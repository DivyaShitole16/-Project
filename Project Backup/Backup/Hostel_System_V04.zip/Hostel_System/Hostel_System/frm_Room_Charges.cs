﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Room_Charges : Form
    {
        public frm_Room_Charges()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        void Clear_Controls()
        {

            cmb_Room_Type.SelectedIndex= -1;
            tb_Deposit.Clear();
            tb_Charges.Clear();
        }

        void Bind_Grid()
        {
            Con_Open();

            dgv_Charges.DataSource = "";

            SqlDataAdapter SDA = new SqlDataAdapter("Select * from Room_Charges ", Con);

            DataTable dt = new DataTable();
            SDA.Fill(dt);

            dgv_Charges.DataSource = dt;

            Con_Close();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (cmb_Room_Type.Text != "" && tb_Deposit.Text != "" && tb_Charges.Text != "" )
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Update Room_Charges Set Deposit= @Deposit, Charges= @Charges, Date= @date where Room_Type = @RType";

                Cmd.Parameters.Add("RType", SqlDbType.NVarChar).Value = cmb_Room_Type.Text;
                Cmd.Parameters.Add("Deposit", SqlDbType.Money).Value = tb_Deposit.Text;
                Cmd.Parameters.Add("Charges", SqlDbType.Money).Value = tb_Charges.Text;
                Cmd.Parameters.Add("Date", SqlDbType.Date).Value = dtp_Date.Value.Date;

                Cmd.ExecuteNonQuery();
                MessageBox.Show("Charges Set Successfully");
                Bind_Grid();

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }
            Con_Close();
        }

        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        
        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void frm_Room_Charges_Load(object sender, EventArgs e)
        {
            Bind_Grid();
        }

    }
}
