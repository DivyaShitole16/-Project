﻿namespace Hostel_System
{
    partial class frm_Room_Charges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Room_Charges_Setting = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_Room_Charges = new System.Windows.Forms.GroupBox();
            this.lbl_Per_Sem1 = new System.Windows.Forms.Label();
            this.lbl_Per_Sem = new System.Windows.Forms.Label();
            this.cmb_Room_Type = new System.Windows.Forms.ComboBox();
            this.tb_Charges = new System.Windows.Forms.TextBox();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.lbl_Deposit = new System.Windows.Forms.Label();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Charges = new System.Windows.Forms.Label();
            this.dgv_Charges = new System.Windows.Forms.DataGridView();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gb_Room_Charges.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Charges)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(300, 640);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 77);
            this.btn_Refresh.TabIndex = 23;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Room_Charges_Setting);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1430, 122);
            this.panel1.TabIndex = 20;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Enabled = false;
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold);
            this.dtp_Date.Location = new System.Drawing.Point(1016, 56);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(309, 38);
            this.dtp_Date.TabIndex = 25;
            // 
            // lbl_Room_Charges_Setting
            // 
            this.lbl_Room_Charges_Setting.AutoSize = true;
            this.lbl_Room_Charges_Setting.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Charges_Setting.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Charges_Setting.Location = new System.Drawing.Point(389, 20);
            this.lbl_Room_Charges_Setting.Name = "lbl_Room_Charges_Setting";
            this.lbl_Room_Charges_Setting.Size = new System.Drawing.Size(684, 77);
            this.lbl_Room_Charges_Setting.TabIndex = 0;
            this.lbl_Room_Charges_Setting.Text = "Room Charges Setting";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(869, 640);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 77);
            this.btn_Save.TabIndex = 22;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // gb_Room_Charges
            // 
            this.gb_Room_Charges.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Room_Charges.Controls.Add(this.lbl_Date);
            this.gb_Room_Charges.Controls.Add(this.dtp_Date);
            this.gb_Room_Charges.Controls.Add(this.lbl_Per_Sem1);
            this.gb_Room_Charges.Controls.Add(this.lbl_Per_Sem);
            this.gb_Room_Charges.Controls.Add(this.cmb_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.tb_Charges);
            this.gb_Room_Charges.Controls.Add(this.tb_Deposit);
            this.gb_Room_Charges.Controls.Add(this.lbl_Deposit);
            this.gb_Room_Charges.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.lbl_Charges);
            this.gb_Room_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Charges.ForeColor = System.Drawing.Color.Indigo;
            this.gb_Room_Charges.Location = new System.Drawing.Point(12, 163);
            this.gb_Room_Charges.Name = "gb_Room_Charges";
            this.gb_Room_Charges.Size = new System.Drawing.Size(1408, 237);
            this.gb_Room_Charges.TabIndex = 21;
            this.gb_Room_Charges.TabStop = false;
            this.gb_Room_Charges.Text = "Charges";
            // 
            // lbl_Per_Sem1
            // 
            this.lbl_Per_Sem1.AutoSize = true;
            this.lbl_Per_Sem1.Font = new System.Drawing.Font("Marlett", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Per_Sem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl_Per_Sem1.Location = new System.Drawing.Point(853, 204);
            this.lbl_Per_Sem1.Name = "lbl_Per_Sem1";
            this.lbl_Per_Sem1.Size = new System.Drawing.Size(100, 22);
            this.lbl_Per_Sem1.TabIndex = 5;
            this.lbl_Per_Sem1.Text = "(Per Sem)";
            // 
            // lbl_Per_Sem
            // 
            this.lbl_Per_Sem.AutoSize = true;
            this.lbl_Per_Sem.Font = new System.Drawing.Font("Marlett", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Per_Sem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl_Per_Sem.Location = new System.Drawing.Point(114, 202);
            this.lbl_Per_Sem.Name = "lbl_Per_Sem";
            this.lbl_Per_Sem.Size = new System.Drawing.Size(100, 22);
            this.lbl_Per_Sem.TabIndex = 4;
            this.lbl_Per_Sem.Text = "(Per Sem)";
            // 
            // cmb_Room_Type
            // 
            this.cmb_Room_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_Type.FormattingEnabled = true;
            this.cmb_Room_Type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_Room_Type.Location = new System.Drawing.Point(319, 57);
            this.cmb_Room_Type.Name = "cmb_Room_Type";
            this.cmb_Room_Type.Size = new System.Drawing.Size(309, 43);
            this.cmb_Room_Type.TabIndex = 1;
            // 
            // tb_Charges
            // 
            this.tb_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Charges.Location = new System.Drawing.Point(1016, 155);
            this.tb_Charges.MaxLength = 5;
            this.tb_Charges.Name = "tb_Charges";
            this.tb_Charges.Size = new System.Drawing.Size(309, 38);
            this.tb_Charges.TabIndex = 3;
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Deposit.Location = new System.Drawing.Point(319, 155);
            this.tb_Deposit.MaxLength = 5;
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(309, 38);
            this.tb_Deposit.TabIndex = 2;
            this.tb_Deposit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Deposit
            // 
            this.lbl_Deposit.AutoSize = true;
            this.lbl_Deposit.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deposit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Deposit.Location = new System.Drawing.Point(28, 155);
            this.lbl_Deposit.Name = "lbl_Deposit";
            this.lbl_Deposit.Size = new System.Drawing.Size(121, 36);
            this.lbl_Deposit.TabIndex = 0;
            this.lbl_Deposit.Text = "Deposit";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Type.Location = new System.Drawing.Point(28, 59);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(170, 36);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Charges
            // 
            this.lbl_Charges.AutoSize = true;
            this.lbl_Charges.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Charges.ForeColor = System.Drawing.Color.Black;
            this.lbl_Charges.Location = new System.Drawing.Point(767, 155);
            this.lbl_Charges.Name = "lbl_Charges";
            this.lbl_Charges.Size = new System.Drawing.Size(126, 36);
            this.lbl_Charges.TabIndex = 0;
            this.lbl_Charges.Text = "Charges";
            // 
            // dgv_Charges
            // 
            this.dgv_Charges.AllowUserToAddRows = false;
            this.dgv_Charges.AllowUserToDeleteRows = false;
            this.dgv_Charges.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Charges.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Charges.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Charges.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Mongolian Baiti", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_Charges.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Charges.Location = new System.Drawing.Point(12, 430);
            this.dgv_Charges.Name = "dgv_Charges";
            this.dgv_Charges.ReadOnly = true;
            this.dgv_Charges.RowTemplate.Height = 24;
            this.dgv_Charges.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Charges.Size = new System.Drawing.Size(1408, 186);
            this.dgv_Charges.TabIndex = 24;
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(767, 59);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(79, 36);
            this.lbl_Date.TabIndex = 26;
            this.lbl_Date.Text = "Date";
            // 
            // frm_Room_Charges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1430, 753);
            this.ControlBox = false;
            this.Controls.Add(this.dgv_Charges);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gb_Room_Charges);
            this.Controls.Add(this.btn_Save);
            this.Name = "frm_Room_Charges";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Charges Setting";
            this.Load += new System.EventHandler(this.frm_Room_Charges_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Charges.ResumeLayout(false);
            this.gb_Room_Charges.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Charges)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Room_Charges_Setting;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.GroupBox gb_Room_Charges;
        private System.Windows.Forms.TextBox tb_Charges;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.Label lbl_Deposit;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Charges;
        private System.Windows.Forms.DataGridView dgv_Charges;
        private System.Windows.Forms.ComboBox cmb_Room_Type;
        private System.Windows.Forms.Label lbl_Per_Sem1;
        private System.Windows.Forms.Label lbl_Per_Sem;
        private System.Windows.Forms.DateTimePicker dtp_Date;
      
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn roomTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn depositDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn chargesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lbl_Date;
    }
}