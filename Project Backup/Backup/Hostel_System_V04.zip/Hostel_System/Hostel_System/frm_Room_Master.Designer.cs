﻿namespace Hostel_System
{
    partial class frm_Room_Master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Capacity = new System.Windows.Forms.TextBox();
            this.tb_Room_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Room_Master = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.lbl_Capacity = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_Room_Master = new System.Windows.Forms.GroupBox();
            this.cmb_Floor = new System.Windows.Forms.ComboBox();
            this.cmb_Room_type = new System.Windows.Forms.ComboBox();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Room_ID = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.gb_Room_Master.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Capacity
            // 
            this.tb_Capacity.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Capacity.Location = new System.Drawing.Point(690, 346);
            this.tb_Capacity.MaxLength = 10;
            this.tb_Capacity.Name = "tb_Capacity";
            this.tb_Capacity.Size = new System.Drawing.Size(186, 38);
            this.tb_Capacity.TabIndex = 5;
            // 
            // tb_Room_Id
            // 
            this.tb_Room_Id.Enabled = false;
            this.tb_Room_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Id.Location = new System.Drawing.Point(288, 106);
            this.tb_Room_Id.MaxLength = 10;
            this.tb_Room_Id.Name = "tb_Room_Id";
            this.tb_Room_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Room_Id.TabIndex = 1;
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(712, 209);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(146, 36);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Room No.";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Room_Master);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1432, 119);
            this.panel1.TabIndex = 16;
            // 
            // lbl_Room_Master
            // 
            this.lbl_Room_Master.AutoSize = true;
            this.lbl_Room_Master.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Room_Master.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Master.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Master.Location = new System.Drawing.Point(477, 22);
            this.lbl_Room_Master.Name = "lbl_Room_Master";
            this.lbl_Room_Master.Size = new System.Drawing.Size(431, 79);
            this.lbl_Room_Master.TabIndex = 0;
            this.lbl_Room_Master.Text = "Room Master";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Floor.Location = new System.Drawing.Point(712, 104);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(89, 36);
            this.lbl_Floor.TabIndex = 0;
            this.lbl_Floor.Text = "Floor";
            // 
            // lbl_Capacity
            // 
            this.lbl_Capacity.AutoSize = true;
            this.lbl_Capacity.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Capacity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Capacity.Location = new System.Drawing.Point(507, 346);
            this.lbl_Capacity.Name = "lbl_Capacity";
            this.lbl_Capacity.Size = new System.Drawing.Size(132, 36);
            this.lbl_Capacity.TabIndex = 0;
            this.lbl_Capacity.Text = "Capacity";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(718, 648);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 77);
            this.btn_Save.TabIndex = 18;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // gb_Room_Master
            // 
            this.gb_Room_Master.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Room_Master.Controls.Add(this.cmb_Floor);
            this.gb_Room_Master.Controls.Add(this.cmb_Room_type);
            this.gb_Room_Master.Controls.Add(this.tb_Capacity);
            this.gb_Room_Master.Controls.Add(this.tb_Room_No);
            this.gb_Room_Master.Controls.Add(this.tb_Room_Id);
            this.gb_Room_Master.Controls.Add(this.lbl_Mobile_No);
            this.gb_Room_Master.Controls.Add(this.lbl_Floor);
            this.gb_Room_Master.Controls.Add(this.lbl_Capacity);
            this.gb_Room_Master.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Master.Controls.Add(this.lbl_Room_ID);
            this.gb_Room_Master.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Master.ForeColor = System.Drawing.Color.Indigo;
            this.gb_Room_Master.Location = new System.Drawing.Point(0, 149);
            this.gb_Room_Master.Name = "gb_Room_Master";
            this.gb_Room_Master.Size = new System.Drawing.Size(1432, 459);
            this.gb_Room_Master.TabIndex = 17;
            this.gb_Room_Master.TabStop = false;
            this.gb_Room_Master.Text = "Room Master";
            // 
            // cmb_Floor
            // 
            this.cmb_Floor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Floor.FormattingEnabled = true;
            this.cmb_Floor.Items.AddRange(new object[] {
            "1 st Floor",
            "2 nd Floor"});
            this.cmb_Floor.Location = new System.Drawing.Point(977, 107);
            this.cmb_Floor.Name = "cmb_Floor";
            this.cmb_Floor.Size = new System.Drawing.Size(303, 37);
            this.cmb_Floor.TabIndex = 3;
            // 
            // cmb_Room_type
            // 
            this.cmb_Room_type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Room_type.FormattingEnabled = true;
            this.cmb_Room_type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_Room_type.Location = new System.Drawing.Point(288, 212);
            this.cmb_Room_type.Name = "cmb_Room_type";
            this.cmb_Room_type.Size = new System.Drawing.Size(303, 37);
            this.cmb_Room_type.TabIndex = 2;
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(977, 209);
            this.tb_Room_No.MaxLength = 5;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(303, 38);
            this.tb_Room_No.TabIndex = 4;
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(23, 209);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(170, 36);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Room_ID
            // 
            this.lbl_Room_ID.AutoSize = true;
            this.lbl_Room_ID.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_ID.Location = new System.Drawing.Point(23, 104);
            this.lbl_Room_ID.Name = "lbl_Room_ID";
            this.lbl_Room_ID.Size = new System.Drawing.Size(133, 36);
            this.lbl_Room_ID.TabIndex = 0;
            this.lbl_Room_ID.Text = "Room ID";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(359, 648);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 77);
            this.btn_Refresh.TabIndex = 19;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Room_Master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Room_Master);
            this.Name = "frm_Room_Master";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Master";
            this.Load += new System.EventHandler(this.frm_Room_Master_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Master.ResumeLayout(false);
            this.gb_Room_Master.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Capacity;
        private System.Windows.Forms.TextBox tb_Room_Id;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Room_Master;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.Label lbl_Capacity;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.GroupBox gb_Room_Master;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Room_ID;
        private System.Windows.Forms.ComboBox cmb_Room_type;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.ComboBox cmb_Floor;
        private System.Windows.Forms.TextBox tb_Room_No;
    }
}