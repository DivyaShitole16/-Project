﻿namespace Hostel_System
{
    partial class frm_Leaving_Room
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.lbl_Leaving_Room = new System.Windows.Forms.Label();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Search = new System.Windows.Forms.Button();
            this.cmb_Room_No = new System.Windows.Forms.ComboBox();
            this.lbl_Remark = new System.Windows.Forms.Label();
            this.tb_Remark = new System.Windows.Forms.TextBox();
            this.tb_Time = new System.Windows.Forms.TextBox();
            this.lbl_Time = new System.Windows.Forms.Label();
            this.lbl_Leave_Date = new System.Windows.Forms.Label();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Student_Id = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(695, 269);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(330, 38);
            this.dtp_Date.TabIndex = 4;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(729, 676);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 65);
            this.btn_Save.TabIndex = 24;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_Name
            // 
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(695, 106);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(330, 38);
            this.tb_Name.TabIndex = 2;
            // 
            // lbl_Leaving_Room
            // 
            this.lbl_Leaving_Room.AutoSize = true;
            this.lbl_Leaving_Room.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Leaving_Room.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Leaving_Room.Location = new System.Drawing.Point(511, 26);
            this.lbl_Leaving_Room.Name = "lbl_Leaving_Room";
            this.lbl_Leaving_Room.Size = new System.Drawing.Size(455, 77);
            this.lbl_Leaving_Room.TabIndex = 0;
            this.lbl_Leaving_Room.Text = "Leaving Room";
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(695, 26);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(330, 38);
            this.tb_Student_Id.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel2.Controls.Add(this.btn_Search);
            this.panel2.Controls.Add(this.cmb_Room_No);
            this.panel2.Controls.Add(this.lbl_Remark);
            this.panel2.Controls.Add(this.tb_Remark);
            this.panel2.Controls.Add(this.tb_Time);
            this.panel2.Controls.Add(this.lbl_Time);
            this.panel2.Controls.Add(this.dtp_Date);
            this.panel2.Controls.Add(this.tb_Name);
            this.panel2.Controls.Add(this.tb_Student_Id);
            this.panel2.Controls.Add(this.lbl_Leave_Date);
            this.panel2.Controls.Add(this.lbl_Room_No);
            this.panel2.Controls.Add(this.lbl_Name);
            this.panel2.Controls.Add(this.lbl_Student_Id);
            this.panel2.Location = new System.Drawing.Point(12, 170);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1408, 498);
            this.panel2.TabIndex = 25;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Search.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Search.Location = new System.Drawing.Point(1094, 17);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(191, 55);
            this.btn_Search.TabIndex = 29;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            // 
            // cmb_Room_No
            // 
            this.cmb_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_No.FormattingEnabled = true;
            this.cmb_Room_No.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21"});
            this.cmb_Room_No.Location = new System.Drawing.Point(695, 186);
            this.cmb_Room_No.Name = "cmb_Room_No";
            this.cmb_Room_No.Size = new System.Drawing.Size(330, 43);
            this.cmb_Room_No.TabIndex = 3;
            // 
            // lbl_Remark
            // 
            this.lbl_Remark.AutoSize = true;
            this.lbl_Remark.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Remark.ForeColor = System.Drawing.Color.Black;
            this.lbl_Remark.Location = new System.Drawing.Point(302, 448);
            this.lbl_Remark.Name = "lbl_Remark";
            this.lbl_Remark.Size = new System.Drawing.Size(125, 36);
            this.lbl_Remark.TabIndex = 8;
            this.lbl_Remark.Text = "Remark";
            // 
            // tb_Remark
            // 
            this.tb_Remark.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Remark.Location = new System.Drawing.Point(695, 445);
            this.tb_Remark.MaxLength = 20;
            this.tb_Remark.Name = "tb_Remark";
            this.tb_Remark.Size = new System.Drawing.Size(330, 38);
            this.tb_Remark.TabIndex = 6;
            // 
            // tb_Time
            // 
            this.tb_Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Time.Location = new System.Drawing.Point(695, 357);
            this.tb_Time.MaxLength = 7;
            this.tb_Time.Name = "tb_Time";
            this.tb_Time.Size = new System.Drawing.Size(330, 38);
            this.tb_Time.TabIndex = 5;
            // 
            // lbl_Time
            // 
            this.lbl_Time.AutoSize = true;
            this.lbl_Time.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Time.ForeColor = System.Drawing.Color.Black;
            this.lbl_Time.Location = new System.Drawing.Point(302, 360);
            this.lbl_Time.Name = "lbl_Time";
            this.lbl_Time.Size = new System.Drawing.Size(86, 36);
            this.lbl_Time.TabIndex = 7;
            this.lbl_Time.Text = "Time";
            // 
            // lbl_Leave_Date
            // 
            this.lbl_Leave_Date.AutoSize = true;
            this.lbl_Leave_Date.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Leave_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Leave_Date.Location = new System.Drawing.Point(302, 273);
            this.lbl_Leave_Date.Name = "lbl_Leave_Date";
            this.lbl_Leave_Date.Size = new System.Drawing.Size(165, 36);
            this.lbl_Leave_Date.TabIndex = 0;
            this.lbl_Leave_Date.Text = "Leave Date";
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(302, 186);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(146, 36);
            this.lbl_Room_No.TabIndex = 0;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(302, 109);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(94, 36);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Student_Id
            // 
            this.lbl_Student_Id.AutoSize = true;
            this.lbl_Student_Id.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Id.Location = new System.Drawing.Point(302, 29);
            this.lbl_Student_Id.Name = "lbl_Student_Id";
            this.lbl_Student_Id.Size = new System.Drawing.Size(160, 36);
            this.lbl_Student_Id.TabIndex = 0;
            this.lbl_Student_Id.Text = "Student ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Leaving_Room);
            this.panel1.Location = new System.Drawing.Point(-2, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1508, 125);
            this.panel1.TabIndex = 23;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(408, 676);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 65);
            this.btn_Refresh.TabIndex = 26;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // frm_Leaving_Room
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Leaving_Room";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leaving Room";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.Label lbl_Leaving_Room;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_Remark;
        private System.Windows.Forms.TextBox tb_Remark;
        private System.Windows.Forms.TextBox tb_Time;
        private System.Windows.Forms.Label lbl_Time;
        private System.Windows.Forms.Label lbl_Leave_Date;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Student_Id;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmb_Room_No;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Search;
    }
}