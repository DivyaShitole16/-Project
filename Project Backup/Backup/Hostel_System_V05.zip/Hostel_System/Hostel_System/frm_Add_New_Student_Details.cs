﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Add_New_Student_Details : Form
    {
        public frm_Add_New_Student_Details()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (Char)Keys.Space)))
            {
                e.Handled = true;
            }
        }
       int Auto_Incr()
        {
            int Cnt = 0;
            Con_Open();

            SqlCommand Cmd = new SqlCommand();

            Cmd.Connection = Con;
            Cmd.CommandText = "Select Count(*) From Student_Details";

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());
            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Student_Id)From Student_Details";
                Cnt = Convert.ToInt32(Cmd.ExecuteScalar()) + 1;
            }
            else
            {
                Cnt = 1001;
            }

            Con_Close();
            return Cnt;
        }
       
        void Clear_Controls()
        {       
            tb_Student_Id.Text = Convert.ToString(Auto_Incr());

            tb_First_Name.Clear();
            tb_Middle_Name.Clear();
            tb_Last_name.Clear();
            tb_Mobile_No.Clear();
            tb_Aadhar_No.Clear();
            tb_Guardian_Name.Clear();
            tb_Mobile_No1.Clear();
            tb_Mobile_No2.Clear();
            tb_Note.Clear();
            tb_College_Name.Clear();
            tb_Course.Clear();
            tb_Address.Clear();
            tb_Relationship.Clear();
           
        }
        private void frm_Add_New_Student_Details_Load(object sender, EventArgs e)
        {
            Auto_Incr();
            Clear_Controls();
            tb_Student_Id.Focus();


        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (tb_Student_Id.Text != "" && tb_First_Name.Text != "" && tb_Middle_Name.Text != "" && tb_Last_name.Text != "" && tb_Mobile_No.Text != "" && tb_Aadhar_No.Text != "" && tb_Guardian_Name.Text != "" && tb_Mobile_No1.Text != "" && tb_Mobile_No2.Text != "" && tb_Relationship.Text != "" && tb_Note.Text != "" && tb_College_Name.Text != "" && tb_Address.Text != "")
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Student_Details(Student_Id,First_Name,Middle_Name,Last_Name,Mobile_No,Aadhar_No,Guardian_Name,Mobile_No1,Mobile_No2,Relationship,Note,College_Name,Course,Address)Values(@Stud_ID,@F_Name,@M_Name,@L_Name,@Mob_No,@Aadhar_No,@Guardian_Name,@Mob_No1,@Mob_No2,@Relationship,@Note,@Clg_Name,@Course,@Address)";
                Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                Cmd.Parameters.Add("F_Name", SqlDbType.VarChar).Value = tb_First_Name.Text;
                Cmd.Parameters.Add("M_Name", SqlDbType.VarChar).Value = tb_Middle_Name.Text;
                Cmd.Parameters.Add("L_Name", SqlDbType.VarChar).Value = tb_Last_name.Text;
                Cmd.Parameters.Add("Mob_No", SqlDbType.Decimal).Value = tb_Mobile_No.Text;
                Cmd.Parameters.Add("Aadhar_No", SqlDbType.Decimal).Value = tb_Aadhar_No.Text;
                Cmd.Parameters.Add("Guardian_Name", SqlDbType.VarChar).Value = tb_Guardian_Name.Text;
                Cmd.Parameters.Add("Mob_No1", SqlDbType.Decimal).Value = tb_Mobile_No1.Text;
                Cmd.Parameters.Add("Mob_No2", SqlDbType.Decimal).Value = tb_Mobile_No2.Text;
                Cmd.Parameters.Add("Relationship", SqlDbType.VarChar).Value = tb_Relationship.Text;
                Cmd.Parameters.Add("Note", SqlDbType.NVarChar).Value = tb_Note.Text;
                Cmd.Parameters.Add("Clg_Name", SqlDbType.VarChar).Value = tb_College_Name.Text;
                Cmd.Parameters.Add("Course", SqlDbType.NVarChar).Value = tb_Course.Text;
                Cmd.Parameters.Add("Address", SqlDbType.NVarChar).Value = tb_Address.Text;

                Cmd.ExecuteNonQuery();


                MessageBox.Show("Record Saved");
                Clear_Controls();

            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }
            Con_Close();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

       
    }

    }

