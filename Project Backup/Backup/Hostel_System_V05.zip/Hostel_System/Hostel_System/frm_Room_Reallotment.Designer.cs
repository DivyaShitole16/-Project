﻿namespace Hostel_System
{
    partial class frm_Room_Reallotment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_Allocation_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_New_Room_Type = new System.Windows.Forms.Label();
            this.lbl_New_Room_No = new System.Windows.Forms.Label();
            this.lbl_New_Floor = new System.Windows.Forms.Label();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Allocation_Date = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Student_Id = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.cmb_Room_type = new System.Windows.Forms.ComboBox();
            this.lbl_Room_Reallotment = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Allocation_Date
            // 
            this.dtp_Allocation_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Allocation_Date.Location = new System.Drawing.Point(1015, 60);
            this.dtp_Allocation_Date.Name = "dtp_Allocation_Date";
            this.dtp_Allocation_Date.Size = new System.Drawing.Size(305, 38);
            this.dtp_Allocation_Date.TabIndex = 5;
            // 
            // lbl_New_Room_Type
            // 
            this.lbl_New_Room_Type.AutoSize = true;
            this.lbl_New_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_Type.Location = new System.Drawing.Point(697, 264);
            this.lbl_New_Room_Type.Name = "lbl_New_Room_Type";
            this.lbl_New_Room_Type.Size = new System.Drawing.Size(224, 35);
            this.lbl_New_Room_Type.TabIndex = 0;
            this.lbl_New_Room_Type.Text = "New Room Type";
            // 
            // lbl_New_Room_No
            // 
            this.lbl_New_Room_No.AutoSize = true;
            this.lbl_New_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_No.Location = new System.Drawing.Point(697, 368);
            this.lbl_New_Room_No.Name = "lbl_New_Room_No";
            this.lbl_New_Room_No.Size = new System.Drawing.Size(200, 35);
            this.lbl_New_Room_No.TabIndex = 0;
            this.lbl_New_Room_No.Text = "New Room No";
            // 
            // lbl_New_Floor
            // 
            this.lbl_New_Floor.AutoSize = true;
            this.lbl_New_Floor.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Floor.Location = new System.Drawing.Point(705, 163);
            this.lbl_New_Floor.Name = "lbl_New_Floor";
            this.lbl_New_Floor.Size = new System.Drawing.Size(148, 35);
            this.lbl_New_Floor.TabIndex = 0;
            this.lbl_New_Floor.Text = "New Floor";
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(262, 60);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Student_Id.TabIndex = 1;
            // 
            // lbl_Allocation_Date
            // 
            this.lbl_Allocation_Date.AutoSize = true;
            this.lbl_Allocation_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Allocation_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Allocation_Date.Location = new System.Drawing.Point(705, 64);
            this.lbl_Allocation_Date.Name = "lbl_Allocation_Date";
            this.lbl_Allocation_Date.Size = new System.Drawing.Size(216, 35);
            this.lbl_Allocation_Date.TabIndex = 0;
            this.lbl_Allocation_Date.Text = " Allocation Date";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Floor.Location = new System.Drawing.Point(17, 165);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(84, 35);
            this.lbl_Floor.TabIndex = 0;
            this.lbl_Floor.Text = "Floor";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(719, 662);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 79);
            this.btn_Save.TabIndex = 24;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(17, 368);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(144, 35);
            this.lbl_Room_No.TabIndex = 0;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(5, 264);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(168, 35);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = " Room Type";
            // 
            // lbl_Student_Id
            // 
            this.lbl_Student_Id.AutoSize = true;
            this.lbl_Student_Id.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Id.Location = new System.Drawing.Point(17, 63);
            this.lbl_Student_Id.Name = "lbl_Student_Id";
            this.lbl_Student_Id.Size = new System.Drawing.Size(156, 35);
            this.lbl_Student_Id.TabIndex = 0;
            this.lbl_Student_Id.Text = "Student ID";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel2.Controls.Add(this.comboBox3);
            this.panel2.Controls.Add(this.comboBox4);
            this.panel2.Controls.Add(this.comboBox5);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.cmb_Room_type);
            this.panel2.Controls.Add(this.dtp_Allocation_Date);
            this.panel2.Controls.Add(this.lbl_New_Room_Type);
            this.panel2.Controls.Add(this.lbl_New_Room_No);
            this.panel2.Controls.Add(this.lbl_New_Floor);
            this.panel2.Controls.Add(this.tb_Student_Id);
            this.panel2.Controls.Add(this.lbl_Allocation_Date);
            this.panel2.Controls.Add(this.lbl_Room_No);
            this.panel2.Controls.Add(this.lbl_Room_Type);
            this.panel2.Controls.Add(this.lbl_Floor);
            this.panel2.Controls.Add(this.lbl_Student_Id);
            this.panel2.Location = new System.Drawing.Point(-2, 180);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1444, 464);
            this.panel2.TabIndex = 25;
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(1017, 364);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(303, 39);
            this.comboBox3.TabIndex = 14;
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(1017, 260);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(303, 39);
            this.comboBox4.TabIndex = 13;
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(1015, 159);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(305, 39);
            this.comboBox5.TabIndex = 12;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(262, 364);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(303, 39);
            this.comboBox2.TabIndex = 11;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(262, 260);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(303, 39);
            this.comboBox1.TabIndex = 3;
            // 
            // cmb_Room_type
            // 
            this.cmb_Room_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_type.FormattingEnabled = true;
            this.cmb_Room_type.Location = new System.Drawing.Point(262, 164);
            this.cmb_Room_type.Name = "cmb_Room_type";
            this.cmb_Room_type.Size = new System.Drawing.Size(303, 39);
            this.cmb_Room_type.TabIndex = 2;
            // 
            // lbl_Room_Reallotment
            // 
            this.lbl_Room_Reallotment.AutoSize = true;
            this.lbl_Room_Reallotment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Room_Reallotment.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Reallotment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Reallotment.Location = new System.Drawing.Point(461, 21);
            this.lbl_Room_Reallotment.Name = "lbl_Room_Reallotment";
            this.lbl_Room_Reallotment.Size = new System.Drawing.Size(576, 79);
            this.lbl_Room_Reallotment.TabIndex = 0;
            this.lbl_Room_Reallotment.Text = "Room Reallotment";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Room_Reallotment);
            this.panel1.Location = new System.Drawing.Point(-2, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1508, 125);
            this.panel1.TabIndex = 23;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(383, 662);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 79);
            this.btn_Refresh.TabIndex = 26;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // frm_Room_Reallotment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Room_Reallotment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Reallotment";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Allocation_Date;
        private System.Windows.Forms.Label lbl_New_Room_Type;
        private System.Windows.Forms.Label lbl_New_Room_No;
        private System.Windows.Forms.Label lbl_New_Floor;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Allocation_Date;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Student_Id;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_Room_Reallotment;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox cmb_Room_type;
        private System.Windows.Forms.Button btn_Refresh;
    }
}