﻿namespace Hostel_System
{
    partial class frm_Add_New_Student_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Add_Student_Details = new System.Windows.Forms.Label();
            this.gb_Student_Information = new System.Windows.Forms.GroupBox();
            this.tb_Aadhar_No = new System.Windows.Forms.TextBox();
            this.lbl_Aadhar_No = new System.Windows.Forms.Label();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Last_name = new System.Windows.Forms.TextBox();
            this.tb_Middle_Name = new System.Windows.Forms.TextBox();
            this.tb_First_Name = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Last_Name = new System.Windows.Forms.Label();
            this.lbl_Middle_Name = new System.Windows.Forms.Label();
            this.lbl_First_Name = new System.Windows.Forms.Label();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.gb_Guardian_Information = new System.Windows.Forms.GroupBox();
            this.tb_Relationship = new System.Windows.Forms.TextBox();
            this.lbl_Relationship = new System.Windows.Forms.Label();
            this.tb_Note = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No2 = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No1 = new System.Windows.Forms.TextBox();
            this.tb_Guardian_Name = new System.Windows.Forms.TextBox();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.lbl_Mobile_No2 = new System.Windows.Forms.Label();
            this.lbl_Mobile_No1 = new System.Windows.Forms.Label();
            this.lbl_Guardian_Name = new System.Windows.Forms.Label();
            this.gb_Others_Information = new System.Windows.Forms.GroupBox();
            this.btn_Document = new System.Windows.Forms.Button();
            this.lbl_Document = new System.Windows.Forms.Label();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Course = new System.Windows.Forms.TextBox();
            this.tb_College_Name = new System.Windows.Forms.TextBox();
            this.lbl_Student_Address = new System.Windows.Forms.Label();
            this.lbl_Course = new System.Windows.Forms.Label();
            this.lbl_College_Name = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.gb_Student_Information.SuspendLayout();
            this.gb_Guardian_Information.SuspendLayout();
            this.gb_Others_Information.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.dtp_Date);
            this.panel1.Controls.Add(this.lbl_Add_Student_Details);
            this.panel1.Location = new System.Drawing.Point(-1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1431, 107);
            this.panel1.TabIndex = 0;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1138, 60);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(261, 34);
            this.dtp_Date.TabIndex = 1;
            // 
            // lbl_Add_Student_Details
            // 
            this.lbl_Add_Student_Details.AutoSize = true;
            this.lbl_Add_Student_Details.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Add_Student_Details.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Add_Student_Details.Location = new System.Drawing.Point(489, 15);
            this.lbl_Add_Student_Details.Name = "lbl_Add_Student_Details";
            this.lbl_Add_Student_Details.Size = new System.Drawing.Size(549, 77);
            this.lbl_Add_Student_Details.TabIndex = 0;
            this.lbl_Add_Student_Details.Text = "Add New Student";
            // 
            // gb_Student_Information
            // 
            this.gb_Student_Information.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Student_Information.Controls.Add(this.tb_Aadhar_No);
            this.gb_Student_Information.Controls.Add(this.lbl_Aadhar_No);
            this.gb_Student_Information.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Information.Controls.Add(this.tb_Last_name);
            this.gb_Student_Information.Controls.Add(this.tb_Middle_Name);
            this.gb_Student_Information.Controls.Add(this.tb_First_Name);
            this.gb_Student_Information.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Information.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Information.Controls.Add(this.lbl_Last_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_Middle_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_First_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Information.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Student_Information.Location = new System.Drawing.Point(-1, 128);
            this.gb_Student_Information.Name = "gb_Student_Information";
            this.gb_Student_Information.Size = new System.Drawing.Size(484, 530);
            this.gb_Student_Information.TabIndex = 1;
            this.gb_Student_Information.TabStop = false;
            this.gb_Student_Information.Text = "Student Information";
            // 
            // tb_Aadhar_No
            // 
            this.tb_Aadhar_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_No.Location = new System.Drawing.Point(208, 482);
            this.tb_Aadhar_No.MaxLength = 12;
            this.tb_Aadhar_No.Name = "tb_Aadhar_No";
            this.tb_Aadhar_No.Size = new System.Drawing.Size(259, 38);
            this.tb_Aadhar_No.TabIndex = 6;
            this.tb_Aadhar_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Aadhar_No
            // 
            this.lbl_Aadhar_No.AutoSize = true;
            this.lbl_Aadhar_No.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhar_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Aadhar_No.Location = new System.Drawing.Point(10, 478);
            this.lbl_Aadhar_No.Name = "lbl_Aadhar_No";
            this.lbl_Aadhar_No.Size = new System.Drawing.Size(157, 33);
            this.lbl_Aadhar_No.TabIndex = 0;
            this.lbl_Aadhar_No.Text = "Aadhar No.";
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(208, 403);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(259, 38);
            this.tb_Mobile_No.TabIndex = 5;
            this.tb_Mobile_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Last_name
            // 
            this.tb_Last_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Last_name.Location = new System.Drawing.Point(208, 322);
            this.tb_Last_name.MaxLength = 20;
            this.tb_Last_name.Name = "tb_Last_name";
            this.tb_Last_name.Size = new System.Drawing.Size(259, 38);
            this.tb_Last_name.TabIndex = 4;
            this.tb_Last_name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Middle_Name
            // 
            this.tb_Middle_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Middle_Name.Location = new System.Drawing.Point(208, 239);
            this.tb_Middle_Name.MaxLength = 20;
            this.tb_Middle_Name.Name = "tb_Middle_Name";
            this.tb_Middle_Name.Size = new System.Drawing.Size(259, 38);
            this.tb_Middle_Name.TabIndex = 3;
            this.tb_Middle_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_First_Name
            // 
            this.tb_First_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_First_Name.Location = new System.Drawing.Point(208, 150);
            this.tb_First_Name.MaxLength = 20;
            this.tb_First_Name.Name = "tb_First_Name";
            this.tb_First_Name.Size = new System.Drawing.Size(259, 38);
            this.tb_First_Name.TabIndex = 2;
            this.tb_First_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Enabled = false;
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(208, 67);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(259, 38);
            this.tb_Student_Id.TabIndex = 1;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(10, 401);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(152, 33);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Last_Name
            // 
            this.lbl_Last_Name.AutoSize = true;
            this.lbl_Last_Name.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Last_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Last_Name.Location = new System.Drawing.Point(10, 318);
            this.lbl_Last_Name.Name = "lbl_Last_Name";
            this.lbl_Last_Name.Size = new System.Drawing.Size(148, 33);
            this.lbl_Last_Name.TabIndex = 0;
            this.lbl_Last_Name.Text = "Last Name";
            // 
            // lbl_Middle_Name
            // 
            this.lbl_Middle_Name.AutoSize = true;
            this.lbl_Middle_Name.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Middle_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Middle_Name.Location = new System.Drawing.Point(10, 237);
            this.lbl_Middle_Name.Name = "lbl_Middle_Name";
            this.lbl_Middle_Name.Size = new System.Drawing.Size(186, 33);
            this.lbl_Middle_Name.TabIndex = 0;
            this.lbl_Middle_Name.Text = "Middle Name";
            // 
            // lbl_First_Name
            // 
            this.lbl_First_Name.AutoSize = true;
            this.lbl_First_Name.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_First_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_First_Name.Location = new System.Drawing.Point(10, 148);
            this.lbl_First_Name.Name = "lbl_First_Name";
            this.lbl_First_Name.Size = new System.Drawing.Size(155, 33);
            this.lbl_First_Name.TabIndex = 0;
            this.lbl_First_Name.Text = "First Name";
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(10, 65);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(151, 33);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // gb_Guardian_Information
            // 
            this.gb_Guardian_Information.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Guardian_Information.Controls.Add(this.tb_Relationship);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Relationship);
            this.gb_Guardian_Information.Controls.Add(this.tb_Note);
            this.gb_Guardian_Information.Controls.Add(this.tb_Mobile_No2);
            this.gb_Guardian_Information.Controls.Add(this.tb_Mobile_No1);
            this.gb_Guardian_Information.Controls.Add(this.tb_Guardian_Name);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Note);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Mobile_No2);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Mobile_No1);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Guardian_Name);
            this.gb_Guardian_Information.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Guardian_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Guardian_Information.Location = new System.Drawing.Point(496, 128);
            this.gb_Guardian_Information.Name = "gb_Guardian_Information";
            this.gb_Guardian_Information.Size = new System.Drawing.Size(475, 530);
            this.gb_Guardian_Information.TabIndex = 2;
            this.gb_Guardian_Information.TabStop = false;
            this.gb_Guardian_Information.Text = "Guardian Information";
            // 
            // tb_Relationship
            // 
            this.tb_Relationship.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Relationship.Location = new System.Drawing.Point(225, 315);
            this.tb_Relationship.MaxLength = 20;
            this.tb_Relationship.Name = "tb_Relationship";
            this.tb_Relationship.Size = new System.Drawing.Size(236, 38);
            this.tb_Relationship.TabIndex = 10;
            this.tb_Relationship.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Relationship
            // 
            this.lbl_Relationship.AutoSize = true;
            this.lbl_Relationship.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Relationship.ForeColor = System.Drawing.Color.Black;
            this.lbl_Relationship.Location = new System.Drawing.Point(-1, 324);
            this.lbl_Relationship.Name = "lbl_Relationship";
            this.lbl_Relationship.Size = new System.Drawing.Size(170, 32);
            this.lbl_Relationship.TabIndex = 0;
            this.lbl_Relationship.Text = "Relationship";
            // 
            // tb_Note
            // 
            this.tb_Note.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Note.Location = new System.Drawing.Point(220, 398);
            this.tb_Note.MaxLength = 50;
            this.tb_Note.Multiline = true;
            this.tb_Note.Name = "tb_Note";
            this.tb_Note.Size = new System.Drawing.Size(241, 83);
            this.tb_Note.TabIndex = 11;
            // 
            // tb_Mobile_No2
            // 
            this.tb_Mobile_No2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No2.Location = new System.Drawing.Point(225, 234);
            this.tb_Mobile_No2.MaxLength = 10;
            this.tb_Mobile_No2.Name = "tb_Mobile_No2";
            this.tb_Mobile_No2.Size = new System.Drawing.Size(236, 38);
            this.tb_Mobile_No2.TabIndex = 9;
            this.tb_Mobile_No2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Mobile_No1
            // 
            this.tb_Mobile_No1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No1.Location = new System.Drawing.Point(225, 145);
            this.tb_Mobile_No1.MaxLength = 10;
            this.tb_Mobile_No1.Name = "tb_Mobile_No1";
            this.tb_Mobile_No1.Size = new System.Drawing.Size(236, 38);
            this.tb_Mobile_No1.TabIndex = 8;
            this.tb_Mobile_No1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Guardian_Name
            // 
            this.tb_Guardian_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Guardian_Name.Location = new System.Drawing.Point(225, 67);
            this.tb_Guardian_Name.MaxLength = 50;
            this.tb_Guardian_Name.Name = "tb_Guardian_Name";
            this.tb_Guardian_Name.Size = new System.Drawing.Size(236, 38);
            this.tb_Guardian_Name.TabIndex = 7;
            this.tb_Guardian_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.ForeColor = System.Drawing.Color.Black;
            this.lbl_Note.Location = new System.Drawing.Point(5, 403);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(72, 32);
            this.lbl_Note.TabIndex = 0;
            this.lbl_Note.Text = "Note";
            // 
            // lbl_Mobile_No2
            // 
            this.lbl_Mobile_No2.AutoSize = true;
            this.lbl_Mobile_No2.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No2.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No2.Location = new System.Drawing.Point(0, 239);
            this.lbl_Mobile_No2.Name = "lbl_Mobile_No2";
            this.lbl_Mobile_No2.Size = new System.Drawing.Size(154, 32);
            this.lbl_Mobile_No2.TabIndex = 0;
            this.lbl_Mobile_No2.Text = "Mobile No2";
            // 
            // lbl_Mobile_No1
            // 
            this.lbl_Mobile_No1.AutoSize = true;
            this.lbl_Mobile_No1.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No1.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No1.Location = new System.Drawing.Point(0, 153);
            this.lbl_Mobile_No1.Name = "lbl_Mobile_No1";
            this.lbl_Mobile_No1.Size = new System.Drawing.Size(154, 32);
            this.lbl_Mobile_No1.TabIndex = 0;
            this.lbl_Mobile_No1.Text = "Mobile No1";
            // 
            // lbl_Guardian_Name
            // 
            this.lbl_Guardian_Name.AutoSize = true;
            this.lbl_Guardian_Name.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Guardian_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Guardian_Name.Location = new System.Drawing.Point(-1, 73);
            this.lbl_Guardian_Name.Name = "lbl_Guardian_Name";
            this.lbl_Guardian_Name.Size = new System.Drawing.Size(204, 32);
            this.lbl_Guardian_Name.TabIndex = 0;
            this.lbl_Guardian_Name.Text = "Guardian Name";
            // 
            // gb_Others_Information
            // 
            this.gb_Others_Information.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Others_Information.Controls.Add(this.btn_Document);
            this.gb_Others_Information.Controls.Add(this.lbl_Document);
            this.gb_Others_Information.Controls.Add(this.tb_Address);
            this.gb_Others_Information.Controls.Add(this.tb_Course);
            this.gb_Others_Information.Controls.Add(this.tb_College_Name);
            this.gb_Others_Information.Controls.Add(this.lbl_Student_Address);
            this.gb_Others_Information.Controls.Add(this.lbl_Course);
            this.gb_Others_Information.Controls.Add(this.lbl_College_Name);
            this.gb_Others_Information.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Others_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Others_Information.Location = new System.Drawing.Point(980, 128);
            this.gb_Others_Information.Name = "gb_Others_Information";
            this.gb_Others_Information.Size = new System.Drawing.Size(440, 530);
            this.gb_Others_Information.TabIndex = 3;
            this.gb_Others_Information.TabStop = false;
            this.gb_Others_Information.Text = "Others Information";
            // 
            // btn_Document
            // 
            this.btn_Document.Location = new System.Drawing.Point(193, 315);
            this.btn_Document.Name = "btn_Document";
            this.btn_Document.Size = new System.Drawing.Size(233, 118);
            this.btn_Document.TabIndex = 15;
            this.btn_Document.Text = "Upload Document";
            this.btn_Document.UseVisualStyleBackColor = true;
            // 
            // lbl_Document
            // 
            this.lbl_Document.AutoSize = true;
            this.lbl_Document.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Document.ForeColor = System.Drawing.Color.Black;
            this.lbl_Document.Location = new System.Drawing.Point(9, 320);
            this.lbl_Document.Name = "lbl_Document";
            this.lbl_Document.Size = new System.Drawing.Size(148, 33);
            this.lbl_Document.TabIndex = 0;
            this.lbl_Document.Text = "Document";
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(193, 234);
            this.tb_Address.MaxLength = 50;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(233, 38);
            this.tb_Address.TabIndex = 14;
            // 
            // tb_Course
            // 
            this.tb_Course.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tb_Course.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Course.Location = new System.Drawing.Point(193, 147);
            this.tb_Course.MaxLength = 20;
            this.tb_Course.Name = "tb_Course";
            this.tb_Course.Size = new System.Drawing.Size(233, 38);
            this.tb_Course.TabIndex = 13;
            // 
            // tb_College_Name
            // 
            this.tb_College_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_College_Name.Location = new System.Drawing.Point(193, 70);
            this.tb_College_Name.MaxLength = 50;
            this.tb_College_Name.Name = "tb_College_Name";
            this.tb_College_Name.Size = new System.Drawing.Size(233, 38);
            this.tb_College_Name.TabIndex = 12;
            this.tb_College_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Student_Address
            // 
            this.lbl_Student_Address.AutoSize = true;
            this.lbl_Student_Address.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Address.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Address.Location = new System.Drawing.Point(3, 239);
            this.lbl_Student_Address.Name = "lbl_Student_Address";
            this.lbl_Student_Address.Size = new System.Drawing.Size(127, 33);
            this.lbl_Student_Address.TabIndex = 0;
            this.lbl_Student_Address.Text = " Address";
            // 
            // lbl_Course
            // 
            this.lbl_Course.AutoSize = true;
            this.lbl_Course.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Course.ForeColor = System.Drawing.Color.Black;
            this.lbl_Course.Location = new System.Drawing.Point(9, 150);
            this.lbl_Course.Name = "lbl_Course";
            this.lbl_Course.Size = new System.Drawing.Size(105, 33);
            this.lbl_Course.TabIndex = 0;
            this.lbl_Course.Text = "Course";
            // 
            // lbl_College_Name
            // 
            this.lbl_College_Name.AutoSize = true;
            this.lbl_College_Name.Font = new System.Drawing.Font("Cambria", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_College_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_College_Name.Location = new System.Drawing.Point(6, 75);
            this.lbl_College_Name.Name = "lbl_College_Name";
            this.lbl_College_Name.Size = new System.Drawing.Size(190, 33);
            this.lbl_College_Name.TabIndex = 0;
            this.lbl_College_Name.Text = "College Name";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Save.Location = new System.Drawing.Point(768, 674);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 77);
            this.btn_Save.TabIndex = 10;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Refresh.Location = new System.Drawing.Point(380, 674);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 77);
            this.btn_Refresh.TabIndex = 11;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Add_New_Student_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Others_Information);
            this.Controls.Add(this.gb_Guardian_Information);
            this.Controls.Add(this.gb_Student_Information);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Add_New_Student_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Student Details";
            this.Load += new System.EventHandler(this.frm_Add_New_Student_Details_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Student_Information.ResumeLayout(false);
            this.gb_Student_Information.PerformLayout();
            this.gb_Guardian_Information.ResumeLayout(false);
            this.gb_Guardian_Information.PerformLayout();
            this.gb_Others_Information.ResumeLayout(false);
            this.gb_Others_Information.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Add_Student_Details;
        private System.Windows.Forms.GroupBox gb_Student_Information;
        private System.Windows.Forms.GroupBox gb_Guardian_Information;
        private System.Windows.Forms.GroupBox gb_Others_Information;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Last_Name;
        private System.Windows.Forms.Label lbl_Middle_Name;
        private System.Windows.Forms.Label lbl_First_Name;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Last_name;
        private System.Windows.Forms.TextBox tb_Middle_Name;
        private System.Windows.Forms.TextBox tb_First_Name;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.TextBox tb_Note;
        private System.Windows.Forms.TextBox tb_Mobile_No2;
        private System.Windows.Forms.TextBox tb_Mobile_No1;
        private System.Windows.Forms.TextBox tb_Guardian_Name;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.Label lbl_Mobile_No2;
        private System.Windows.Forms.Label lbl_Mobile_No1;
        private System.Windows.Forms.Label lbl_Guardian_Name;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Aadhar_No;
        private System.Windows.Forms.Label lbl_Aadhar_No;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Course;
        private System.Windows.Forms.TextBox tb_College_Name;
        private System.Windows.Forms.Label lbl_Student_Address;
        private System.Windows.Forms.Label lbl_Course;
        private System.Windows.Forms.Label lbl_College_Name;
        private System.Windows.Forms.Button btn_Document;
        private System.Windows.Forms.Label lbl_Document;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Relationship;
        private System.Windows.Forms.Label lbl_Relationship;
        private System.Windows.Forms.Button btn_Refresh;
    }
}