﻿namespace Hostel_System
{
    partial class frm_Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.gb_Student_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.lbl_Payment = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gb_Room_Charges = new System.Windows.Forms.GroupBox();
            this.cmb_Duration = new System.Windows.Forms.ComboBox();
            this.cmb_Room_Type = new System.Windows.Forms.ComboBox();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.tb_Charges = new System.Windows.Forms.TextBox();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Deposit = new System.Windows.Forms.Label();
            this.lbl_Duration = new System.Windows.Forms.Label();
            this.lbl_Charges = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmb_Payment_Mode = new System.Windows.Forms.ComboBox();
            this.tb_Remaining_Amt = new System.Windows.Forms.TextBox();
            this.tb_Paying_Amt = new System.Windows.Forms.TextBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.lbl_Payment_Mode = new System.Windows.Forms.Label();
            this.lbl_Remaining_Amt = new System.Windows.Forms.Label();
            this.lbl_Paying_Amt = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.gb_Student_Details.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gb_Room_Charges.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Enabled = false;
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(298, 227);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(303, 38);
            this.tb_Mobile_No.TabIndex = 4;
            // 
            // tb_Name
            // 
            this.tb_Name.Enabled = false;
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(298, 141);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(303, 38);
            this.tb_Name.TabIndex = 2;
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(33, 230);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(160, 36);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(33, 318);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(79, 36);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(33, 142);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(94, 36);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // gb_Student_Details
            // 
            this.gb_Student_Details.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Student_Details.Controls.Add(this.dtp_Date);
            this.gb_Student_Details.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.tb_Name);
            this.gb_Student_Details.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Details.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.lbl_Date);
            this.gb_Student_Details.Controls.Add(this.lbl_Name);
            this.gb_Student_Details.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Details.ForeColor = System.Drawing.Color.DarkMagenta;
            this.gb_Student_Details.Location = new System.Drawing.Point(-6, 143);
            this.gb_Student_Details.Name = "gb_Student_Details";
            this.gb_Student_Details.Size = new System.Drawing.Size(672, 381);
            this.gb_Student_Details.TabIndex = 20;
            this.gb_Student_Details.TabStop = false;
            this.gb_Student_Details.Text = "Student Details";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Enabled = false;
            this.dtp_Date.Location = new System.Drawing.Point(298, 317);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(303, 26);
            this.dtp_Date.TabIndex = 5;
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Enabled = false;
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(298, 54);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Student_Id.TabIndex = 1;
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(33, 54);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(160, 36);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // lbl_Payment
            // 
            this.lbl_Payment.AutoSize = true;
            this.lbl_Payment.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Payment.Location = new System.Drawing.Point(601, 18);
            this.lbl_Payment.Name = "lbl_Payment";
            this.lbl_Payment.Size = new System.Drawing.Size(289, 77);
            this.lbl_Payment.TabIndex = 0;
            this.lbl_Payment.Text = "Payment";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(779, 689);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 63);
            this.btn_Save.TabIndex = 21;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Payment);
            this.panel1.Location = new System.Drawing.Point(-6, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1509, 123);
            this.panel1.TabIndex = 19;
            // 
            // gb_Room_Charges
            // 
            this.gb_Room_Charges.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Room_Charges.Controls.Add(this.cmb_Duration);
            this.gb_Room_Charges.Controls.Add(this.cmb_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.tb_Deposit);
            this.gb_Room_Charges.Controls.Add(this.tb_Charges);
            this.gb_Room_Charges.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.lbl_Deposit);
            this.gb_Room_Charges.Controls.Add(this.lbl_Duration);
            this.gb_Room_Charges.Controls.Add(this.lbl_Charges);
            this.gb_Room_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Charges.ForeColor = System.Drawing.Color.Purple;
            this.gb_Room_Charges.Location = new System.Drawing.Point(690, 143);
            this.gb_Room_Charges.Name = "gb_Room_Charges";
            this.gb_Room_Charges.Size = new System.Drawing.Size(730, 381);
            this.gb_Room_Charges.TabIndex = 0;
            this.gb_Room_Charges.TabStop = false;
            this.gb_Room_Charges.Text = "Room Charges";
            // 
            // cmb_Duration
            // 
            this.cmb_Duration.Enabled = false;
            this.cmb_Duration.FormattingEnabled = true;
            this.cmb_Duration.Items.AddRange(new object[] {
            "Per Sem",
            "Per Year"});
            this.cmb_Duration.Location = new System.Drawing.Point(307, 141);
            this.cmb_Duration.Name = "cmb_Duration";
            this.cmb_Duration.Size = new System.Drawing.Size(303, 28);
            this.cmb_Duration.TabIndex = 6;
            // 
            // cmb_Room_Type
            // 
            this.cmb_Room_Type.FormattingEnabled = true;
            this.cmb_Room_Type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_Room_Type.Location = new System.Drawing.Point(307, 60);
            this.cmb_Room_Type.Name = "cmb_Room_Type";
            this.cmb_Room_Type.Size = new System.Drawing.Size(303, 28);
            this.cmb_Room_Type.TabIndex = 5;
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Deposit.Location = new System.Drawing.Point(307, 312);
            this.tb_Deposit.MaxLength = 10;
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(303, 38);
            this.tb_Deposit.TabIndex = 8;
            // 
            // tb_Charges
            // 
            this.tb_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Charges.Location = new System.Drawing.Point(307, 230);
            this.tb_Charges.MaxLength = 20;
            this.tb_Charges.Name = "tb_Charges";
            this.tb_Charges.Size = new System.Drawing.Size(303, 38);
            this.tb_Charges.TabIndex = 7;
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(33, 57);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(170, 36);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Deposit
            // 
            this.lbl_Deposit.AutoSize = true;
            this.lbl_Deposit.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deposit.ForeColor = System.Drawing.Color.Black;
            this.lbl_Deposit.Location = new System.Drawing.Point(33, 315);
            this.lbl_Deposit.Name = "lbl_Deposit";
            this.lbl_Deposit.Size = new System.Drawing.Size(121, 36);
            this.lbl_Deposit.TabIndex = 0;
            this.lbl_Deposit.Text = "Deposit";
            // 
            // lbl_Duration
            // 
            this.lbl_Duration.AutoSize = true;
            this.lbl_Duration.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Duration.ForeColor = System.Drawing.Color.Black;
            this.lbl_Duration.Location = new System.Drawing.Point(33, 142);
            this.lbl_Duration.Name = "lbl_Duration";
            this.lbl_Duration.Size = new System.Drawing.Size(138, 36);
            this.lbl_Duration.TabIndex = 0;
            this.lbl_Duration.Text = "Duration";
            // 
            // lbl_Charges
            // 
            this.lbl_Charges.AutoSize = true;
            this.lbl_Charges.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Charges.ForeColor = System.Drawing.Color.Black;
            this.lbl_Charges.Location = new System.Drawing.Point(33, 230);
            this.lbl_Charges.Name = "lbl_Charges";
            this.lbl_Charges.Size = new System.Drawing.Size(126, 36);
            this.lbl_Charges.TabIndex = 0;
            this.lbl_Charges.Text = "Charges";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel2.Controls.Add(this.cmb_Payment_Mode);
            this.panel2.Controls.Add(this.tb_Remaining_Amt);
            this.panel2.Controls.Add(this.tb_Paying_Amt);
            this.panel2.Controls.Add(this.tb_Total);
            this.panel2.Controls.Add(this.lbl_Payment_Mode);
            this.panel2.Controls.Add(this.lbl_Remaining_Amt);
            this.panel2.Controls.Add(this.lbl_Paying_Amt);
            this.panel2.Controls.Add(this.lbl_Total);
            this.panel2.Location = new System.Drawing.Point(-6, 530);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1426, 153);
            this.panel2.TabIndex = 23;
            // 
            // cmb_Payment_Mode
            // 
            this.cmb_Payment_Mode.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Payment_Mode.FormattingEnabled = true;
            this.cmb_Payment_Mode.Location = new System.Drawing.Point(983, 83);
            this.cmb_Payment_Mode.MaxLength = 20;
            this.cmb_Payment_Mode.Name = "cmb_Payment_Mode";
            this.cmb_Payment_Mode.Size = new System.Drawing.Size(303, 39);
            this.cmb_Payment_Mode.TabIndex = 12;
            // 
            // tb_Remaining_Amt
            // 
            this.tb_Remaining_Amt.Enabled = false;
            this.tb_Remaining_Amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Remaining_Amt.Location = new System.Drawing.Point(983, 13);
            this.tb_Remaining_Amt.MaxLength = 10;
            this.tb_Remaining_Amt.Name = "tb_Remaining_Amt";
            this.tb_Remaining_Amt.Size = new System.Drawing.Size(303, 38);
            this.tb_Remaining_Amt.TabIndex = 11;
            // 
            // tb_Paying_Amt
            // 
            this.tb_Paying_Amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Paying_Amt.Location = new System.Drawing.Point(298, 90);
            this.tb_Paying_Amt.MaxLength = 10;
            this.tb_Paying_Amt.Name = "tb_Paying_Amt";
            this.tb_Paying_Amt.Size = new System.Drawing.Size(303, 38);
            this.tb_Paying_Amt.TabIndex = 10;
            // 
            // tb_Total
            // 
            this.tb_Total.Enabled = false;
            this.tb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total.Location = new System.Drawing.Point(298, 17);
            this.tb_Total.MaxLength = 10;
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.Size = new System.Drawing.Size(303, 38);
            this.tb_Total.TabIndex = 9;
            // 
            // lbl_Payment_Mode
            // 
            this.lbl_Payment_Mode.AutoSize = true;
            this.lbl_Payment_Mode.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payment_Mode.ForeColor = System.Drawing.Color.Black;
            this.lbl_Payment_Mode.Location = new System.Drawing.Point(709, 87);
            this.lbl_Payment_Mode.Name = "lbl_Payment_Mode";
            this.lbl_Payment_Mode.Size = new System.Drawing.Size(218, 36);
            this.lbl_Payment_Mode.TabIndex = 4;
            this.lbl_Payment_Mode.Text = "Payment Mode";
            // 
            // lbl_Remaining_Amt
            // 
            this.lbl_Remaining_Amt.AutoSize = true;
            this.lbl_Remaining_Amt.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Remaining_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Remaining_Amt.Location = new System.Drawing.Point(709, 17);
            this.lbl_Remaining_Amt.Name = "lbl_Remaining_Amt";
            this.lbl_Remaining_Amt.Size = new System.Drawing.Size(235, 36);
            this.lbl_Remaining_Amt.TabIndex = 0;
            this.lbl_Remaining_Amt.Text = "Remaining Amt.";
            // 
            // lbl_Paying_Amt
            // 
            this.lbl_Paying_Amt.AutoSize = true;
            this.lbl_Paying_Amt.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paying_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paying_Amt.Location = new System.Drawing.Point(69, 88);
            this.lbl_Paying_Amt.Name = "lbl_Paying_Amt";
            this.lbl_Paying_Amt.Size = new System.Drawing.Size(178, 36);
            this.lbl_Paying_Amt.TabIndex = 0;
            this.lbl_Paying_Amt.Text = "Paying Amt.";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.ForeColor = System.Drawing.Color.Black;
            this.lbl_Total.Location = new System.Drawing.Point(69, 14);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(84, 36);
            this.lbl_Total.TabIndex = 1;
            this.lbl_Total.Text = "Total";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Refresh.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(462, 689);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 63);
            this.btn_Refresh.TabIndex = 24;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // frm_Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.gb_Room_Charges);
            this.Controls.Add(this.gb_Student_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Payment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.frm_Payment_Load);
            this.gb_Student_Details.ResumeLayout(false);
            this.gb_Student_Details.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Charges.ResumeLayout(false);
            this.gb_Room_Charges.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.GroupBox gb_Student_Details;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.Label lbl_Payment;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gb_Room_Charges;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.TextBox tb_Charges;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Deposit;
        private System.Windows.Forms.Label lbl_Duration;
        private System.Windows.Forms.Label lbl_Charges;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.ComboBox cmb_Room_Type;
        private System.Windows.Forms.ComboBox cmb_Payment_Mode;
        private System.Windows.Forms.TextBox tb_Remaining_Amt;
        private System.Windows.Forms.TextBox tb_Paying_Amt;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.Label lbl_Payment_Mode;
        private System.Windows.Forms.Label lbl_Remaining_Amt;
        private System.Windows.Forms.Label lbl_Paying_Amt;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.ComboBox cmb_Duration;
        private System.Windows.Forms.Button btn_Refresh;
    }
}