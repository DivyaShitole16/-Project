﻿namespace Hostel_System
{
    partial class frm_Room_Master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Capacity = new System.Windows.Forms.TextBox();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.lbl_Deposit = new System.Windows.Forms.Label();
            this.tb_Room_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Room_Master = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.lbl_Capacity = new System.Windows.Forms.Label();
            this.tb_Charges = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Charges = new System.Windows.Forms.Label();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.tb_Floor = new System.Windows.Forms.TextBox();
            this.tb_Room_Type = new System.Windows.Forms.TextBox();
            this.gb_Room_Master = new System.Windows.Forms.GroupBox();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Room_ID = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gb_Room_Master.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Capacity
            // 
            this.tb_Capacity.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Capacity.Location = new System.Drawing.Point(298, 311);
            this.tb_Capacity.MaxLength = 10;
            this.tb_Capacity.Name = "tb_Capacity";
            this.tb_Capacity.Size = new System.Drawing.Size(303, 38);
            this.tb_Capacity.TabIndex = 3;
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Deposit.Location = new System.Drawing.Point(1038, 307);
            this.tb_Deposit.MaxLength = 10;
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(315, 38);
            this.tb_Deposit.TabIndex = 7;
            // 
            // lbl_Deposit
            // 
            this.lbl_Deposit.AutoSize = true;
            this.lbl_Deposit.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deposit.ForeColor = System.Drawing.Color.Black;
            this.lbl_Deposit.Location = new System.Drawing.Point(721, 311);
            this.lbl_Deposit.Name = "lbl_Deposit";
            this.lbl_Deposit.Size = new System.Drawing.Size(112, 35);
            this.lbl_Deposit.TabIndex = 0;
            this.lbl_Deposit.Text = "Deposit";
            // 
            // tb_Room_Id
            // 
            this.tb_Room_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Id.Location = new System.Drawing.Point(298, 96);
            this.tb_Room_Id.MaxLength = 10;
            this.tb_Room_Id.Name = "tb_Room_Id";
            this.tb_Room_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Room_Id.TabIndex = 1;
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(722, 97);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(144, 35);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Room No.";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_Room_Master);
            this.panel1.Location = new System.Drawing.Point(5, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1495, 107);
            this.panel1.TabIndex = 16;
            // 
            // lbl_Room_Master
            // 
            this.lbl_Room_Master.AutoSize = true;
            this.lbl_Room_Master.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Master.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Master.Location = new System.Drawing.Point(526, 12);
            this.lbl_Room_Master.Name = "lbl_Room_Master";
            this.lbl_Room_Master.Size = new System.Drawing.Size(429, 77);
            this.lbl_Room_Master.TabIndex = 0;
            this.lbl_Room_Master.Text = "Room Master";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Floor.Location = new System.Drawing.Point(33, 427);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(84, 35);
            this.lbl_Floor.TabIndex = 0;
            this.lbl_Floor.Text = "Floor";
            // 
            // lbl_Capacity
            // 
            this.lbl_Capacity.AutoSize = true;
            this.lbl_Capacity.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Capacity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Capacity.Location = new System.Drawing.Point(33, 311);
            this.lbl_Capacity.Name = "lbl_Capacity";
            this.lbl_Capacity.Size = new System.Drawing.Size(127, 35);
            this.lbl_Capacity.TabIndex = 0;
            this.lbl_Capacity.Text = "Capacity";
            // 
            // tb_Charges
            // 
            this.tb_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Charges.Location = new System.Drawing.Point(1038, 203);
            this.tb_Charges.MaxLength = 10;
            this.tb_Charges.Name = "tb_Charges";
            this.tb_Charges.Size = new System.Drawing.Size(315, 38);
            this.tb_Charges.TabIndex = 6;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(620, 697);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 66);
            this.btn_Save.TabIndex = 18;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // lbl_Charges
            // 
            this.lbl_Charges.AutoSize = true;
            this.lbl_Charges.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Charges.ForeColor = System.Drawing.Color.Black;
            this.lbl_Charges.Location = new System.Drawing.Point(721, 204);
            this.lbl_Charges.Name = "lbl_Charges";
            this.lbl_Charges.Size = new System.Drawing.Size(119, 35);
            this.lbl_Charges.TabIndex = 0;
            this.lbl_Charges.Text = "Charges";
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(1038, 94);
            this.tb_Room_No.MaxLength = 10;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(315, 38);
            this.tb_Room_No.TabIndex = 5;
            // 
            // tb_Floor
            // 
            this.tb_Floor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Floor.Location = new System.Drawing.Point(298, 426);
            this.tb_Floor.MaxLength = 20;
            this.tb_Floor.Name = "tb_Floor";
            this.tb_Floor.Size = new System.Drawing.Size(303, 38);
            this.tb_Floor.TabIndex = 4;
            // 
            // tb_Room_Type
            // 
            this.tb_Room_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Type.Location = new System.Drawing.Point(298, 201);
            this.tb_Room_Type.MaxLength = 20;
            this.tb_Room_Type.Name = "tb_Room_Type";
            this.tb_Room_Type.Size = new System.Drawing.Size(303, 38);
            this.tb_Room_Type.TabIndex = 2;
            // 
            // gb_Room_Master
            // 
            this.gb_Room_Master.BackColor = System.Drawing.Color.Lavender;
            this.gb_Room_Master.Controls.Add(this.tb_Capacity);
            this.gb_Room_Master.Controls.Add(this.tb_Deposit);
            this.gb_Room_Master.Controls.Add(this.lbl_Deposit);
            this.gb_Room_Master.Controls.Add(this.tb_Charges);
            this.gb_Room_Master.Controls.Add(this.lbl_Charges);
            this.gb_Room_Master.Controls.Add(this.tb_Room_No);
            this.gb_Room_Master.Controls.Add(this.tb_Floor);
            this.gb_Room_Master.Controls.Add(this.tb_Room_Type);
            this.gb_Room_Master.Controls.Add(this.tb_Room_Id);
            this.gb_Room_Master.Controls.Add(this.lbl_Mobile_No);
            this.gb_Room_Master.Controls.Add(this.lbl_Floor);
            this.gb_Room_Master.Controls.Add(this.lbl_Capacity);
            this.gb_Room_Master.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Master.Controls.Add(this.lbl_Room_ID);
            this.gb_Room_Master.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Master.ForeColor = System.Drawing.Color.Purple;
            this.gb_Room_Master.Location = new System.Drawing.Point(65, 143);
            this.gb_Room_Master.Name = "gb_Room_Master";
            this.gb_Room_Master.Size = new System.Drawing.Size(1379, 552);
            this.gb_Room_Master.TabIndex = 17;
            this.gb_Room_Master.TabStop = false;
            this.gb_Room_Master.Text = "Room Master";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(33, 206);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(160, 35);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Room_ID
            // 
            this.lbl_Room_ID.AutoSize = true;
            this.lbl_Room_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_ID.Location = new System.Drawing.Point(33, 97);
            this.lbl_Room_ID.Name = "lbl_Room_ID";
            this.lbl_Room_ID.Size = new System.Drawing.Size(133, 35);
            this.lbl_Room_ID.TabIndex = 0;
            this.lbl_Room_ID.Text = "Room ID";
            // 
            // frm_Room_Master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1505, 778);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Room_Master);
            this.Name = "frm_Room_Master";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Master";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Master.ResumeLayout(false);
            this.gb_Room_Master.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Capacity;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.Label lbl_Deposit;
        private System.Windows.Forms.TextBox tb_Room_Id;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Room_Master;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.Label lbl_Capacity;
        private System.Windows.Forms.TextBox tb_Charges;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Charges;
        private System.Windows.Forms.TextBox tb_Room_No;
        private System.Windows.Forms.TextBox tb_Floor;
        private System.Windows.Forms.TextBox tb_Room_Type;
        private System.Windows.Forms.GroupBox gb_Room_Master;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Room_ID;
    }
}