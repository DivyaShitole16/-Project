﻿namespace Hostel_System
{
    partial class frm_Expenses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Expenses = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_Type = new System.Windows.Forms.TextBox();
            this.tb_Amount = new System.Windows.Forms.TextBox();
            this.lbl_Paid_By = new System.Windows.Forms.Label();
            this.tb_Paid_By = new System.Windows.Forms.TextBox();
            this.tb_Detail = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Expense_Id = new System.Windows.Forms.TextBox();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Detail = new System.Windows.Forms.Label();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Expense_Id = new System.Windows.Forms.Label();
            this.btn_Browse = new System.Windows.Forms.Button();
            this.lbl_Bill_Image = new System.Windows.Forms.Label();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(623, 701);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 66);
            this.btn_Save.TabIndex = 21;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_Expenses);
            this.panel1.Location = new System.Drawing.Point(-4, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1508, 125);
            this.panel1.TabIndex = 19;
            // 
            // lbl_Expenses
            // 
            this.lbl_Expenses.AutoSize = true;
            this.lbl_Expenses.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Expenses.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Expenses.Location = new System.Drawing.Point(614, 25);
            this.lbl_Expenses.Name = "lbl_Expenses";
            this.lbl_Expenses.Size = new System.Drawing.Size(299, 77);
            this.lbl_Expenses.TabIndex = 0;
            this.lbl_Expenses.Text = "Expenses";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.dtp_Date);
            this.panel2.Controls.Add(this.lbl_Amount);
            this.panel2.Controls.Add(this.btn_Browse);
            this.panel2.Controls.Add(this.lbl_Bill_Image);
            this.panel2.Controls.Add(this.tb_Type);
            this.panel2.Controls.Add(this.tb_Amount);
            this.panel2.Controls.Add(this.lbl_Paid_By);
            this.panel2.Controls.Add(this.tb_Paid_By);
            this.panel2.Controls.Add(this.tb_Detail);
            this.panel2.Controls.Add(this.tb_Name);
            this.panel2.Controls.Add(this.tb_Expense_Id);
            this.panel2.Controls.Add(this.lbl_Date);
            this.panel2.Controls.Add(this.lbl_Detail);
            this.panel2.Controls.Add(this.lbl_Type);
            this.panel2.Controls.Add(this.lbl_Name);
            this.panel2.Controls.Add(this.lbl_Expense_Id);
            this.panel2.Location = new System.Drawing.Point(61, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1379, 493);
            this.panel2.TabIndex = 22;
            // 
            // tb_Type
            // 
            this.tb_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Type.Location = new System.Drawing.Point(262, 275);
            this.tb_Type.MaxLength = 10;
            this.tb_Type.Name = "tb_Type";
            this.tb_Type.Size = new System.Drawing.Size(303, 38);
            this.tb_Type.TabIndex = 3;
            // 
            // tb_Amount
            // 
            this.tb_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Amount.Location = new System.Drawing.Point(1002, 274);
            this.tb_Amount.MaxLength = 10;
            this.tb_Amount.Name = "tb_Amount";
            this.tb_Amount.Size = new System.Drawing.Size(305, 38);
            this.tb_Amount.TabIndex = 7;
            // 
            // lbl_Paid_By
            // 
            this.lbl_Paid_By.AutoSize = true;
            this.lbl_Paid_By.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paid_By.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paid_By.Location = new System.Drawing.Point(685, 168);
            this.lbl_Paid_By.Name = "lbl_Paid_By";
            this.lbl_Paid_By.Size = new System.Drawing.Size(116, 35);
            this.lbl_Paid_By.TabIndex = 0;
            this.lbl_Paid_By.Text = "Paid By";
            // 
            // tb_Paid_By
            // 
            this.tb_Paid_By.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Paid_By.Location = new System.Drawing.Point(1002, 168);
            this.tb_Paid_By.MaxLength = 10;
            this.tb_Paid_By.Name = "tb_Paid_By";
            this.tb_Paid_By.Size = new System.Drawing.Size(305, 38);
            this.tb_Paid_By.TabIndex = 6;
            // 
            // tb_Detail
            // 
            this.tb_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Detail.Location = new System.Drawing.Point(262, 390);
            this.tb_Detail.MaxLength = 50;
            this.tb_Detail.Name = "tb_Detail";
            this.tb_Detail.Size = new System.Drawing.Size(303, 38);
            this.tb_Detail.TabIndex = 4;
            // 
            // tb_Name
            // 
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(262, 165);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(303, 38);
            this.tb_Name.TabIndex = 2;
            // 
            // tb_Expense_Id
            // 
            this.tb_Expense_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Expense_Id.Location = new System.Drawing.Point(262, 60);
            this.tb_Expense_Id.MaxLength = 10;
            this.tb_Expense_Id.Name = "tb_Expense_Id";
            this.tb_Expense_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Expense_Id.TabIndex = 1;
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(686, 61);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(74, 35);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Detail
            // 
            this.lbl_Detail.AutoSize = true;
            this.lbl_Detail.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Detail.ForeColor = System.Drawing.Color.Black;
            this.lbl_Detail.Location = new System.Drawing.Point(17, 393);
            this.lbl_Detail.Name = "lbl_Detail";
            this.lbl_Detail.Size = new System.Drawing.Size(90, 35);
            this.lbl_Detail.TabIndex = 0;
            this.lbl_Detail.Text = "Detail";
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Type.Location = new System.Drawing.Point(17, 277);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(77, 35);
            this.lbl_Type.TabIndex = 0;
            this.lbl_Type.Text = "Type";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(17, 172);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(88, 35);
            this.lbl_Name.TabIndex = 13;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Expense_Id
            // 
            this.lbl_Expense_Id.AutoSize = true;
            this.lbl_Expense_Id.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Expense_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Expense_Id.Location = new System.Drawing.Point(17, 63);
            this.lbl_Expense_Id.Name = "lbl_Expense_Id";
            this.lbl_Expense_Id.Size = new System.Drawing.Size(162, 35);
            this.lbl_Expense_Id.TabIndex = 0;
            this.lbl_Expense_Id.Text = "Expense ID";
            // 
            // btn_Browse
            // 
            this.btn_Browse.BackColor = System.Drawing.Color.LightCyan;
            this.btn_Browse.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse.ForeColor = System.Drawing.Color.MidnightBlue;
            this.btn_Browse.Location = new System.Drawing.Point(1002, 368);
            this.btn_Browse.Name = "btn_Browse";
            this.btn_Browse.Size = new System.Drawing.Size(305, 69);
            this.btn_Browse.TabIndex = 8;
            this.btn_Browse.Text = "Browse Document";
            this.btn_Browse.UseVisualStyleBackColor = false;
            // 
            // lbl_Bill_Image
            // 
            this.lbl_Bill_Image.AutoSize = true;
            this.lbl_Bill_Image.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bill_Image.ForeColor = System.Drawing.Color.Black;
            this.lbl_Bill_Image.Location = new System.Drawing.Point(686, 391);
            this.lbl_Bill_Image.Name = "lbl_Bill_Image";
            this.lbl_Bill_Image.Size = new System.Drawing.Size(146, 35);
            this.lbl_Bill_Image.TabIndex = 23;
            this.lbl_Bill_Image.Text = "Bill Image";
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Amount.ForeColor = System.Drawing.Color.Black;
            this.lbl_Amount.Location = new System.Drawing.Point(686, 278);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(117, 35);
            this.lbl_Amount.TabIndex = 0;
            this.lbl_Amount.Text = "Amount";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1002, 71);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(305, 38);
            this.dtp_Date.TabIndex = 5;
            // 
            // frm_Expenses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1505, 778);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Expenses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Expenses";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Expenses;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Button btn_Browse;
        private System.Windows.Forms.Label lbl_Bill_Image;
        private System.Windows.Forms.TextBox tb_Type;
        private System.Windows.Forms.TextBox tb_Amount;
        private System.Windows.Forms.Label lbl_Paid_By;
        private System.Windows.Forms.TextBox tb_Paid_By;
        private System.Windows.Forms.TextBox tb_Detail;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Expense_Id;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Detail;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Expense_Id;
    }
}