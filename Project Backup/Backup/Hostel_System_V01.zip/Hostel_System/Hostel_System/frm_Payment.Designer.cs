﻿namespace Hostel_System
{
    partial class frm_Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.gb_Student_Information = new System.Windows.Forms.GroupBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.lbl_Payment = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gb_Room_Charges = new System.Windows.Forms.GroupBox();
            this.cmb_Charges = new System.Windows.Forms.ComboBox();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.tb_Amount = new System.Windows.Forms.TextBox();
            this.tb_Duration = new System.Windows.Forms.TextBox();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.lbl_Deposit = new System.Windows.Forms.Label();
            this.lbl_Duration = new System.Windows.Forms.Label();
            this.lbl_Charges = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmb_Payment_Mode = new System.Windows.Forms.ComboBox();
            this.tb_Remaining_Amt = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbl_Payment_Mode = new System.Windows.Forms.Label();
            this.lbl_Remaining_Amt = new System.Windows.Forms.Label();
            this.lbl_Paying_Amt = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.gb_Student_Information.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gb_Room_Charges.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(298, 227);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(303, 38);
            this.tb_Mobile_No.TabIndex = 4;
            // 
            // tb_Name
            // 
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(298, 141);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(303, 38);
            this.tb_Name.TabIndex = 2;
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(33, 232);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(157, 35);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(33, 318);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(74, 35);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(33, 142);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(88, 35);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // gb_Student_Information
            // 
            this.gb_Student_Information.BackColor = System.Drawing.Color.Lavender;
            this.gb_Student_Information.Controls.Add(this.dtp_Date);
            this.gb_Student_Information.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Information.Controls.Add(this.tb_Name);
            this.gb_Student_Information.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Information.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Information.Controls.Add(this.lbl_Date);
            this.gb_Student_Information.Controls.Add(this.lbl_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Information.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Student_Information.Location = new System.Drawing.Point(65, 143);
            this.gb_Student_Information.Name = "gb_Student_Information";
            this.gb_Student_Information.Size = new System.Drawing.Size(654, 397);
            this.gb_Student_Information.TabIndex = 20;
            this.gb_Student_Information.TabStop = false;
            this.gb_Student_Information.Text = "Student Information";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Location = new System.Drawing.Point(298, 317);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(303, 34);
            this.dtp_Date.TabIndex = 5;
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(298, 54);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Student_Id.TabIndex = 1;
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(33, 57);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(156, 35);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // lbl_Payment
            // 
            this.lbl_Payment.AutoSize = true;
            this.lbl_Payment.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Payment.Location = new System.Drawing.Point(642, 27);
            this.lbl_Payment.Name = "lbl_Payment";
            this.lbl_Payment.Size = new System.Drawing.Size(289, 77);
            this.lbl_Payment.TabIndex = 0;
            this.lbl_Payment.Text = "Payment";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Save.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(627, 732);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 89);
            this.btn_Save.TabIndex = 21;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_Payment);
            this.panel1.Location = new System.Drawing.Point(-6, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1509, 123);
            this.panel1.TabIndex = 19;
            // 
            // gb_Room_Charges
            // 
            this.gb_Room_Charges.BackColor = System.Drawing.Color.Lavender;
            this.gb_Room_Charges.Controls.Add(this.cmb_Charges);
            this.gb_Room_Charges.Controls.Add(this.tb_Deposit);
            this.gb_Room_Charges.Controls.Add(this.tb_Amount);
            this.gb_Room_Charges.Controls.Add(this.tb_Duration);
            this.gb_Room_Charges.Controls.Add(this.lbl_Amount);
            this.gb_Room_Charges.Controls.Add(this.lbl_Deposit);
            this.gb_Room_Charges.Controls.Add(this.lbl_Duration);
            this.gb_Room_Charges.Controls.Add(this.lbl_Charges);
            this.gb_Room_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Charges.ForeColor = System.Drawing.Color.Purple;
            this.gb_Room_Charges.Location = new System.Drawing.Point(741, 143);
            this.gb_Room_Charges.Name = "gb_Room_Charges";
            this.gb_Room_Charges.Size = new System.Drawing.Size(665, 397);
            this.gb_Room_Charges.TabIndex = 0;
            this.gb_Room_Charges.TabStop = false;
            this.gb_Room_Charges.Text = "Room Charges";
            // 
            // cmb_Charges
            // 
            this.cmb_Charges.FormattingEnabled = true;
            this.cmb_Charges.Location = new System.Drawing.Point(307, 59);
            this.cmb_Charges.Name = "cmb_Charges";
            this.cmb_Charges.Size = new System.Drawing.Size(303, 37);
            this.cmb_Charges.TabIndex = 5;
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Deposit.Location = new System.Drawing.Point(307, 227);
            this.tb_Deposit.MaxLength = 10;
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(303, 38);
            this.tb_Deposit.TabIndex = 7;
            // 
            // tb_Amount
            // 
            this.tb_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Amount.Location = new System.Drawing.Point(307, 317);
            this.tb_Amount.MaxLength = 10;
            this.tb_Amount.Name = "tb_Amount";
            this.tb_Amount.Size = new System.Drawing.Size(303, 38);
            this.tb_Amount.TabIndex = 8;
            // 
            // tb_Duration
            // 
            this.tb_Duration.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Duration.Location = new System.Drawing.Point(307, 139);
            this.tb_Duration.MaxLength = 20;
            this.tb_Duration.Name = "tb_Duration";
            this.tb_Duration.Size = new System.Drawing.Size(303, 38);
            this.tb_Duration.TabIndex = 6;
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Amount.ForeColor = System.Drawing.Color.Black;
            this.lbl_Amount.Location = new System.Drawing.Point(33, 320);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(117, 35);
            this.lbl_Amount.TabIndex = 0;
            this.lbl_Amount.Text = "Amount";
            // 
            // lbl_Deposit
            // 
            this.lbl_Deposit.AutoSize = true;
            this.lbl_Deposit.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deposit.ForeColor = System.Drawing.Color.Black;
            this.lbl_Deposit.Location = new System.Drawing.Point(33, 230);
            this.lbl_Deposit.Name = "lbl_Deposit";
            this.lbl_Deposit.Size = new System.Drawing.Size(112, 35);
            this.lbl_Deposit.TabIndex = 0;
            this.lbl_Deposit.Text = "Deposit";
            // 
            // lbl_Duration
            // 
            this.lbl_Duration.AutoSize = true;
            this.lbl_Duration.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Duration.ForeColor = System.Drawing.Color.Black;
            this.lbl_Duration.Location = new System.Drawing.Point(33, 142);
            this.lbl_Duration.Name = "lbl_Duration";
            this.lbl_Duration.Size = new System.Drawing.Size(128, 35);
            this.lbl_Duration.TabIndex = 0;
            this.lbl_Duration.Text = "Duration";
            // 
            // lbl_Charges
            // 
            this.lbl_Charges.AutoSize = true;
            this.lbl_Charges.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Charges.ForeColor = System.Drawing.Color.Black;
            this.lbl_Charges.Location = new System.Drawing.Point(33, 57);
            this.lbl_Charges.Name = "lbl_Charges";
            this.lbl_Charges.Size = new System.Drawing.Size(119, 35);
            this.lbl_Charges.TabIndex = 0;
            this.lbl_Charges.Text = "Charges";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.cmb_Payment_Mode);
            this.panel2.Controls.Add(this.tb_Remaining_Amt);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.lbl_Payment_Mode);
            this.panel2.Controls.Add(this.lbl_Remaining_Amt);
            this.panel2.Controls.Add(this.lbl_Paying_Amt);
            this.panel2.Controls.Add(this.lbl_Total);
            this.panel2.Location = new System.Drawing.Point(65, 559);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1341, 137);
            this.panel2.TabIndex = 23;
            // 
            // cmb_Payment_Mode
            // 
            this.cmb_Payment_Mode.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Payment_Mode.FormattingEnabled = true;
            this.cmb_Payment_Mode.Location = new System.Drawing.Point(983, 83);
            this.cmb_Payment_Mode.MaxLength = 20;
            this.cmb_Payment_Mode.Name = "cmb_Payment_Mode";
            this.cmb_Payment_Mode.Size = new System.Drawing.Size(303, 39);
            this.cmb_Payment_Mode.TabIndex = 12;
            // 
            // tb_Remaining_Amt
            // 
            this.tb_Remaining_Amt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Remaining_Amt.Location = new System.Drawing.Point(983, 13);
            this.tb_Remaining_Amt.MaxLength = 10;
            this.tb_Remaining_Amt.Name = "tb_Remaining_Amt";
            this.tb_Remaining_Amt.Size = new System.Drawing.Size(303, 38);
            this.tb_Remaining_Amt.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(298, 86);
            this.textBox1.MaxLength = 10;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(303, 38);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(298, 13);
            this.textBox2.MaxLength = 10;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(303, 38);
            this.textBox2.TabIndex = 9;
            // 
            // lbl_Payment_Mode
            // 
            this.lbl_Payment_Mode.AutoSize = true;
            this.lbl_Payment_Mode.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payment_Mode.ForeColor = System.Drawing.Color.Black;
            this.lbl_Payment_Mode.Location = new System.Drawing.Point(709, 87);
            this.lbl_Payment_Mode.Name = "lbl_Payment_Mode";
            this.lbl_Payment_Mode.Size = new System.Drawing.Size(206, 35);
            this.lbl_Payment_Mode.TabIndex = 4;
            this.lbl_Payment_Mode.Text = "Payment Mode";
            // 
            // lbl_Remaining_Amt
            // 
            this.lbl_Remaining_Amt.AutoSize = true;
            this.lbl_Remaining_Amt.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Remaining_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Remaining_Amt.Location = new System.Drawing.Point(709, 17);
            this.lbl_Remaining_Amt.Name = "lbl_Remaining_Amt";
            this.lbl_Remaining_Amt.Size = new System.Drawing.Size(220, 35);
            this.lbl_Remaining_Amt.TabIndex = 0;
            this.lbl_Remaining_Amt.Text = "Remaining Amt.";
            // 
            // lbl_Paying_Amt
            // 
            this.lbl_Paying_Amt.AutoSize = true;
            this.lbl_Paying_Amt.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paying_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paying_Amt.Location = new System.Drawing.Point(60, 96);
            this.lbl_Paying_Amt.Name = "lbl_Paying_Amt";
            this.lbl_Paying_Amt.Size = new System.Drawing.Size(170, 35);
            this.lbl_Paying_Amt.TabIndex = 0;
            this.lbl_Paying_Amt.Text = "Paying Amt.";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.ForeColor = System.Drawing.Color.Black;
            this.lbl_Total.Location = new System.Drawing.Point(60, 16);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(79, 35);
            this.lbl_Total.TabIndex = 1;
            this.lbl_Total.Text = "Total";
            // 
            // frm_Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1505, 853);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.gb_Room_Charges);
            this.Controls.Add(this.gb_Student_Information);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Payment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payment";
            this.gb_Student_Information.ResumeLayout(false);
            this.gb_Student_Information.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Charges.ResumeLayout(false);
            this.gb_Room_Charges.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.GroupBox gb_Student_Information;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.Label lbl_Payment;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gb_Room_Charges;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.TextBox tb_Amount;
        private System.Windows.Forms.TextBox tb_Duration;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Label lbl_Deposit;
        private System.Windows.Forms.Label lbl_Duration;
        private System.Windows.Forms.Label lbl_Charges;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.ComboBox cmb_Charges;
        private System.Windows.Forms.ComboBox cmb_Payment_Mode;
        private System.Windows.Forms.TextBox tb_Remaining_Amt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbl_Payment_Mode;
        private System.Windows.Forms.Label lbl_Remaining_Amt;
        private System.Windows.Forms.Label lbl_Paying_Amt;
        private System.Windows.Forms.Label lbl_Total;
    }
}