﻿namespace Hostel_System
{
    partial class frm_Room_Reallotment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_Allocation_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_New_Room_Type = new System.Windows.Forms.Label();
            this.lbl_New_Room_No = new System.Windows.Forms.Label();
            this.tb_Room_Type = new System.Windows.Forms.TextBox();
            this.tb_New_Room_Type = new System.Windows.Forms.TextBox();
            this.lbl_New_Room_Id = new System.Windows.Forms.Label();
            this.tb_New_Room_Id = new System.Windows.Forms.TextBox();
            this.tb_Detail = new System.Windows.Forms.TextBox();
            this.tb_Room_Id = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Allocation_Date = new System.Windows.Forms.Label();
            this.lbl_Room_Id = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Student_Id = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_New_Room_No = new System.Windows.Forms.TextBox();
            this.lbl_Room_Reallotment = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Allocation_Date
            // 
            this.dtp_Allocation_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Allocation_Date.Location = new System.Drawing.Point(1002, 57);
            this.dtp_Allocation_Date.Name = "dtp_Allocation_Date";
            this.dtp_Allocation_Date.Size = new System.Drawing.Size(305, 38);
            this.dtp_Allocation_Date.TabIndex = 5;
            // 
            // lbl_New_Room_Type
            // 
            this.lbl_New_Room_Type.AutoSize = true;
            this.lbl_New_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_Type.Location = new System.Drawing.Point(686, 278);
            this.lbl_New_Room_Type.Name = "lbl_New_Room_Type";
            this.lbl_New_Room_Type.Size = new System.Drawing.Size(224, 35);
            this.lbl_New_Room_Type.TabIndex = 0;
            this.lbl_New_Room_Type.Text = "New Room Type";
            // 
            // lbl_New_Room_No
            // 
            this.lbl_New_Room_No.AutoSize = true;
            this.lbl_New_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_No.Location = new System.Drawing.Point(686, 391);
            this.lbl_New_Room_No.Name = "lbl_New_Room_No";
            this.lbl_New_Room_No.Size = new System.Drawing.Size(200, 35);
            this.lbl_New_Room_No.TabIndex = 0;
            this.lbl_New_Room_No.Text = "New Room No";
            // 
            // tb_Room_Type
            // 
            this.tb_Room_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Type.Location = new System.Drawing.Point(262, 275);
            this.tb_Room_Type.MaxLength = 10;
            this.tb_Room_Type.Name = "tb_Room_Type";
            this.tb_Room_Type.Size = new System.Drawing.Size(303, 38);
            this.tb_Room_Type.TabIndex = 3;
            // 
            // tb_New_Room_Type
            // 
            this.tb_New_Room_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_New_Room_Type.Location = new System.Drawing.Point(1002, 274);
            this.tb_New_Room_Type.MaxLength = 10;
            this.tb_New_Room_Type.Name = "tb_New_Room_Type";
            this.tb_New_Room_Type.Size = new System.Drawing.Size(305, 38);
            this.tb_New_Room_Type.TabIndex = 7;
            // 
            // lbl_New_Room_Id
            // 
            this.lbl_New_Room_Id.AutoSize = true;
            this.lbl_New_Room_Id.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_Id.Location = new System.Drawing.Point(686, 172);
            this.lbl_New_Room_Id.Name = "lbl_New_Room_Id";
            this.lbl_New_Room_Id.Size = new System.Drawing.Size(192, 35);
            this.lbl_New_Room_Id.TabIndex = 0;
            this.lbl_New_Room_Id.Text = "New Room Id";
            // 
            // tb_New_Room_Id
            // 
            this.tb_New_Room_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_New_Room_Id.Location = new System.Drawing.Point(1002, 168);
            this.tb_New_Room_Id.MaxLength = 10;
            this.tb_New_Room_Id.Name = "tb_New_Room_Id";
            this.tb_New_Room_Id.Size = new System.Drawing.Size(305, 38);
            this.tb_New_Room_Id.TabIndex = 6;
            // 
            // tb_Detail
            // 
            this.tb_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Detail.Location = new System.Drawing.Point(262, 390);
            this.tb_Detail.MaxLength = 10;
            this.tb_Detail.Name = "tb_Detail";
            this.tb_Detail.Size = new System.Drawing.Size(303, 38);
            this.tb_Detail.TabIndex = 4;
            // 
            // tb_Room_Id
            // 
            this.tb_Room_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Id.Location = new System.Drawing.Point(262, 165);
            this.tb_Room_Id.MaxLength = 10;
            this.tb_Room_Id.Name = "tb_Room_Id";
            this.tb_Room_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Room_Id.TabIndex = 2;
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(262, 60);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Student_Id.TabIndex = 1;
            // 
            // lbl_Allocation_Date
            // 
            this.lbl_Allocation_Date.AutoSize = true;
            this.lbl_Allocation_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Allocation_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Allocation_Date.Location = new System.Drawing.Point(686, 61);
            this.lbl_Allocation_Date.Name = "lbl_Allocation_Date";
            this.lbl_Allocation_Date.Size = new System.Drawing.Size(216, 35);
            this.lbl_Allocation_Date.TabIndex = 0;
            this.lbl_Allocation_Date.Text = " Allocation Date";
            // 
            // lbl_Room_Id
            // 
            this.lbl_Room_Id.AutoSize = true;
            this.lbl_Room_Id.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Id.Location = new System.Drawing.Point(17, 172);
            this.lbl_Room_Id.Name = "lbl_Room_Id";
            this.lbl_Room_Id.Size = new System.Drawing.Size(133, 35);
            this.lbl_Room_Id.TabIndex = 0;
            this.lbl_Room_Id.Text = "Room ID";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(651, 700);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 66);
            this.btn_Save.TabIndex = 24;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(17, 393);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(144, 35);
            this.lbl_Room_No.TabIndex = 0;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(17, 277);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(168, 35);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = " Room Type";
            // 
            // lbl_Student_Id
            // 
            this.lbl_Student_Id.AutoSize = true;
            this.lbl_Student_Id.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Id.Location = new System.Drawing.Point(17, 63);
            this.lbl_Student_Id.Name = "lbl_Student_Id";
            this.lbl_Student_Id.Size = new System.Drawing.Size(156, 35);
            this.lbl_Student_Id.TabIndex = 0;
            this.lbl_Student_Id.Text = "Student ID";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.tb_New_Room_No);
            this.panel2.Controls.Add(this.dtp_Allocation_Date);
            this.panel2.Controls.Add(this.lbl_New_Room_Type);
            this.panel2.Controls.Add(this.lbl_New_Room_No);
            this.panel2.Controls.Add(this.tb_Room_Type);
            this.panel2.Controls.Add(this.tb_New_Room_Type);
            this.panel2.Controls.Add(this.lbl_New_Room_Id);
            this.panel2.Controls.Add(this.tb_New_Room_Id);
            this.panel2.Controls.Add(this.tb_Detail);
            this.panel2.Controls.Add(this.tb_Room_Id);
            this.panel2.Controls.Add(this.tb_Student_Id);
            this.panel2.Controls.Add(this.lbl_Allocation_Date);
            this.panel2.Controls.Add(this.lbl_Room_No);
            this.panel2.Controls.Add(this.lbl_Room_Type);
            this.panel2.Controls.Add(this.lbl_Room_Id);
            this.panel2.Controls.Add(this.lbl_Student_Id);
            this.panel2.Location = new System.Drawing.Point(63, 180);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1379, 493);
            this.panel2.TabIndex = 25;
            // 
            // tb_New_Room_No
            // 
            this.tb_New_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_New_Room_No.Location = new System.Drawing.Point(1002, 388);
            this.tb_New_Room_No.MaxLength = 10;
            this.tb_New_Room_No.Name = "tb_New_Room_No";
            this.tb_New_Room_No.Size = new System.Drawing.Size(305, 38);
            this.tb_New_Room_No.TabIndex = 8;
            // 
            // lbl_Room_Reallotment
            // 
            this.lbl_Room_Reallotment.AutoSize = true;
            this.lbl_Room_Reallotment.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Reallotment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Reallotment.Location = new System.Drawing.Point(505, 24);
            this.lbl_Room_Reallotment.Name = "lbl_Room_Reallotment";
            this.lbl_Room_Reallotment.Size = new System.Drawing.Size(574, 77);
            this.lbl_Room_Reallotment.TabIndex = 0;
            this.lbl_Room_Reallotment.Text = "Room Reallotment";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.lbl_Room_Reallotment);
            this.panel1.Location = new System.Drawing.Point(-2, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1508, 125);
            this.panel1.TabIndex = 23;
            // 
            // frm_Room_Reallotment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1505, 778);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Room_Reallotment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Reallotment";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Allocation_Date;
        private System.Windows.Forms.Label lbl_New_Room_Type;
        private System.Windows.Forms.Label lbl_New_Room_No;
        private System.Windows.Forms.TextBox tb_Room_Type;
        private System.Windows.Forms.TextBox tb_New_Room_Type;
        private System.Windows.Forms.Label lbl_New_Room_Id;
        private System.Windows.Forms.TextBox tb_New_Room_Id;
        private System.Windows.Forms.TextBox tb_Detail;
        private System.Windows.Forms.TextBox tb_Room_Id;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Allocation_Date;
        private System.Windows.Forms.Label lbl_Room_Id;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Student_Id;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tb_New_Room_No;
        private System.Windows.Forms.Label lbl_Room_Reallotment;
        private System.Windows.Forms.Panel panel1;
    }
}