﻿namespace Hostel_System
{
    partial class Room_Charges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Room_Charges_Setting = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_Room_Charges = new System.Windows.Forms.GroupBox();
            this.lbl_Per_Sem1 = new System.Windows.Forms.Label();
            this.lbl_Per_Sem = new System.Windows.Forms.Label();
            this.cmb_Room_Type = new System.Windows.Forms.ComboBox();
            this.tb_Charges = new System.Windows.Forms.TextBox();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.lbl_Deposit = new System.Windows.Forms.Label();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Charges = new System.Windows.Forms.Label();
            this.dgv_Charges = new System.Windows.Forms.DataGridView();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.gb_Room_Charges.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Charges)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(448, 664);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 77);
            this.btn_Refresh.TabIndex = 23;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.dtp_Date);
            this.panel1.Controls.Add(this.lbl_Room_Charges_Setting);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1430, 122);
            this.panel1.TabIndex = 20;
            // 
            // lbl_Room_Charges_Setting
            // 
            this.lbl_Room_Charges_Setting.AutoSize = true;
            this.lbl_Room_Charges_Setting.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Charges_Setting.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Charges_Setting.Location = new System.Drawing.Point(389, 20);
            this.lbl_Room_Charges_Setting.Name = "lbl_Room_Charges_Setting";
            this.lbl_Room_Charges_Setting.Size = new System.Drawing.Size(684, 77);
            this.lbl_Room_Charges_Setting.TabIndex = 0;
            this.lbl_Room_Charges_Setting.Text = "Room Charges Setting";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(736, 664);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 77);
            this.btn_Save.TabIndex = 22;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // gb_Room_Charges
            // 
            this.gb_Room_Charges.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Room_Charges.Controls.Add(this.lbl_Per_Sem1);
            this.gb_Room_Charges.Controls.Add(this.lbl_Per_Sem);
            this.gb_Room_Charges.Controls.Add(this.cmb_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.tb_Charges);
            this.gb_Room_Charges.Controls.Add(this.tb_Room_No);
            this.gb_Room_Charges.Controls.Add(this.lbl_Deposit);
            this.gb_Room_Charges.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.lbl_Charges);
            this.gb_Room_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Charges.ForeColor = System.Drawing.Color.Indigo;
            this.gb_Room_Charges.Location = new System.Drawing.Point(0, 163);
            this.gb_Room_Charges.Name = "gb_Room_Charges";
            this.gb_Room_Charges.Size = new System.Drawing.Size(616, 459);
            this.gb_Room_Charges.TabIndex = 21;
            this.gb_Room_Charges.TabStop = false;
            this.gb_Room_Charges.Text = "Charges";
            // 
            // lbl_Per_Sem1
            // 
            this.lbl_Per_Sem1.AutoSize = true;
            this.lbl_Per_Sem1.Font = new System.Drawing.Font("Marlett", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Per_Sem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl_Per_Sem1.Location = new System.Drawing.Point(98, 363);
            this.lbl_Per_Sem1.Name = "lbl_Per_Sem1";
            this.lbl_Per_Sem1.Size = new System.Drawing.Size(100, 22);
            this.lbl_Per_Sem1.TabIndex = 5;
            this.lbl_Per_Sem1.Text = "(Per Sem)";
            // 
            // lbl_Per_Sem
            // 
            this.lbl_Per_Sem.AutoSize = true;
            this.lbl_Per_Sem.Font = new System.Drawing.Font("Marlett", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Per_Sem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.lbl_Per_Sem.Location = new System.Drawing.Point(98, 245);
            this.lbl_Per_Sem.Name = "lbl_Per_Sem";
            this.lbl_Per_Sem.Size = new System.Drawing.Size(100, 22);
            this.lbl_Per_Sem.TabIndex = 4;
            this.lbl_Per_Sem.Text = "(Per Sem)";
            // 
            // cmb_Room_Type
            // 
            this.cmb_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_Type.FormattingEnabled = true;
            this.cmb_Room_Type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_Room_Type.Location = new System.Drawing.Point(296, 82);
            this.cmb_Room_Type.Name = "cmb_Room_Type";
            this.cmb_Room_Type.Size = new System.Drawing.Size(221, 43);
            this.cmb_Room_Type.TabIndex = 1;
            // 
            // tb_Charges
            // 
            this.tb_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Charges.Location = new System.Drawing.Point(296, 312);
            this.tb_Charges.MaxLength = 5;
            this.tb_Charges.Name = "tb_Charges";
            this.tb_Charges.Size = new System.Drawing.Size(221, 38);
            this.tb_Charges.TabIndex = 3;
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(296, 198);
            this.tb_Room_No.MaxLength = 5;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(221, 38);
            this.tb_Room_No.TabIndex = 2;
            // 
            // lbl_Deposit
            // 
            this.lbl_Deposit.AutoSize = true;
            this.lbl_Deposit.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deposit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Deposit.Location = new System.Drawing.Point(12, 198);
            this.lbl_Deposit.Name = "lbl_Deposit";
            this.lbl_Deposit.Size = new System.Drawing.Size(121, 36);
            this.lbl_Deposit.TabIndex = 0;
            this.lbl_Deposit.Text = "Deposit";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Type.Location = new System.Drawing.Point(12, 89);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(170, 36);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Charges
            // 
            this.lbl_Charges.AutoSize = true;
            this.lbl_Charges.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Charges.ForeColor = System.Drawing.Color.Black;
            this.lbl_Charges.Location = new System.Drawing.Point(12, 314);
            this.lbl_Charges.Name = "lbl_Charges";
            this.lbl_Charges.Size = new System.Drawing.Size(126, 36);
            this.lbl_Charges.TabIndex = 0;
            this.lbl_Charges.Text = "Charges";
            // 
            // dgv_Charges
            // 
            this.dgv_Charges.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Charges.Location = new System.Drawing.Point(655, 163);
            this.dgv_Charges.Name = "dgv_Charges";
            this.dgv_Charges.RowTemplate.Height = 24;
            this.dgv_Charges.Size = new System.Drawing.Size(775, 459);
            this.dgv_Charges.TabIndex = 24;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1180, 89);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(208, 30);
            this.dtp_Date.TabIndex = 25;
            // 
            // Room_Charges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1430, 753);
            this.ControlBox = false;
            this.Controls.Add(this.dgv_Charges);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gb_Room_Charges);
            this.Controls.Add(this.btn_Save);
            this.Name = "Room_Charges";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Charges Setting";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Charges.ResumeLayout(false);
            this.gb_Room_Charges.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Charges)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Room_Charges_Setting;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.GroupBox gb_Room_Charges;
        private System.Windows.Forms.TextBox tb_Charges;
        private System.Windows.Forms.TextBox tb_Room_No;
        private System.Windows.Forms.Label lbl_Deposit;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Charges;
        private System.Windows.Forms.DataGridView dgv_Charges;
        private System.Windows.Forms.ComboBox cmb_Room_Type;
        private System.Windows.Forms.Label lbl_Per_Sem1;
        private System.Windows.Forms.Label lbl_Per_Sem;
        private System.Windows.Forms.DateTimePicker dtp_Date;
    }
}