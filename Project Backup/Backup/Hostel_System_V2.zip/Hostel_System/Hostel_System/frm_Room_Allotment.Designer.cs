﻿namespace Hostel_System
{
    partial class frm_Room_Allotment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Room_Allotment = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gb_Room_Details = new System.Windows.Forms.GroupBox();
            this.tb_Vacancy = new System.Windows.Forms.TextBox();
            this.cmb_Floor = new System.Windows.Forms.ComboBox();
            this.cmb_Room_Type = new System.Windows.Forms.ComboBox();
            this.lbl_Vacancy = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.gb_Student_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.gb_Room_Details.SuspendLayout();
            this.gb_Student_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(748, 649);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 69);
            this.btn_Save.TabIndex = 24;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // lbl_Room_Allotment
            // 
            this.lbl_Room_Allotment.AutoSize = true;
            this.lbl_Room_Allotment.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Room_Allotment.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Allotment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Allotment.Location = new System.Drawing.Point(496, 19);
            this.lbl_Room_Allotment.Name = "lbl_Room_Allotment";
            this.lbl_Room_Allotment.Size = new System.Drawing.Size(506, 77);
            this.lbl_Room_Allotment.TabIndex = 0;
            this.lbl_Room_Allotment.Text = "Room Allotment";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Room_Allotment);
            this.panel1.Location = new System.Drawing.Point(-2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1508, 111);
            this.panel1.TabIndex = 23;
            // 
            // gb_Room_Details
            // 
            this.gb_Room_Details.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Room_Details.Controls.Add(this.tb_Room_No);
            this.gb_Room_Details.Controls.Add(this.tb_Vacancy);
            this.gb_Room_Details.Controls.Add(this.cmb_Floor);
            this.gb_Room_Details.Controls.Add(this.cmb_Room_Type);
            this.gb_Room_Details.Controls.Add(this.lbl_Vacancy);
            this.gb_Room_Details.Controls.Add(this.lbl_Floor);
            this.gb_Room_Details.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Details.Controls.Add(this.lbl_Room_No);
            this.gb_Room_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Details.ForeColor = System.Drawing.Color.Purple;
            this.gb_Room_Details.Location = new System.Drawing.Point(700, 136);
            this.gb_Room_Details.Name = "gb_Room_Details";
            this.gb_Room_Details.Size = new System.Drawing.Size(737, 458);
            this.gb_Room_Details.TabIndex = 25;
            this.gb_Room_Details.TabStop = false;
            this.gb_Room_Details.Text = "Room Details";
            // 
            // tb_Vacancy
            // 
            this.tb_Vacancy.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Vacancy.Location = new System.Drawing.Point(307, 349);
            this.tb_Vacancy.MaxLength = 20;
            this.tb_Vacancy.Name = "tb_Vacancy";
            this.tb_Vacancy.Size = new System.Drawing.Size(303, 42);
            this.tb_Vacancy.TabIndex = 8;
            // 
            // cmb_Floor
            // 
            this.cmb_Floor.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Floor.FormattingEnabled = true;
            this.cmb_Floor.Items.AddRange(new object[] {
            "1 st Floor",
            "2 nd Floor"});
            this.cmb_Floor.Location = new System.Drawing.Point(307, 51);
            this.cmb_Floor.Name = "cmb_Floor";
            this.cmb_Floor.Size = new System.Drawing.Size(303, 43);
            this.cmb_Floor.TabIndex = 5;
            // 
            // cmb_Room_Type
            // 
            this.cmb_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_Type.FormattingEnabled = true;
            this.cmb_Room_Type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_Room_Type.Location = new System.Drawing.Point(307, 152);
            this.cmb_Room_Type.Name = "cmb_Room_Type";
            this.cmb_Room_Type.Size = new System.Drawing.Size(303, 43);
            this.cmb_Room_Type.TabIndex = 6;
            // 
            // lbl_Vacancy
            // 
            this.lbl_Vacancy.AutoSize = true;
            this.lbl_Vacancy.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vacancy.ForeColor = System.Drawing.Color.Black;
            this.lbl_Vacancy.Location = new System.Drawing.Point(33, 357);
            this.lbl_Vacancy.Name = "lbl_Vacancy";
            this.lbl_Vacancy.Size = new System.Drawing.Size(117, 35);
            this.lbl_Vacancy.TabIndex = 0;
            this.lbl_Vacancy.Text = "Vacancy";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Floor.Location = new System.Drawing.Point(42, 59);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(84, 35);
            this.lbl_Floor.TabIndex = 0;
            this.lbl_Floor.Text = "Floor";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(33, 155);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(160, 35);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(33, 257);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(144, 35);
            this.lbl_Room_No.TabIndex = 0;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // gb_Student_Details
            // 
            this.gb_Student_Details.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Student_Details.Controls.Add(this.dtp_Date);
            this.gb_Student_Details.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.tb_Name);
            this.gb_Student_Details.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Details.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.lbl_Date);
            this.gb_Student_Details.Controls.Add(this.lbl_Name);
            this.gb_Student_Details.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Details.ForeColor = System.Drawing.Color.Purple;
            this.gb_Student_Details.Location = new System.Drawing.Point(-2, 136);
            this.gb_Student_Details.Name = "gb_Student_Details";
            this.gb_Student_Details.Size = new System.Drawing.Size(665, 458);
            this.gb_Student_Details.TabIndex = 26;
            this.gb_Student_Details.TabStop = false;
            this.gb_Student_Details.Text = "Student Details";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(298, 353);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(303, 38);
            this.dtp_Date.TabIndex = 5;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(298, 254);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(303, 38);
            this.tb_Mobile_No.TabIndex = 4;
            this.tb_Mobile_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Name
            // 
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(298, 152);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(303, 38);
            this.tb_Name.TabIndex = 2;
            this.tb_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(298, 56);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Student_Id.TabIndex = 1;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(33, 255);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(157, 35);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(33, 356);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(74, 35);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(33, 153);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(88, 35);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(33, 57);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(156, 35);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(426, 649);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 69);
            this.btn_Refresh.TabIndex = 28;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(307, 252);
            this.tb_Room_No.MaxLength = 5;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(303, 42);
            this.tb_Room_No.TabIndex = 9;
            // 
            // frm_Room_Allotment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.gb_Room_Details);
            this.Controls.Add(this.gb_Student_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Room_Allotment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Allotment";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Details.ResumeLayout(false);
            this.gb_Room_Details.PerformLayout();
            this.gb_Student_Details.ResumeLayout(false);
            this.gb_Student_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Room_Allotment;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gb_Room_Details;
        private System.Windows.Forms.ComboBox cmb_Room_Type;
        private System.Windows.Forms.Label lbl_Vacancy;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.GroupBox gb_Student_Details;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.TextBox tb_Vacancy;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.ComboBox cmb_Floor;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.TextBox tb_Room_No;
    }
}