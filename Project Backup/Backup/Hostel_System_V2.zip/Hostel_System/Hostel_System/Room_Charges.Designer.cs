﻿namespace Hostel_System
{
    partial class Room_Charges
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Room_Charges = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_Room_Charges = new System.Windows.Forms.GroupBox();
            this.tb_Room_Type = new System.Windows.Forms.TextBox();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.lbl_Capacity = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dgv_Charges = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.gb_Room_Charges.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Charges)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(359, 662);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 77);
            this.btn_Refresh.TabIndex = 23;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Room_Charges);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1432, 119);
            this.panel1.TabIndex = 20;
            // 
            // lbl_Room_Charges
            // 
            this.lbl_Room_Charges.AutoSize = true;
            this.lbl_Room_Charges.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_Room_Charges.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Charges.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Charges.Location = new System.Drawing.Point(477, 22);
            this.lbl_Room_Charges.Name = "lbl_Room_Charges";
            this.lbl_Room_Charges.Size = new System.Drawing.Size(464, 79);
            this.lbl_Room_Charges.TabIndex = 0;
            this.lbl_Room_Charges.Text = "Room Charges";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(718, 662);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 77);
            this.btn_Save.TabIndex = 22;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            // 
            // gb_Room_Charges
            // 
            this.gb_Room_Charges.BackColor = System.Drawing.Color.LavenderBlush;
            this.gb_Room_Charges.Controls.Add(this.textBox1);
            this.gb_Room_Charges.Controls.Add(this.tb_Room_No);
            this.gb_Room_Charges.Controls.Add(this.tb_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.lbl_Floor);
            this.gb_Room_Charges.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Charges.Controls.Add(this.lbl_Capacity);
            this.gb_Room_Charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Charges.ForeColor = System.Drawing.Color.Indigo;
            this.gb_Room_Charges.Location = new System.Drawing.Point(0, 163);
            this.gb_Room_Charges.Name = "gb_Room_Charges";
            this.gb_Room_Charges.Size = new System.Drawing.Size(576, 459);
            this.gb_Room_Charges.TabIndex = 21;
            this.gb_Room_Charges.TabStop = false;
            this.gb_Room_Charges.Text = "Charges";
            // 
            // tb_Room_Type
            // 
            this.tb_Room_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Type.Location = new System.Drawing.Point(286, 59);
            this.tb_Room_Type.MaxLength = 10;
            this.tb_Room_Type.Name = "tb_Room_Type";
            this.tb_Room_Type.Size = new System.Drawing.Size(186, 38);
            this.tb_Room_Type.TabIndex = 1;
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(286, 153);
            this.tb_Room_No.MaxLength = 5;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(186, 38);
            this.tb_Room_No.TabIndex = 32;
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Room_Type.Location = new System.Drawing.Point(12, 61);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(170, 36);
            this.lbl_Room_Type.TabIndex = 0;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Floor.Location = new System.Drawing.Point(12, 164);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(89, 36);
            this.lbl_Floor.TabIndex = 24;
            this.lbl_Floor.Text = "Floor";
            // 
            // lbl_Capacity
            // 
            this.lbl_Capacity.AutoSize = true;
            this.lbl_Capacity.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Capacity.ForeColor = System.Drawing.Color.Black;
            this.lbl_Capacity.Location = new System.Drawing.Point(12, 259);
            this.lbl_Capacity.Name = "lbl_Capacity";
            this.lbl_Capacity.Size = new System.Drawing.Size(132, 36);
            this.lbl_Capacity.TabIndex = 26;
            this.lbl_Capacity.Text = "Capacity";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(286, 259);
            this.textBox1.MaxLength = 5;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 38);
            this.textBox1.TabIndex = 34;
            // 
            // dgv_Charges
            // 
            this.dgv_Charges.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Charges.Location = new System.Drawing.Point(650, 163);
            this.dgv_Charges.Name = "dgv_Charges";
            this.dgv_Charges.RowTemplate.Height = 24;
            this.dgv_Charges.Size = new System.Drawing.Size(757, 459);
            this.dgv_Charges.TabIndex = 24;
            // 
            // Room_Charges
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.dgv_Charges);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gb_Room_Charges);
            this.Controls.Add(this.btn_Save);
            this.Name = "Room_Charges";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Charges";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Charges.ResumeLayout(false);
            this.gb_Room_Charges.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Charges)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Room_Charges;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.GroupBox gb_Room_Charges;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox tb_Room_No;
        private System.Windows.Forms.TextBox tb_Room_Type;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Capacity;
        private System.Windows.Forms.DataGridView dgv_Charges;
    }
}