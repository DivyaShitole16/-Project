﻿namespace Hostel_System
{
    partial class frm_Expenses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Expenses = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmb_Paid_By = new System.Windows.Forms.ComboBox();
            this.cmb_Type = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Amount = new System.Windows.Forms.Label();
            this.lbl_Bill_Image = new System.Windows.Forms.Label();
            this.tb_Amount = new System.Windows.Forms.TextBox();
            this.lbl_Paid_By = new System.Windows.Forms.Label();
            this.tb_Detail = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Expense_Id = new System.Windows.Forms.TextBox();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Detail = new System.Windows.Forms.Label();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Expense_Id = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.Location = new System.Drawing.Point(672, 658);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 75);
            this.btn_Save.TabIndex = 21;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumVioletRed;
            this.panel1.Controls.Add(this.lbl_Expenses);
            this.panel1.Location = new System.Drawing.Point(-4, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1508, 125);
            this.panel1.TabIndex = 19;
            // 
            // lbl_Expenses
            // 
            this.lbl_Expenses.AutoSize = true;
            this.lbl_Expenses.Font = new System.Drawing.Font("Times New Roman", 40.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Expenses.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_Expenses.Location = new System.Drawing.Point(598, 26);
            this.lbl_Expenses.Name = "lbl_Expenses";
            this.lbl_Expenses.Size = new System.Drawing.Size(299, 77);
            this.lbl_Expenses.TabIndex = 0;
            this.lbl_Expenses.Text = "Expenses";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel2.Controls.Add(this.cmb_Paid_By);
            this.panel2.Controls.Add(this.cmb_Type);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.dtp_Date);
            this.panel2.Controls.Add(this.lbl_Amount);
            this.panel2.Controls.Add(this.lbl_Bill_Image);
            this.panel2.Controls.Add(this.tb_Amount);
            this.panel2.Controls.Add(this.lbl_Paid_By);
            this.panel2.Controls.Add(this.tb_Detail);
            this.panel2.Controls.Add(this.tb_Name);
            this.panel2.Controls.Add(this.tb_Expense_Id);
            this.panel2.Controls.Add(this.lbl_Date);
            this.panel2.Controls.Add(this.lbl_Detail);
            this.panel2.Controls.Add(this.lbl_Type);
            this.panel2.Controls.Add(this.lbl_Name);
            this.panel2.Controls.Add(this.lbl_Expense_Id);
            this.panel2.Location = new System.Drawing.Point(-4, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1444, 468);
            this.panel2.TabIndex = 22;
            // 
            // cmb_Paid_By
            // 
            this.cmb_Paid_By.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Paid_By.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Paid_By.FormattingEnabled = true;
            this.cmb_Paid_By.Items.AddRange(new object[] {
            "Admin",
            "Warden",
            "Watchman"});
            this.cmb_Paid_By.Location = new System.Drawing.Point(968, 167);
            this.cmb_Paid_By.Name = "cmb_Paid_By";
            this.cmb_Paid_By.Size = new System.Drawing.Size(305, 39);
            this.cmb_Paid_By.TabIndex = 26;
            // 
            // cmb_Type
            // 
            this.cmb_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Type.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Type.FormattingEnabled = true;
            this.cmb_Type.Items.AddRange(new object[] {
            "Light Bill",
            "Water Bill",
            "Transport",
            "Cleaning",
            "others"});
            this.cmb_Type.Location = new System.Drawing.Point(262, 273);
            this.cmb_Type.Name = "cmb_Type";
            this.cmb_Type.Size = new System.Drawing.Size(303, 39);
            this.cmb_Type.TabIndex = 25;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(968, 340);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(305, 116);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(968, 57);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(305, 38);
            this.dtp_Date.TabIndex = 5;
            // 
            // lbl_Amount
            // 
            this.lbl_Amount.AutoSize = true;
            this.lbl_Amount.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Amount.ForeColor = System.Drawing.Color.Black;
            this.lbl_Amount.Location = new System.Drawing.Point(686, 278);
            this.lbl_Amount.Name = "lbl_Amount";
            this.lbl_Amount.Size = new System.Drawing.Size(126, 36);
            this.lbl_Amount.TabIndex = 0;
            this.lbl_Amount.Text = "Amount";
            // 
            // lbl_Bill_Image
            // 
            this.lbl_Bill_Image.AutoSize = true;
            this.lbl_Bill_Image.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Bill_Image.ForeColor = System.Drawing.Color.Black;
            this.lbl_Bill_Image.Location = new System.Drawing.Point(686, 391);
            this.lbl_Bill_Image.Name = "lbl_Bill_Image";
            this.lbl_Bill_Image.Size = new System.Drawing.Size(154, 36);
            this.lbl_Bill_Image.TabIndex = 23;
            this.lbl_Bill_Image.Text = "Bill Image";
            // 
            // tb_Amount
            // 
            this.tb_Amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Amount.Location = new System.Drawing.Point(968, 271);
            this.tb_Amount.MaxLength = 10;
            this.tb_Amount.Name = "tb_Amount";
            this.tb_Amount.Size = new System.Drawing.Size(305, 38);
            this.tb_Amount.TabIndex = 7;
            // 
            // lbl_Paid_By
            // 
            this.lbl_Paid_By.AutoSize = true;
            this.lbl_Paid_By.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paid_By.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paid_By.Location = new System.Drawing.Point(686, 168);
            this.lbl_Paid_By.Name = "lbl_Paid_By";
            this.lbl_Paid_By.Size = new System.Drawing.Size(118, 36);
            this.lbl_Paid_By.TabIndex = 0;
            this.lbl_Paid_By.Text = "Paid By";
            // 
            // tb_Detail
            // 
            this.tb_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Detail.Location = new System.Drawing.Point(262, 390);
            this.tb_Detail.MaxLength = 50;
            this.tb_Detail.Name = "tb_Detail";
            this.tb_Detail.Size = new System.Drawing.Size(303, 38);
            this.tb_Detail.TabIndex = 4;
            // 
            // tb_Name
            // 
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(262, 165);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(303, 38);
            this.tb_Name.TabIndex = 2;
            this.tb_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Expense_Id
            // 
            this.tb_Expense_Id.Enabled = false;
            this.tb_Expense_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Expense_Id.Location = new System.Drawing.Point(262, 60);
            this.tb_Expense_Id.MaxLength = 10;
            this.tb_Expense_Id.Name = "tb_Expense_Id";
            this.tb_Expense_Id.Size = new System.Drawing.Size(303, 38);
            this.tb_Expense_Id.TabIndex = 1;
            this.tb_Expense_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(686, 63);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(79, 36);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Detail
            // 
            this.lbl_Detail.AutoSize = true;
            this.lbl_Detail.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Detail.ForeColor = System.Drawing.Color.Black;
            this.lbl_Detail.Location = new System.Drawing.Point(17, 393);
            this.lbl_Detail.Name = "lbl_Detail";
            this.lbl_Detail.Size = new System.Drawing.Size(97, 36);
            this.lbl_Detail.TabIndex = 0;
            this.lbl_Detail.Text = "Detail";
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Type.Location = new System.Drawing.Point(17, 277);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(83, 36);
            this.lbl_Type.TabIndex = 0;
            this.lbl_Type.Text = "Type";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(17, 172);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(94, 36);
            this.lbl_Name.TabIndex = 13;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Expense_Id
            // 
            this.lbl_Expense_Id.AutoSize = true;
            this.lbl_Expense_Id.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Expense_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Expense_Id.Location = new System.Drawing.Point(17, 63);
            this.lbl_Expense_Id.Name = "lbl_Expense_Id";
            this.lbl_Expense_Id.Size = new System.Drawing.Size(168, 36);
            this.lbl_Expense_Id.TabIndex = 0;
            this.lbl_Expense_Id.Text = "Expense ID";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.MediumVioletRed;
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.Location = new System.Drawing.Point(369, 658);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 75);
            this.btn_Refresh.TabIndex = 23;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Expenses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1432, 734);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Expenses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Expenses";
            this.Load += new System.EventHandler(this.frm_Expenses_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Expenses;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label lbl_Amount;
        private System.Windows.Forms.Label lbl_Bill_Image;
        private System.Windows.Forms.TextBox tb_Amount;
        private System.Windows.Forms.Label lbl_Paid_By;
        private System.Windows.Forms.TextBox tb_Detail;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Expense_Id;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Detail;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Expense_Id;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.ComboBox cmb_Paid_By;
        private System.Windows.Forms.ComboBox cmb_Type;
    }
}