﻿namespace Hostel_System
{
    partial class frm_Repayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.btn_Back = new System.Windows.Forms.Button();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.gb_Student_Details = new System.Windows.Forms.GroupBox();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_Search = new System.Windows.Forms.Button();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Repayment = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.gb_Payment_Details = new System.Windows.Forms.GroupBox();
            this.tb_Paying_Amt = new System.Windows.Forms.TextBox();
            this.lbl_Paying_Amt = new System.Windows.Forms.Label();
            this.lbl_Paying_Date = new System.Windows.Forms.Label();
            this.dtp_Paying_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Paid_Amt = new System.Windows.Forms.TextBox();
            this.lbl_Paid_Amt = new System.Windows.Forms.Label();
            this.cmb_Payment_Mode = new System.Windows.Forms.ComboBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.tb_Remaining_Amt = new System.Windows.Forms.TextBox();
            this.lbl_Payment_Mode = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.lbl_Remaining_Amt = new System.Windows.Forms.Label();
            this.gb_Student_Details.SuspendLayout();
            this.panel1.SuspendLayout();
            this.gb_Payment_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Save.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Save.Location = new System.Drawing.Point(733, 648);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(186, 78);
            this.btn_Save.TabIndex = 3;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Enabled = false;
            this.tb_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(1037, 111);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(290, 39);
            this.tb_Mobile_No.TabIndex = 0;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(3, 6);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 58);
            this.btn_Back.TabIndex = 28;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            // 
            // tb_Name
            // 
            this.tb_Name.Enabled = false;
            this.tb_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(276, 114);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(286, 39);
            this.tb_Name.TabIndex = 0;
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(276, 34);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(286, 39);
            this.tb_Student_Id.TabIndex = 0;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(761, 113);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(147, 32);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // gb_Student_Details
            // 
            this.gb_Student_Details.BackColor = System.Drawing.Color.Lavender;
            this.gb_Student_Details.Controls.Add(this.lbl_Date);
            this.gb_Student_Details.Controls.Add(this.dtp_Date);
            this.gb_Student_Details.Controls.Add(this.btn_Search);
            this.gb_Student_Details.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.tb_Name);
            this.gb_Student_Details.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Details.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.lbl_Name);
            this.gb_Student_Details.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Details.ForeColor = System.Drawing.Color.DarkMagenta;
            this.gb_Student_Details.Location = new System.Drawing.Point(12, 110);
            this.gb_Student_Details.Name = "gb_Student_Details";
            this.gb_Student_Details.Size = new System.Drawing.Size(1408, 182);
            this.gb_Student_Details.TabIndex = 28;
            this.gb_Student_Details.TabStop = false;
            this.gb_Student_Details.Text = "Student Details";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(761, 40);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(70, 32);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1037, 34);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(290, 39);
            this.dtp_Date.TabIndex = 0;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Search.Location = new System.Drawing.Point(589, 30);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(132, 45);
            this.btn_Search.TabIndex = 29;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(21, 121);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(83, 32);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(21, 39);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(146, 32);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel1.Controls.Add(this.btn_Back);
            this.panel1.Controls.Add(this.lbl_Repayment);
            this.panel1.Location = new System.Drawing.Point(-3, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1439, 80);
            this.panel1.TabIndex = 27;
            // 
            // lbl_Repayment
            // 
            this.lbl_Repayment.AutoSize = true;
            this.lbl_Repayment.Font = new System.Drawing.Font("Times New Roman", 30.2F, System.Drawing.FontStyle.Bold);
            this.lbl_Repayment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Repayment.Location = new System.Drawing.Point(627, 6);
            this.lbl_Repayment.Name = "lbl_Repayment";
            this.lbl_Repayment.Size = new System.Drawing.Size(295, 58);
            this.lbl_Repayment.TabIndex = 0;
            this.lbl_Repayment.Text = "Re-Payment";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Refresh.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Refresh.Font = new System.Drawing.Font("Cambria", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Refresh.Location = new System.Drawing.Point(353, 648);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(186, 78);
            this.btn_Refresh.TabIndex = 4;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // gb_Payment_Details
            // 
            this.gb_Payment_Details.BackColor = System.Drawing.Color.Lavender;
            this.gb_Payment_Details.Controls.Add(this.tb_Paying_Amt);
            this.gb_Payment_Details.Controls.Add(this.lbl_Paying_Amt);
            this.gb_Payment_Details.Controls.Add(this.lbl_Paying_Date);
            this.gb_Payment_Details.Controls.Add(this.dtp_Paying_Date);
            this.gb_Payment_Details.Controls.Add(this.tb_Paid_Amt);
            this.gb_Payment_Details.Controls.Add(this.lbl_Paid_Amt);
            this.gb_Payment_Details.Controls.Add(this.cmb_Payment_Mode);
            this.gb_Payment_Details.Controls.Add(this.tb_Total);
            this.gb_Payment_Details.Controls.Add(this.tb_Remaining_Amt);
            this.gb_Payment_Details.Controls.Add(this.lbl_Payment_Mode);
            this.gb_Payment_Details.Controls.Add(this.lbl_Total);
            this.gb_Payment_Details.Controls.Add(this.lbl_Remaining_Amt);
            this.gb_Payment_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Payment_Details.ForeColor = System.Drawing.Color.DarkMagenta;
            this.gb_Payment_Details.Location = new System.Drawing.Point(12, 319);
            this.gb_Payment_Details.Name = "gb_Payment_Details";
            this.gb_Payment_Details.Size = new System.Drawing.Size(1408, 295);
            this.gb_Payment_Details.TabIndex = 31;
            this.gb_Payment_Details.TabStop = false;
            this.gb_Payment_Details.Text = "Payment Details";
            // 
            // tb_Paying_Amt
            // 
            this.tb_Paying_Amt.Enabled = false;
            this.tb_Paying_Amt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Paying_Amt.Location = new System.Drawing.Point(1037, 48);
            this.tb_Paying_Amt.MaxLength = 10;
            this.tb_Paying_Amt.Name = "tb_Paying_Amt";
            this.tb_Paying_Amt.Size = new System.Drawing.Size(280, 39);
            this.tb_Paying_Amt.TabIndex = 1;
            this.tb_Paying_Amt.Text = "0";
            this.tb_Paying_Amt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Paying_Amt
            // 
            this.lbl_Paying_Amt.AutoSize = true;
            this.lbl_Paying_Amt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paying_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paying_Amt.Location = new System.Drawing.Point(761, 54);
            this.lbl_Paying_Amt.Name = "lbl_Paying_Amt";
            this.lbl_Paying_Amt.Size = new System.Drawing.Size(162, 32);
            this.lbl_Paying_Amt.TabIndex = 32;
            this.lbl_Paying_Amt.Text = "Paying Amt.";
            // 
            // lbl_Paying_Date
            // 
            this.lbl_Paying_Date.AutoSize = true;
            this.lbl_Paying_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paying_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paying_Date.Location = new System.Drawing.Point(761, 215);
            this.lbl_Paying_Date.Name = "lbl_Paying_Date";
            this.lbl_Paying_Date.Size = new System.Drawing.Size(161, 32);
            this.lbl_Paying_Date.TabIndex = 0;
            this.lbl_Paying_Date.Text = "Paying Date";
            // 
            // dtp_Paying_Date
            // 
            this.dtp_Paying_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Paying_Date.Location = new System.Drawing.Point(1037, 209);
            this.dtp_Paying_Date.Name = "dtp_Paying_Date";
            this.dtp_Paying_Date.Size = new System.Drawing.Size(290, 39);
            this.dtp_Paying_Date.TabIndex = 3;
            // 
            // tb_Paid_Amt
            // 
            this.tb_Paid_Amt.Enabled = false;
            this.tb_Paid_Amt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Paid_Amt.Location = new System.Drawing.Point(292, 127);
            this.tb_Paid_Amt.MaxLength = 10;
            this.tb_Paid_Amt.Name = "tb_Paid_Amt";
            this.tb_Paid_Amt.Size = new System.Drawing.Size(280, 39);
            this.tb_Paid_Amt.TabIndex = 0;
            this.tb_Paid_Amt.Text = "0";
            // 
            // lbl_Paid_Amt
            // 
            this.lbl_Paid_Amt.AutoSize = true;
            this.lbl_Paid_Amt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Paid_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Paid_Amt.Location = new System.Drawing.Point(21, 135);
            this.lbl_Paid_Amt.Name = "lbl_Paid_Amt";
            this.lbl_Paid_Amt.Size = new System.Drawing.Size(134, 32);
            this.lbl_Paid_Amt.TabIndex = 9;
            this.lbl_Paid_Amt.Text = "Paid Amt.";
            // 
            // cmb_Payment_Mode
            // 
            this.cmb_Payment_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Payment_Mode.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Payment_Mode.FormattingEnabled = true;
            this.cmb_Payment_Mode.Items.AddRange(new object[] {
            "Cash",
            "Online",
            "UPI"});
            this.cmb_Payment_Mode.Location = new System.Drawing.Point(1037, 126);
            this.cmb_Payment_Mode.MaxLength = 20;
            this.cmb_Payment_Mode.Name = "cmb_Payment_Mode";
            this.cmb_Payment_Mode.Size = new System.Drawing.Size(280, 39);
            this.cmb_Payment_Mode.TabIndex = 2;
            // 
            // tb_Total
            // 
            this.tb_Total.Enabled = false;
            this.tb_Total.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total.Location = new System.Drawing.Point(292, 54);
            this.tb_Total.MaxLength = 10;
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.Size = new System.Drawing.Size(280, 39);
            this.tb_Total.TabIndex = 0;
            this.tb_Total.Text = "0";
            // 
            // tb_Remaining_Amt
            // 
            this.tb_Remaining_Amt.Enabled = false;
            this.tb_Remaining_Amt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Remaining_Amt.Location = new System.Drawing.Point(292, 209);
            this.tb_Remaining_Amt.MaxLength = 10;
            this.tb_Remaining_Amt.Name = "tb_Remaining_Amt";
            this.tb_Remaining_Amt.Size = new System.Drawing.Size(280, 39);
            this.tb_Remaining_Amt.TabIndex = 0;
            this.tb_Remaining_Amt.Text = "0";
            // 
            // lbl_Payment_Mode
            // 
            this.lbl_Payment_Mode.AutoSize = true;
            this.lbl_Payment_Mode.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Payment_Mode.ForeColor = System.Drawing.Color.Black;
            this.lbl_Payment_Mode.Location = new System.Drawing.Point(761, 135);
            this.lbl_Payment_Mode.Name = "lbl_Payment_Mode";
            this.lbl_Payment_Mode.Size = new System.Drawing.Size(195, 32);
            this.lbl_Payment_Mode.TabIndex = 4;
            this.lbl_Payment_Mode.Text = "Payment Mode";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.ForeColor = System.Drawing.Color.Black;
            this.lbl_Total.Location = new System.Drawing.Point(21, 51);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(75, 32);
            this.lbl_Total.TabIndex = 1;
            this.lbl_Total.Text = "Total";
            // 
            // lbl_Remaining_Amt
            // 
            this.lbl_Remaining_Amt.AutoSize = true;
            this.lbl_Remaining_Amt.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Remaining_Amt.ForeColor = System.Drawing.Color.Black;
            this.lbl_Remaining_Amt.Location = new System.Drawing.Point(21, 215);
            this.lbl_Remaining_Amt.Name = "lbl_Remaining_Amt";
            this.lbl_Remaining_Amt.Size = new System.Drawing.Size(208, 32);
            this.lbl_Remaining_Amt.TabIndex = 0;
            this.lbl_Remaining_Amt.Text = "Remaining Amt.";
            // 
            // frm_Repayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.Controls.Add(this.gb_Payment_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Student_Details);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Refresh);
            this.Name = "frm_Repayment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_Repayment";
            this.Load += new System.EventHandler(this.frm_Repayment_Load);
            this.gb_Student_Details.ResumeLayout(false);
            this.gb_Student_Details.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Payment_Details.ResumeLayout(false);
            this.gb_Payment_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.GroupBox gb_Student_Details;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Repayment;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.GroupBox gb_Payment_Details;
        private System.Windows.Forms.TextBox tb_Paid_Amt;
        private System.Windows.Forms.Label lbl_Paid_Amt;
        private System.Windows.Forms.ComboBox cmb_Payment_Mode;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.TextBox tb_Remaining_Amt;
        private System.Windows.Forms.Label lbl_Payment_Mode;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Label lbl_Remaining_Amt;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Paying_Date;
        private System.Windows.Forms.DateTimePicker dtp_Paying_Date;
        private System.Windows.Forms.TextBox tb_Paying_Amt;
        private System.Windows.Forms.Label lbl_Paying_Amt;
    }
}