﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_View_Mess_Payment_List : Form
    {
        public frm_View_Mess_Payment_List()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        void Bind_Grid(string Query)
        {
            Con_Open();

            dgv_View_Mess_Payment_Details.DataSource = "";

            SqlDataAdapter SDA = new SqlDataAdapter(Query, Con);

            DataTable dt = new DataTable();
            SDA.Fill(dt);

            dgv_View_Mess_Payment_Details.DataSource = dt;

            Con_Close();
        }
        private void tb_Search_By_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (tb_Search_By.Text == "")
                {
                    Bind_Grid("Select * from Mess_Payment_Details");
                    return;
                }
                if (cmb_Search_By.SelectedIndex == 0)
                {
                    Bind_Grid("Select * from Mess_Payment_Details where Student_Id like'" + tb_Search_By.Text + "%'");
                }
                else
                {
                    Bind_Grid("Select * from Mess_Payment_Details where Name like '" + tb_Search_By.Text + "%'");
                }

            }
            catch { }
        }
        private void frm_View_Mess_Payment_List_Load(object sender, EventArgs e)
        {
            Bind_Grid("Select * from Mess_Payment_Details ");
        }

        private void Only_Num_Or_Only_Text(object sender, KeyPressEventArgs e)
        {
            if (cmb_Search_By.SelectedIndex == 0 )
            {
                if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (char)Keys.Space)))
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (char)Keys.Space)))
                {
                    e.Handled = true;
                }
            }
        }
       
    }
}
