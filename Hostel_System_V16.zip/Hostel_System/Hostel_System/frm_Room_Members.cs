﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Room_Members : Form
    {
        public frm_Room_Members()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        private void frm_Room_Members_Load(object sender, EventArgs e)
        {
            Con_Open();

            int Cnt = 0,  Height = 0;

            SqlCommand Cmd = new SqlCommand("Select Student_Id from Room_Allotment where Room_No = @RNo1 And Status = 'true'", Con);

            Cmd.Parameters.Add("RNo1", SqlDbType.VarChar).Value = Shared_Class.Room_No;

            SqlDataReader Dr = Cmd.ExecuteReader();

            while (Dr.Read())
            {
                Shared_Class.Stud_ID = Convert.ToInt32(Dr["Student_Id"].ToString());

                UC_Student_Card Obj = new UC_Student_Card();

                this.pnl_Container.Controls.Add(Obj);
                Obj.Location = new Point(0, Height + (Cnt * 310));

                Obj.Show();
                Cnt++;
            }

            Cmd.Dispose();
            Dr.Close();          
            Con_Close();
        }

        private void pnl_Container_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
