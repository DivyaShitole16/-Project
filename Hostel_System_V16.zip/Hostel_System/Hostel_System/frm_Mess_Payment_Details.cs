﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Mess_Payment_Details : Form
    {
        public frm_Mess_Payment_Details()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (Char)Keys.Space)))
            {
                e.Handled = true;
            }
        }

        void Clear_Controls()
        {
            tb_Student_Id.Clear();
            tb_Name.Clear();
            cmb_Month.SelectedIndex = -1;
            tb_Amount.Clear();
        }


        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (tb_Student_Id.Text != "" && tb_Name.Text != "" && cmb_Month.Text != "" && tb_Amount.Text != "" && dtp_Date.Text != "")
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Mess_Payment_Details(Student_Id,Name,Month,Amount,Date)Values(@Stud_ID,@Name,@Month,@Amount,@Date)";
                Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                Cmd.Parameters.Add("Name", SqlDbType.VarChar).Value = tb_Name.Text;
                Cmd.Parameters.Add("Month", SqlDbType.VarChar).Value = cmb_Month.Text;
                Cmd.Parameters.Add("Amount", SqlDbType.Money).Value = tb_Amount.Text;
                Cmd.Parameters.Add("Date", SqlDbType.Date).Value = dtp_Date.Value.Date;

                Cmd.ExecuteNonQuery();

                MessageBox.Show("Record Saved");

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }

            Con_Close();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Con_Open();
            SqlCommand Cmd = new SqlCommand("Select * from Student_Details where  Student_Id= @Stud_Id", Con);

            Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                String Name = Dr.GetString(Dr.GetOrdinal("First_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Middle_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Last_Name"));
                tb_Name.Text = Name;
            }
            else
            {
                MessageBox.Show("No Record Found", "Invalid Student Id");
                tb_Student_Id.Clear();
                Cmd.Dispose();
            }
            Dr.Close();
            Con_Close();

        }
        
    }
}
