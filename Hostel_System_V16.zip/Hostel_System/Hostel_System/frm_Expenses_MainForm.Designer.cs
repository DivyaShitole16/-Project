﻿namespace Hostel_System
{
    partial class frm_Expenses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_View_Expenses_Details = new System.Windows.Forms.Button();
            this.btn_Add_New_Expenses = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_View_Expenses_Details
            // 
            this.btn_View_Expenses_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Expenses_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Expenses_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Expenses_Details.Location = new System.Drawing.Point(340, 269);
            this.btn_View_Expenses_Details.Name = "btn_View_Expenses_Details";
            this.btn_View_Expenses_Details.Size = new System.Drawing.Size(547, 88);
            this.btn_View_Expenses_Details.TabIndex = 9;
            this.btn_View_Expenses_Details.Text = "View Expenses Details";
            this.btn_View_Expenses_Details.UseVisualStyleBackColor = false;
            this.btn_View_Expenses_Details.Click += new System.EventHandler(this.btn_View_Expenses_Details_Click);
            // 
            // btn_Add_New_Expenses
            // 
            this.btn_Add_New_Expenses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Add_New_Expenses.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_New_Expenses.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Add_New_Expenses.Location = new System.Drawing.Point(340, 123);
            this.btn_Add_New_Expenses.Name = "btn_Add_New_Expenses";
            this.btn_Add_New_Expenses.Size = new System.Drawing.Size(547, 92);
            this.btn_Add_New_Expenses.TabIndex = 8;
            this.btn_Add_New_Expenses.Text = "Add New Expenses";
            this.btn_Add_New_Expenses.UseVisualStyleBackColor = false;
            this.btn_Add_New_Expenses.Click += new System.EventHandler(this.btn_Add_New_Expenses_Click);
            // 
            // frm_Expenses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1227, 668);
            this.Controls.Add(this.btn_View_Expenses_Details);
            this.Controls.Add(this.btn_Add_New_Expenses);
            this.Name = "frm_Expenses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Expenses";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_View_Expenses_Details;
        private System.Windows.Forms.Button btn_Add_New_Expenses;
    }
}