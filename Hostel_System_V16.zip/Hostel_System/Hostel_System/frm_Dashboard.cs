﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Dashboard : Form
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        public frm_Dashboard()
        {
            InitializeComponent();
            random = new Random();
        }

        private Color SelectThemeColor()
        {
            int index = random.Next(Theme_Color.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(Theme_Color.ColorList.Count);
            }
            tempIndex = index;
            string color = Theme_Color.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }


        private void ActivateButton(object btnSender)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    pnl_Title.BackColor = color;
                    pnl_Logo.BackColor = Theme_Color.ChangeColorBrightness(color, -0.3);
                    Theme_Color.PrimaryColor = color;
                    Theme_Color.SecondaryColor = Theme_Color.ChangeColorBrightness(color, -0.3);
                }
            }
        }

        private void DisableButton()
        {
            foreach (Control previousBtn in pnl_Menu.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 76);
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

                }
            }
        }
         private void OPenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.pnl_Desktop.Controls.Add(childForm);
            this.pnl_Desktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lbl_Home.Text=childForm.Text;
        }

        private void btn_Student_Click(object sender, EventArgs e)
        {
            OPenChildForm(new frm_Student(), sender);
        }


        private void btn_Employee_Click(object sender, EventArgs e)
        {
            OPenChildForm(new frm_Employee(), sender);
        }

        private void btn_Room_Click(object sender, EventArgs e)
        {
            OPenChildForm(new frm_Rooms(), sender);
        }

        private void btn_Payment_Click(object sender, EventArgs e)
        {
            OPenChildForm(new frm_Payment_Main_Form(), sender);
        }

        private void btn_Expenses_Click(object sender, EventArgs e)
        {
            OPenChildForm(new frm_Expenses(), sender);
        }
        private void btn_Charges_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
            frm_Room_Charges obj = new frm_Room_Charges();
            obj.Show();
            
        }
       

       
    }
}
