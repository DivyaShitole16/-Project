﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Rooms : Form
    {
        public frm_Rooms()
        {
            InitializeComponent();
        }

        private void btn_Room_Master_Click(object sender, EventArgs e)
        {
            frm_Room_Master obj = new frm_Room_Master();
            obj.Show();
            this.Hide();

        }
        private void btn_View_Rooms_List_Click(object sender, EventArgs e)
        {
            frm_Room_Manager Obj = new frm_Room_Manager();
            Obj.Show();
            this.Hide();
        }

        private void btn_Room_Allotment_Click(object sender, EventArgs e)
        {
            frm_Room_Allotment obj = new frm_Room_Allotment();
            obj.Show();
            this.Hide();
        }

        private void btn_Room_Reallotment_Click(object sender, EventArgs e)
        {
            frm_Room_Reallotment obj = new frm_Room_Reallotment();
            obj.Show();
            this.Hide();
        }
        

        private void btn_Leaving_Room_List_Click(object sender, EventArgs e)
        {
            frm_Leaving_Room obj = new frm_Leaving_Room();
            obj.Show();
            this.Hide();
        }
        private void frm_Rooms_Load(object sender, EventArgs e)
        {
            if (Shared_Class.UserRole == 1)
            {
                btn_Room_Master.Visible = true;
            }

        }

        private void btn_View_Room_Reallocation_List_Click(object sender, EventArgs e)
        {
           
        }

        private void btn_View_Leaving_Room_List_Click(object sender, EventArgs e)
        {

        }

        private void btn_View_Room_Allocation_Click(object sender, EventArgs e)
        {
            frm_View_Room_Allocation Obj = new frm_View_Room_Allocation();
            Obj.Show();
            this.Hide();
        }
    }
}
