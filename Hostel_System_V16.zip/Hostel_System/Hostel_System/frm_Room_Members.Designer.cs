﻿namespace Hostel_System
{
    partial class frm_Room_Members
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Room_Manager = new System.Windows.Forms.Panel();
            this.lbl_Room_Members = new System.Windows.Forms.Label();
            this.pnl_Container = new System.Windows.Forms.Panel();
            this.pnl_Room_Manager.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Room_Manager
            // 
            this.pnl_Room_Manager.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnl_Room_Manager.Controls.Add(this.lbl_Room_Members);
            this.pnl_Room_Manager.Location = new System.Drawing.Point(1, 1);
            this.pnl_Room_Manager.Name = "pnl_Room_Manager";
            this.pnl_Room_Manager.Size = new System.Drawing.Size(1326, 86);
            this.pnl_Room_Manager.TabIndex = 1;
            // 
            // lbl_Room_Members
            // 
            this.lbl_Room_Members.AutoSize = true;
            this.lbl_Room_Members.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Members.ForeColor = System.Drawing.Color.White;
            this.lbl_Room_Members.Location = new System.Drawing.Point(521, 18);
            this.lbl_Room_Members.Name = "lbl_Room_Members";
            this.lbl_Room_Members.Size = new System.Drawing.Size(295, 45);
            this.lbl_Room_Members.TabIndex = 0;
            this.lbl_Room_Members.Text = "Room Members";
            // 
            // pnl_Container
            // 
            this.pnl_Container.AutoScroll = true;
            this.pnl_Container.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pnl_Container.Location = new System.Drawing.Point(135, 115);
            this.pnl_Container.Name = "pnl_Container";
            this.pnl_Container.Size = new System.Drawing.Size(1031, 573);
            this.pnl_Container.TabIndex = 2;
            this.pnl_Container.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_Container_Paint);
            // 
            // frm_Room_Members
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1327, 713);
            this.Controls.Add(this.pnl_Container);
            this.Controls.Add(this.pnl_Room_Manager);
            this.Name = "frm_Room_Members";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Members";
            this.Load += new System.EventHandler(this.frm_Room_Members_Load);
            this.pnl_Room_Manager.ResumeLayout(false);
            this.pnl_Room_Manager.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Room_Manager;
        private System.Windows.Forms.Label lbl_Room_Members;
        private System.Windows.Forms.Panel pnl_Container;
    }
}