﻿namespace Hostel_System
{
    partial class frm_Payment_Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Repayment_Details = new System.Windows.Forms.Button();
            this.btn_Mess_Payment = new System.Windows.Forms.Button();
            this.btn_View_Mess_Payment_List = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Repayment_Details
            // 
            this.btn_Repayment_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Repayment_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Repayment_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Repayment_Details.Location = new System.Drawing.Point(364, 354);
            this.btn_Repayment_Details.Name = "btn_Repayment_Details";
            this.btn_Repayment_Details.Size = new System.Drawing.Size(513, 76);
            this.btn_Repayment_Details.TabIndex = 16;
            this.btn_Repayment_Details.Text = "Repayment Details";
            this.btn_Repayment_Details.UseVisualStyleBackColor = false;
            this.btn_Repayment_Details.Click += new System.EventHandler(this.btn_Repayment_Details_Click);
            // 
            // btn_Mess_Payment
            // 
            this.btn_Mess_Payment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Mess_Payment.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mess_Payment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Mess_Payment.Location = new System.Drawing.Point(364, 109);
            this.btn_Mess_Payment.Name = "btn_Mess_Payment";
            this.btn_Mess_Payment.Size = new System.Drawing.Size(513, 78);
            this.btn_Mess_Payment.TabIndex = 15;
            this.btn_Mess_Payment.Text = "Mess Payment";
            this.btn_Mess_Payment.UseVisualStyleBackColor = false;
            this.btn_Mess_Payment.Click += new System.EventHandler(this.btn_Mess_Payment_details_Click);
            // 
            // btn_View_Mess_Payment_List
            // 
            this.btn_View_Mess_Payment_List.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Mess_Payment_List.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Mess_Payment_List.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Mess_Payment_List.Location = new System.Drawing.Point(364, 232);
            this.btn_View_Mess_Payment_List.Name = "btn_View_Mess_Payment_List";
            this.btn_View_Mess_Payment_List.Size = new System.Drawing.Size(513, 78);
            this.btn_View_Mess_Payment_List.TabIndex = 17;
            this.btn_View_Mess_Payment_List.Text = "View Mess Payment List";
            this.btn_View_Mess_Payment_List.UseVisualStyleBackColor = false;
            this.btn_View_Mess_Payment_List.Click += new System.EventHandler(this.btn_View_Mess_Payment_Details_Click);
            // 
            // frm_Payment_Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1197, 688);
            this.Controls.Add(this.btn_View_Mess_Payment_List);
            this.Controls.Add(this.btn_Repayment_Details);
            this.Controls.Add(this.btn_Mess_Payment);
            this.Name = "frm_Payment_Main_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "      ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Repayment_Details;
        private System.Windows.Forms.Button btn_Mess_Payment;
        private System.Windows.Forms.Button btn_View_Mess_Payment_List;
    }
}