﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Room_Manager : Form
    {
        public frm_Room_Manager()
        {
            InitializeComponent();
        }

        private void btn_Show_Room_Details_Click(object sender, EventArgs e)
        {
            Shared_Class.Room_No = Convert.ToInt32((sender as Button).Text);

            frm_Room_Members Obj = new frm_Room_Members();

            Obj.Show();
        }

        private void frm_Room_Manager_Load(object sender, EventArgs e)
        {

        }
    }
}
