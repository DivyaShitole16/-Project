﻿namespace Hostel_System
{
    partial class frm_View_Reallotment_List
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Back = new System.Windows.Forms.Button();
            this.dgv_View_Reallotment_List = new System.Windows.Forms.DataGridView();
            this.cmb_Search_By = new System.Windows.Forms.ComboBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Search_By = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Search_By = new System.Windows.Forms.Label();
            this.lbl_View_Reallotment_List = new System.Windows.Forms.Label();
            this.pnl_View_Student_Details = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_View_Reallotment_List)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnl_View_Student_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(3, 3);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 67);
            this.btn_Back.TabIndex = 4;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            // 
            // dgv_View_Reallotment_List
            // 
            this.dgv_View_Reallotment_List.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_View_Reallotment_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_View_Reallotment_List.Location = new System.Drawing.Point(11, 228);
            this.dgv_View_Reallotment_List.Name = "dgv_View_Reallotment_List";
            this.dgv_View_Reallotment_List.RowTemplate.Height = 24;
            this.dgv_View_Reallotment_List.Size = new System.Drawing.Size(1408, 519);
            this.dgv_View_Reallotment_List.TabIndex = 11;
            // 
            // cmb_Search_By
            // 
            this.cmb_Search_By.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Search_By.FormattingEnabled = true;
            this.cmb_Search_By.Items.AddRange(new object[] {
            "Student Id",
            "New Room No"});
            this.cmb_Search_By.Location = new System.Drawing.Point(518, 31);
            this.cmb_Search_By.Name = "cmb_Search_By";
            this.cmb_Search_By.Size = new System.Drawing.Size(240, 41);
            this.cmb_Search_By.TabIndex = 1;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1156, 28);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(254, 34);
            this.dtp_Date.TabIndex = 1;
            // 
            // tb_Search_By
            // 
            this.tb_Search_By.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Search_By.Location = new System.Drawing.Point(828, 33);
            this.tb_Search_By.Name = "tb_Search_By";
            this.tb_Search_By.Size = new System.Drawing.Size(243, 40);
            this.tb_Search_By.TabIndex = 2;
            this.tb_Search_By.TextChanged += new System.EventHandler(this.tb_Search_By_TextChanged);
            this.tb_Search_By.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Num_Or_Only_Text);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Controls.Add(this.tb_Search_By);
            this.panel1.Controls.Add(this.cmb_Search_By);
            this.panel1.Controls.Add(this.lbl_Search_By);
            this.panel1.Location = new System.Drawing.Point(12, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1398, 96);
            this.panel1.TabIndex = 12;
            // 
            // lbl_Search_By
            // 
            this.lbl_Search_By.AutoSize = true;
            this.lbl_Search_By.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Search_By.Location = new System.Drawing.Point(319, 37);
            this.lbl_Search_By.Name = "lbl_Search_By";
            this.lbl_Search_By.Size = new System.Drawing.Size(136, 32);
            this.lbl_Search_By.TabIndex = 0;
            this.lbl_Search_By.Text = "Search By";
            // 
            // lbl_View_Reallotment_List
            // 
            this.lbl_View_Reallotment_List.AutoSize = true;
            this.lbl_View_Reallotment_List.Font = new System.Drawing.Font("Times New Roman", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_View_Reallotment_List.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_View_Reallotment_List.Location = new System.Drawing.Point(501, 13);
            this.lbl_View_Reallotment_List.Name = "lbl_View_Reallotment_List";
            this.lbl_View_Reallotment_List.Size = new System.Drawing.Size(471, 53);
            this.lbl_View_Reallotment_List.TabIndex = 0;
            this.lbl_View_Reallotment_List.Text = "View Reallotment List";
            // 
            // pnl_View_Student_Details
            // 
            this.pnl_View_Student_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnl_View_Student_Details.Controls.Add(this.btn_Back);
            this.pnl_View_Student_Details.Controls.Add(this.dtp_Date);
            this.pnl_View_Student_Details.Controls.Add(this.lbl_View_Reallotment_List);
            this.pnl_View_Student_Details.Location = new System.Drawing.Point(0, 6);
            this.pnl_View_Student_Details.Name = "pnl_View_Student_Details";
            this.pnl_View_Student_Details.Size = new System.Drawing.Size(1433, 84);
            this.pnl_View_Student_Details.TabIndex = 10;
            // 
            // frm_View_Reallotment_List
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.Controls.Add(this.dgv_View_Reallotment_List);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_View_Student_Details);
            this.Name = "frm_View_Reallotment_List";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Reallotment List";
            this.Load += new System.EventHandler(this.frm_View_Reallotment_List_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_View_Reallotment_List)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnl_View_Student_Details.ResumeLayout(false);
            this.pnl_View_Student_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.DataGridView dgv_View_Reallotment_List;
        private System.Windows.Forms.ComboBox cmb_Search_By;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Search_By;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Search_By;
        private System.Windows.Forms.Label lbl_View_Reallotment_List;
        private System.Windows.Forms.Panel pnl_View_Student_Details;
    }
}