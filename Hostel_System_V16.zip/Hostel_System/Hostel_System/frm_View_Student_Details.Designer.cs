﻿namespace Hostel_System
{
    partial class frm_View_Student_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnl_View_Student_Details = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_View_Student_Details = new System.Windows.Forms.Label();
            this.dgv_View_Student_Details = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_Search_By = new System.Windows.Forms.TextBox();
            this.cmb_Search_By = new System.Windows.Forms.ComboBox();
            this.lbl_Search_By = new System.Windows.Forms.Label();
            this.pnl_View_Student_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_View_Student_Details)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_View_Student_Details
            // 
            this.pnl_View_Student_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnl_View_Student_Details.Controls.Add(this.btn_Back);
            this.pnl_View_Student_Details.Controls.Add(this.dtp_Date);
            this.pnl_View_Student_Details.Controls.Add(this.lbl_View_Student_Details);
            this.pnl_View_Student_Details.Location = new System.Drawing.Point(0, 3);
            this.pnl_View_Student_Details.Name = "pnl_View_Student_Details";
            this.pnl_View_Student_Details.Size = new System.Drawing.Size(1431, 79);
            this.pnl_View_Student_Details.TabIndex = 1;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(3, 3);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 67);
            this.btn_Back.TabIndex = 4;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1156, 28);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(254, 34);
            this.dtp_Date.TabIndex = 1;
            // 
            // lbl_View_Student_Details
            // 
            this.lbl_View_Student_Details.AutoSize = true;
            this.lbl_View_Student_Details.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_View_Student_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_View_Student_Details.Location = new System.Drawing.Point(493, 10);
            this.lbl_View_Student_Details.Name = "lbl_View_Student_Details";
            this.lbl_View_Student_Details.Size = new System.Drawing.Size(471, 57);
            this.lbl_View_Student_Details.TabIndex = 0;
            this.lbl_View_Student_Details.Text = "View Student Details";
            // 
            // dgv_View_Student_Details
            // 
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_View_Student_Details.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_View_Student_Details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_View_Student_Details.Location = new System.Drawing.Point(21, 211);
            this.dgv_View_Student_Details.Name = "dgv_View_Student_Details";
            this.dgv_View_Student_Details.RowTemplate.Height = 24;
            this.dgv_View_Student_Details.Size = new System.Drawing.Size(1389, 530);
            this.dgv_View_Student_Details.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Controls.Add(this.tb_Search_By);
            this.panel1.Controls.Add(this.cmb_Search_By);
            this.panel1.Controls.Add(this.lbl_Search_By);
            this.panel1.Location = new System.Drawing.Point(33, 99);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1327, 91);
            this.panel1.TabIndex = 8;
            // 
            // tb_Search_By
            // 
            this.tb_Search_By.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Search_By.Location = new System.Drawing.Point(739, 32);
            this.tb_Search_By.Name = "tb_Search_By";
            this.tb_Search_By.Size = new System.Drawing.Size(241, 40);
            this.tb_Search_By.TabIndex = 2;
            this.tb_Search_By.TextChanged += new System.EventHandler(this.tb_Search_By_TextChanged);
            this.tb_Search_By.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Num_Or_Only_Text);
            // 
            // cmb_Search_By
            // 
            this.cmb_Search_By.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Search_By.FormattingEnabled = true;
            this.cmb_Search_By.Items.AddRange(new object[] {
            "Student Id",
            "Mobile No",
            "First Name"});
            this.cmb_Search_By.Location = new System.Drawing.Point(429, 32);
            this.cmb_Search_By.Name = "cmb_Search_By";
            this.cmb_Search_By.Size = new System.Drawing.Size(240, 44);
            this.cmb_Search_By.TabIndex = 1;
            // 
            // lbl_Search_By
            // 
            this.lbl_Search_By.AutoSize = true;
            this.lbl_Search_By.Font = new System.Drawing.Font("Cambria", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Search_By.Location = new System.Drawing.Point(246, 41);
            this.lbl_Search_By.Name = "lbl_Search_By";
            this.lbl_Search_By.Size = new System.Drawing.Size(136, 32);
            this.lbl_Search_By.TabIndex = 0;
            this.lbl_Search_By.Text = "Search By";
            // 
            // frm_View_Student_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgv_View_Student_Details);
            this.Controls.Add(this.pnl_View_Student_Details);
            this.Name = "frm_View_Student_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Student Details";
            this.Load += new System.EventHandler(this.frm_View_Student_Details_Load);
            this.pnl_View_Student_Details.ResumeLayout(false);
            this.pnl_View_Student_Details.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_View_Student_Details)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_View_Student_Details;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label lbl_View_Student_Details;
        private System.Windows.Forms.DataGridView dgv_View_Student_Details;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_Search_By;
        private System.Windows.Forms.ComboBox cmb_Search_By;
        private System.Windows.Forms.Label lbl_Search_By;
    }
}