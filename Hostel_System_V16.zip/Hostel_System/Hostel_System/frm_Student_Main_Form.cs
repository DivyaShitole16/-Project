﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Student : Form
    {
        public frm_Student()
        {
            InitializeComponent();
        }

        private void frm_Student_Load(object sender, EventArgs e)
        {

        }

        private void btn_Add_New_Student_Details__Click(object sender, EventArgs e)
        {
            frm_Add_New_Student_Details obj = new frm_Add_New_Student_Details();
            obj.Show();
        }

        private void btn_Update_Student_Details_Click(object sender, EventArgs e)
        {
            frm_Update_Student_Details obj = new frm_Update_Student_Details();
            obj.Show();
            this.Hide();
        }

        private void btn_View_Student_Details_Click(object sender, EventArgs e)
        {
            frm_View_Student_Details obj = new frm_View_Student_Details();
            obj.Show();
            this.Hide();
        }

        private void btn_View_Account_Details_Click(object sender, EventArgs e)
        {
            frm_View_Payment_Details obj = new frm_View_Payment_Details();
            obj.Show();
            this.Hide();
        }

      
      


    }
}
