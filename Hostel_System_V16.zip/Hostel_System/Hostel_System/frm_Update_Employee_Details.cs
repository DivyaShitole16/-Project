﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Update_Employee_Details : Form
    {
        public frm_Update_Employee_Details()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
        void Clear_Controls()
        {
            tb_Employee_Id.Text = "";
            tb_Name.Clear();
            dtp_Date_Of_Joining.ResetText();
            tb_Address.Clear();
            tb_Mobile_No.Clear();
            tb_Aadhar_No.Clear();
            cmb_Designation.SelectedIndex=-1;
            tb_Salary.Clear();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Con_Open();
            SqlCommand Cmd = new SqlCommand("Select *from Employee_Details where  Employee_Id= @Emp_Id", Con);

            Cmd.Parameters.Add("Emp_Id", SqlDbType.Int).Value = tb_Employee_Id.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                tb_Name.Text = Dr.GetString(Dr.GetOrdinal("Name"));
                dtp_Date_Of_Joining.Text = (Dr["Date_Of_Joining"].ToString());
                tb_Address.Text = Dr.GetString(Dr.GetOrdinal("Address"));
                tb_Mobile_No.Text = (Dr["Mobile_No"].ToString());
                tb_Aadhar_No.Text = (Dr["Aadhar_No"].ToString());
                cmb_Designation.Text = Dr.GetString(Dr.GetOrdinal("Designation"));
                tb_Salary.Text = (Dr["Salary"].ToString());
                   
            }
            else
            {
                MessageBox.Show("No Record Found", "Invalid Employee Id");
                tb_Employee_Id.Clear();
            }
            Con_Close();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void frm_Update_Employee_Details_Load(object sender, EventArgs e)
        {
            tb_Employee_Id.Focus();
        }

        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (Char)Keys.Space)))
            {
                e.Handled = true;
            }
        }
        
        private void btn_Update_Click(object sender, EventArgs e)
        {
            Con_Open();
            if (tb_Address.Text != "" && tb_Mobile_No.Text != "" && tb_Salary.Text != "")
            {
                SqlCommand Cmd = new SqlCommand();
                Cmd.Connection = Con;
                Cmd.CommandText = "Update Employee_Details Set Address = @Address ,Mobile_No = @MobNo,Salary=@Salary Where Employee_Id=@Emp_Id";
                Cmd.Parameters.Add("Emp_Id", SqlDbType.Int).Value = tb_Employee_Id.Text;
                Cmd.Parameters.Add("Address", SqlDbType.NVarChar).Value = tb_Address.Text;
                Cmd.Parameters.Add("MobNo", SqlDbType.Decimal).Value = tb_Mobile_No.Text;
                Cmd.Parameters.Add("Salary", SqlDbType.Money).Value = tb_Salary.Text;
               
                Cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                Clear_Controls();

            }
            else
            {
                MessageBox.Show("First Fill All Fields");
            }

            Con_Close();
        }
    }
}
