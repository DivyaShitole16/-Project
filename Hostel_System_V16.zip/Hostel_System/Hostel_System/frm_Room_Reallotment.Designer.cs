﻿namespace Hostel_System
{
    partial class frm_Room_Reallotment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_Allocation_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_New_Room_Type = new System.Windows.Forms.Label();
            this.lbl_New_Room_No = new System.Windows.Forms.Label();
            this.lbl_New_Floor = new System.Windows.Forms.Label();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Allocation_Date = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Student_Id = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.tb_Room_Type = new System.Windows.Forms.TextBox();
            this.tb_Floor = new System.Windows.Forms.TextBox();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.tb_Vacancy = new System.Windows.Forms.TextBox();
            this.lbl_Vacancy = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.cmb_New_Room_No = new System.Windows.Forms.ComboBox();
            this.cmb_New_Room_Type = new System.Windows.Forms.ComboBox();
            this.cmb_New_Floor = new System.Windows.Forms.ComboBox();
            this.lbl_Room_Reallotment = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Allocation_Date
            // 
            this.dtp_Allocation_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Allocation_Date.Location = new System.Drawing.Point(995, 42);
            this.dtp_Allocation_Date.Name = "dtp_Allocation_Date";
            this.dtp_Allocation_Date.Size = new System.Drawing.Size(305, 38);
            this.dtp_Allocation_Date.TabIndex = 5;
            // 
            // lbl_New_Room_Type
            // 
            this.lbl_New_Room_Type.AutoSize = true;
            this.lbl_New_Room_Type.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_Type.Location = new System.Drawing.Point(698, 229);
            this.lbl_New_Room_Type.Name = "lbl_New_Room_Type";
            this.lbl_New_Room_Type.Size = new System.Drawing.Size(207, 32);
            this.lbl_New_Room_Type.TabIndex = 0;
            this.lbl_New_Room_Type.Text = "New Room Type";
            // 
            // lbl_New_Room_No
            // 
            this.lbl_New_Room_No.AutoSize = true;
            this.lbl_New_Room_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Room_No.Location = new System.Drawing.Point(702, 316);
            this.lbl_New_Room_No.Name = "lbl_New_Room_No";
            this.lbl_New_Room_No.Size = new System.Drawing.Size(184, 32);
            this.lbl_New_Room_No.TabIndex = 0;
            this.lbl_New_Room_No.Text = "New Room No";
            // 
            // lbl_New_Floor
            // 
            this.lbl_New_Floor.AutoSize = true;
            this.lbl_New_Floor.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_New_Floor.Location = new System.Drawing.Point(696, 146);
            this.lbl_New_Floor.Name = "lbl_New_Floor";
            this.lbl_New_Floor.Size = new System.Drawing.Size(139, 32);
            this.lbl_New_Floor.TabIndex = 0;
            this.lbl_New_Floor.Text = "New Floor";
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(268, 49);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(189, 38);
            this.tb_Student_Id.TabIndex = 1;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Allocation_Date
            // 
            this.lbl_Allocation_Date.AutoSize = true;
            this.lbl_Allocation_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Allocation_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Allocation_Date.Location = new System.Drawing.Point(696, 53);
            this.lbl_Allocation_Date.Name = "lbl_Allocation_Date";
            this.lbl_Allocation_Date.Size = new System.Drawing.Size(205, 32);
            this.lbl_Allocation_Date.TabIndex = 0;
            this.lbl_Allocation_Date.Text = " Allocation Date";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Save.Location = new System.Drawing.Point(801, 662);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 79);
            this.btn_Save.TabIndex = 24;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // lbl_Student_Id
            // 
            this.lbl_Student_Id.AutoSize = true;
            this.lbl_Student_Id.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Id.Location = new System.Drawing.Point(30, 56);
            this.lbl_Student_Id.Name = "lbl_Student_Id";
            this.lbl_Student_Id.Size = new System.Drawing.Size(141, 31);
            this.lbl_Student_Id.TabIndex = 0;
            this.lbl_Student_Id.Text = "Student ID";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.tb_Room_No);
            this.panel2.Controls.Add(this.tb_Room_Type);
            this.panel2.Controls.Add(this.tb_Floor);
            this.panel2.Controls.Add(this.lbl_Room_No);
            this.panel2.Controls.Add(this.lbl_Room_Type);
            this.panel2.Controls.Add(this.lbl_Floor);
            this.panel2.Controls.Add(this.tb_Name);
            this.panel2.Controls.Add(this.lbl_Name);
            this.panel2.Controls.Add(this.tb_Vacancy);
            this.panel2.Controls.Add(this.lbl_Vacancy);
            this.panel2.Controls.Add(this.btn_Search);
            this.panel2.Controls.Add(this.cmb_New_Room_No);
            this.panel2.Controls.Add(this.cmb_New_Room_Type);
            this.panel2.Controls.Add(this.cmb_New_Floor);
            this.panel2.Controls.Add(this.dtp_Allocation_Date);
            this.panel2.Controls.Add(this.lbl_New_Room_Type);
            this.panel2.Controls.Add(this.lbl_New_Room_No);
            this.panel2.Controls.Add(this.lbl_New_Floor);
            this.panel2.Controls.Add(this.tb_Student_Id);
            this.panel2.Controls.Add(this.lbl_Allocation_Date);
            this.panel2.Controls.Add(this.lbl_Student_Id);
            this.panel2.Location = new System.Drawing.Point(30, 152);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1366, 469);
            this.panel2.TabIndex = 25;
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Enabled = false;
            this.tb_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(268, 401);
            this.tb_Room_No.MaxLength = 10;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(286, 38);
            this.tb_Room_No.TabIndex = 38;
            // 
            // tb_Room_Type
            // 
            this.tb_Room_Type.Enabled = false;
            this.tb_Room_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_Type.Location = new System.Drawing.Point(268, 312);
            this.tb_Room_Type.MaxLength = 10;
            this.tb_Room_Type.Name = "tb_Room_Type";
            this.tb_Room_Type.Size = new System.Drawing.Size(286, 38);
            this.tb_Room_Type.TabIndex = 39;
            // 
            // tb_Floor
            // 
            this.tb_Floor.Enabled = false;
            this.tb_Floor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Floor.Location = new System.Drawing.Point(268, 228);
            this.tb_Floor.MaxLength = 10;
            this.tb_Floor.Name = "tb_Floor";
            this.tb_Floor.Size = new System.Drawing.Size(286, 38);
            this.tb_Floor.TabIndex = 40;
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(30, 401);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(132, 31);
            this.lbl_Room_No.TabIndex = 35;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(17, 320);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(154, 31);
            this.lbl_Room_Type.TabIndex = 36;
            this.lbl_Room_Type.Text = " Room Type";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Floor.Location = new System.Drawing.Point(30, 232);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(79, 31);
            this.lbl_Floor.TabIndex = 37;
            this.lbl_Floor.Text = "Floor";
            // 
            // tb_Name
            // 
            this.tb_Name.Enabled = false;
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(268, 131);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(286, 38);
            this.tb_Name.TabIndex = 34;
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(30, 142);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(94, 36);
            this.lbl_Name.TabIndex = 33;
            this.lbl_Name.Text = "Name";
            // 
            // tb_Vacancy
            // 
            this.tb_Vacancy.Enabled = false;
            this.tb_Vacancy.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Vacancy.Location = new System.Drawing.Point(997, 397);
            this.tb_Vacancy.MaxLength = 20;
            this.tb_Vacancy.Name = "tb_Vacancy";
            this.tb_Vacancy.Size = new System.Drawing.Size(303, 38);
            this.tb_Vacancy.TabIndex = 32;
            // 
            // lbl_Vacancy
            // 
            this.lbl_Vacancy.AutoSize = true;
            this.lbl_Vacancy.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vacancy.ForeColor = System.Drawing.Color.Black;
            this.lbl_Vacancy.Location = new System.Drawing.Point(702, 401);
            this.lbl_Vacancy.Name = "lbl_Vacancy";
            this.lbl_Vacancy.Size = new System.Drawing.Size(114, 32);
            this.lbl_Vacancy.TabIndex = 31;
            this.lbl_Vacancy.Text = "Vacancy";
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Search.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Search.Location = new System.Drawing.Point(475, 45);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(126, 50);
            this.btn_Search.TabIndex = 30;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // cmb_New_Room_No
            // 
            this.cmb_New_Room_No.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_New_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_New_Room_No.FormattingEnabled = true;
            this.cmb_New_Room_No.Location = new System.Drawing.Point(995, 305);
            this.cmb_New_Room_No.Name = "cmb_New_Room_No";
            this.cmb_New_Room_No.Size = new System.Drawing.Size(303, 39);
            this.cmb_New_Room_No.TabIndex = 14;
            this.cmb_New_Room_No.SelectedIndexChanged += new System.EventHandler(this.cmb_New_Room_No_SelectedIndexChanged);
            // 
            // cmb_New_Room_Type
            // 
            this.cmb_New_Room_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_New_Room_Type.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_New_Room_Type.FormattingEnabled = true;
            this.cmb_New_Room_Type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_New_Room_Type.Location = new System.Drawing.Point(997, 224);
            this.cmb_New_Room_Type.Name = "cmb_New_Room_Type";
            this.cmb_New_Room_Type.Size = new System.Drawing.Size(303, 39);
            this.cmb_New_Room_Type.TabIndex = 7;
            this.cmb_New_Room_Type.SelectedIndexChanged += new System.EventHandler(this.cmb_New_Room_Type_SelectedIndexChanged);
            // 
            // cmb_New_Floor
            // 
            this.cmb_New_Floor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_New_Floor.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_New_Floor.FormattingEnabled = true;
            this.cmb_New_Floor.Items.AddRange(new object[] {
            "1 st Floor",
            "2 nd Floor"});
            this.cmb_New_Floor.Location = new System.Drawing.Point(995, 131);
            this.cmb_New_Floor.Name = "cmb_New_Floor";
            this.cmb_New_Floor.Size = new System.Drawing.Size(305, 39);
            this.cmb_New_Floor.TabIndex = 6;
            // 
            // lbl_Room_Reallotment
            // 
            this.lbl_Room_Reallotment.AutoSize = true;
            this.lbl_Room_Reallotment.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Reallotment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Room_Reallotment.Location = new System.Drawing.Point(497, 19);
            this.lbl_Room_Reallotment.Name = "lbl_Room_Reallotment";
            this.lbl_Room_Reallotment.Size = new System.Drawing.Size(424, 57);
            this.lbl_Room_Reallotment.TabIndex = 0;
            this.lbl_Room_Reallotment.Text = "Room Reallotment";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel1.Controls.Add(this.btn_Back);
            this.panel1.Controls.Add(this.lbl_Room_Reallotment);
            this.panel1.Location = new System.Drawing.Point(-2, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1436, 91);
            this.panel1.TabIndex = 23;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(11, 9);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 67);
            this.btn_Back.TabIndex = 14;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Refresh.Location = new System.Drawing.Point(338, 662);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 79);
            this.btn_Refresh.TabIndex = 26;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Room_Reallotment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Room_Reallotment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Reallotment";
            this.Load += new System.EventHandler(this.frm_Room_Reallotment_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Allocation_Date;
        private System.Windows.Forms.Label lbl_New_Room_Type;
        private System.Windows.Forms.Label lbl_New_Room_No;
        private System.Windows.Forms.Label lbl_New_Floor;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Allocation_Date;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Student_Id;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_Room_Reallotment;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmb_New_Room_No;
        private System.Windows.Forms.ComboBox cmb_New_Room_Type;
        private System.Windows.Forms.ComboBox cmb_New_Floor;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox tb_Vacancy;
        private System.Windows.Forms.Label lbl_Vacancy;
        private System.Windows.Forms.TextBox tb_Room_No;
        private System.Windows.Forms.TextBox tb_Room_Type;
        private System.Windows.Forms.TextBox tb_Floor;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.Label lbl_Name;
    }
}