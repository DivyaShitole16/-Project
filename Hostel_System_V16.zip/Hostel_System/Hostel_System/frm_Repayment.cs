﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Repayment : Form
    {
        public frm_Repayment()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        private void frm_Repayment_Load(object sender, EventArgs e)
        {
            tb_Student_Id.Focus();
        }

        void Clear_Controls()
        {
            tb_Student_Id.Clear();
            tb_Name.Clear();
            tb_Mobile_No.Clear();
            dtp_Date.ResetText();
            tb_Total.Clear();
            tb_Paid_Amt.Clear();
            tb_Remaining_Amt.Clear();
            tb_Paying_Amt.Clear();
            cmb_Payment_Mode.SelectedIndex = -1;
            dtp_Paying_Date.ResetText();

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (tb_Student_Id.Text != "" && tb_Name.Text != "" && dtp_Date.Text != "" && tb_Mobile_No.Text != "" && tb_Total.Text != "" && tb_Paid_Amt.Text != "" && tb_Remaining_Amt.Text != "" && tb_Paying_Amt.Text != "" && cmb_Payment_Mode.Text != "" && dtp_Paying_Date.Text != "")
            {
                if (Convert.ToDouble(tb_Remaining_Amt.Text) == Convert.ToDouble(tb_Paying_Amt.Text))
                {
                    SqlCommand Cmd = new SqlCommand();

                    Cmd.Connection = Con;
                    Cmd.CommandText = "Update Payment Set Paid_Amt = @PA, Remaining_Amt = @RA Where Student_Id = @S_Id";

                    Cmd.Parameters.Add("S_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                    Cmd.Parameters.Add("PA", SqlDbType.Money).Value = tb_Total.Text;
                    Cmd.Parameters.Add("RA", SqlDbType.Money).Value = "0";

                    Cmd.ExecuteNonQuery();
                    Cmd.Dispose();

                    Cmd.Connection = Con;
                    Cmd.CommandText = "Insert Into Accounts Values(@St_Id, @Date, @Amt, @Pay_Mode)";

                    Cmd.Parameters.Add("St_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                    Cmd.Parameters.Add("Date", SqlDbType.Date).Value = dtp_Paying_Date.Value.Date;
                    Cmd.Parameters.Add("Amt", SqlDbType.Money).Value = tb_Paying_Amt.Text;
                    Cmd.Parameters.Add("Pay_Mode", SqlDbType.VarChar).Value = cmb_Payment_Mode.Text;

                    Cmd.ExecuteNonQuery();

                    Cmd.Dispose();

                    MessageBox.Show("Record Saved");
                }
                else
                {
                    MessageBox.Show("You Should Pay Full Remaining Amount");
                }
                
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }
            Con_Close();
            Clear_Controls();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Con_Open();
            SqlCommand Cmd = new SqlCommand("Select * from Student_Details where  Student_Id= @Stud_Id", Con);
            
            Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                String Name = Dr.GetString(Dr.GetOrdinal("First_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Middle_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Last_Name"));
                tb_Name.Text = Name;
                tb_Mobile_No.Text = (Dr["Mobile_No"].ToString());
                dtp_Date.Text = (Dr["Date"].ToString());
            } 
            else
            {
                MessageBox.Show("No Record Found", "Invalid Student Id");
                tb_Student_Id.Clear();
                Cmd.Dispose();
                return;
            }

            Dr.Close();
  
            SqlCommand Cmd1 = new SqlCommand("Select * from Payment where  Student_Id= @Stud_Id", Con);
            
            Cmd1.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;

            SqlDataReader Dr1 = Cmd1.ExecuteReader();

            if(Dr1.Read())
            {
                tb_Total.Text = (Dr1["Total"].ToString());
                tb_Paid_Amt.Text = (Dr1["Paid_Amt"].ToString());
                tb_Paying_Amt.Text = (Dr1["Remaining_Amt"].ToString());
                tb_Remaining_Amt.Text = (Dr1["Remaining_Amt"].ToString());
            }
            else
            {
                MessageBox.Show("No Record Found", "Invalid Student Id");
                tb_Student_Id.Clear();
                Cmd1.Dispose();
            }

            Con_Close();

        }
      
    }
}
