﻿namespace Hostel_System
{
    partial class UC_Student_Card
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Date = new System.Windows.Forms.Label();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No1 = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.tb_Mob2 = new System.Windows.Forms.TextBox();
            this.tb_Course = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No2 = new System.Windows.Forms.Label();
            this.lbl_Course = new System.Windows.Forms.Label();
            this.btn_View_Student_Details = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(552, 26);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(60, 26);
            this.lbl_Date.TabIndex = 36;
            this.lbl_Date.Text = "Date";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Enabled = false;
            this.dtp_Date.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(712, 21);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(257, 34);
            this.dtp_Date.TabIndex = 0;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Enabled = false;
            this.tb_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(712, 101);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(257, 34);
            this.tb_Mobile_No.TabIndex = 0;
            // 
            // tb_Name
            // 
            this.tb_Name.Enabled = false;
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(221, 100);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(228, 34);
            this.tb_Name.TabIndex = 0;
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Enabled = false;
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(221, 20);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(228, 34);
            this.tb_Student_Id.TabIndex = 0;
            // 
            // lbl_Mobile_No1
            // 
            this.lbl_Mobile_No1.AutoSize = true;
            this.lbl_Mobile_No1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No1.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No1.Location = new System.Drawing.Point(552, 106);
            this.lbl_Mobile_No1.Name = "lbl_Mobile_No1";
            this.lbl_Mobile_No1.Size = new System.Drawing.Size(132, 26);
            this.lbl_Mobile_No1.TabIndex = 30;
            this.lbl_Mobile_No1.Text = "Mobile No1";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(32, 106);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(71, 26);
            this.lbl_Name.TabIndex = 33;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(32, 29);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(123, 26);
            this.lbl_Student_ID.TabIndex = 32;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // tb_Mob2
            // 
            this.tb_Mob2.Enabled = false;
            this.tb_Mob2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mob2.Location = new System.Drawing.Point(712, 179);
            this.tb_Mob2.MaxLength = 10;
            this.tb_Mob2.Name = "tb_Mob2";
            this.tb_Mob2.Size = new System.Drawing.Size(257, 34);
            this.tb_Mob2.TabIndex = 0;
            // 
            // tb_Course
            // 
            this.tb_Course.Enabled = false;
            this.tb_Course.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Course.Location = new System.Drawing.Point(221, 178);
            this.tb_Course.MaxLength = 50;
            this.tb_Course.Name = "tb_Course";
            this.tb_Course.Size = new System.Drawing.Size(228, 34);
            this.tb_Course.TabIndex = 0;
            // 
            // lbl_Mobile_No2
            // 
            this.lbl_Mobile_No2.AutoSize = true;
            this.lbl_Mobile_No2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No2.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No2.Location = new System.Drawing.Point(552, 184);
            this.lbl_Mobile_No2.Name = "lbl_Mobile_No2";
            this.lbl_Mobile_No2.Size = new System.Drawing.Size(132, 26);
            this.lbl_Mobile_No2.TabIndex = 38;
            this.lbl_Mobile_No2.Text = "Mobile No2";
            // 
            // lbl_Course
            // 
            this.lbl_Course.AutoSize = true;
            this.lbl_Course.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Course.ForeColor = System.Drawing.Color.Black;
            this.lbl_Course.Location = new System.Drawing.Point(32, 184);
            this.lbl_Course.Name = "lbl_Course";
            this.lbl_Course.Size = new System.Drawing.Size(85, 26);
            this.lbl_Course.TabIndex = 0;
            this.lbl_Course.Text = "Course";
            // 
            // btn_View_Student_Details
            // 
            this.btn_View_Student_Details.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_View_Student_Details.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Student_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Student_Details.Location = new System.Drawing.Point(341, 243);
            this.btn_View_Student_Details.Name = "btn_View_Student_Details";
            this.btn_View_Student_Details.Size = new System.Drawing.Size(303, 46);
            this.btn_View_Student_Details.TabIndex = 39;
            this.btn_View_Student_Details.Text = "View Student Details";
            this.btn_View_Student_Details.UseVisualStyleBackColor = false;
            this.btn_View_Student_Details.Click += new System.EventHandler(this.btn_View_Student_Details_Click);
            // 
            // UC_Student_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.btn_View_Student_Details);
            this.Controls.Add(this.tb_Mob2);
            this.Controls.Add(this.tb_Course);
            this.Controls.Add(this.lbl_Mobile_No2);
            this.Controls.Add(this.lbl_Course);
            this.Controls.Add(this.lbl_Date);
            this.Controls.Add(this.dtp_Date);
            this.Controls.Add(this.tb_Mobile_No);
            this.Controls.Add(this.tb_Name);
            this.Controls.Add(this.tb_Student_Id);
            this.Controls.Add(this.lbl_Mobile_No1);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.lbl_Student_ID);
            this.Enabled = false;
            this.Name = "UC_Student_Card";
            this.Size = new System.Drawing.Size(1046, 305);
            this.Load += new System.EventHandler(this.UC_Student_Card_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Mobile_No1;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.TextBox tb_Mob2;
        private System.Windows.Forms.TextBox tb_Course;
        private System.Windows.Forms.Label lbl_Mobile_No2;
        private System.Windows.Forms.Label lbl_Course;
        private System.Windows.Forms.Button btn_View_Student_Details;
    }
}
