﻿namespace Hostel_System
{
    partial class frm_Rooms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Room_Reallotment = new System.Windows.Forms.Button();
            this.btn_Room_Master = new System.Windows.Forms.Button();
            this.btn_View_Rooms_List = new System.Windows.Forms.Button();
            this.btn_View_Room_Reallocation_List = new System.Windows.Forms.Button();
            this.btn_View_Leaving_Room_List = new System.Windows.Forms.Button();
            this.btn_Leaving_Room = new System.Windows.Forms.Button();
            this.btn_View_Room_Allocation = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Room_Reallotment
            // 
            this.btn_Room_Reallotment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Room_Reallotment.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Room_Reallotment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Room_Reallotment.Location = new System.Drawing.Point(307, 294);
            this.btn_Room_Reallotment.Name = "btn_Room_Reallotment";
            this.btn_Room_Reallotment.Size = new System.Drawing.Size(509, 72);
            this.btn_Room_Reallotment.TabIndex = 12;
            this.btn_Room_Reallotment.Text = "Room Reallotment";
            this.btn_Room_Reallotment.UseVisualStyleBackColor = false;
            this.btn_Room_Reallotment.Click += new System.EventHandler(this.btn_Room_Reallotment_Click);
            // 
            // btn_Room_Master
            // 
            this.btn_Room_Master.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Room_Master.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Room_Master.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Room_Master.Location = new System.Drawing.Point(307, 27);
            this.btn_Room_Master.Name = "btn_Room_Master";
            this.btn_Room_Master.Size = new System.Drawing.Size(509, 72);
            this.btn_Room_Master.TabIndex = 10;
            this.btn_Room_Master.Text = "Room Master";
            this.btn_Room_Master.UseVisualStyleBackColor = false;
            this.btn_Room_Master.Visible = false;
            this.btn_Room_Master.Click += new System.EventHandler(this.btn_Room_Master_Click);
            // 
            // btn_View_Rooms_List
            // 
            this.btn_View_Rooms_List.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Rooms_List.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Rooms_List.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Rooms_List.Location = new System.Drawing.Point(307, 116);
            this.btn_View_Rooms_List.Name = "btn_View_Rooms_List";
            this.btn_View_Rooms_List.Size = new System.Drawing.Size(509, 70);
            this.btn_View_Rooms_List.TabIndex = 14;
            this.btn_View_Rooms_List.Text = "View Rooms List";
            this.btn_View_Rooms_List.UseVisualStyleBackColor = false;
            this.btn_View_Rooms_List.Click += new System.EventHandler(this.btn_View_Rooms_List_Click);
            // 
            // btn_View_Room_Reallocation_List
            // 
            this.btn_View_Room_Reallocation_List.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Room_Reallocation_List.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Room_Reallocation_List.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Room_Reallocation_List.Location = new System.Drawing.Point(307, 385);
            this.btn_View_Room_Reallocation_List.Name = "btn_View_Room_Reallocation_List";
            this.btn_View_Room_Reallocation_List.Size = new System.Drawing.Size(509, 70);
            this.btn_View_Room_Reallocation_List.TabIndex = 15;
            this.btn_View_Room_Reallocation_List.Text = "View Room Reallocation List";
            this.btn_View_Room_Reallocation_List.UseVisualStyleBackColor = false;
            this.btn_View_Room_Reallocation_List.Click += new System.EventHandler(this.btn_View_Room_Reallocation_List_Click);
            // 
            // btn_View_Leaving_Room_List
            // 
            this.btn_View_Leaving_Room_List.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Leaving_Room_List.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Leaving_Room_List.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Leaving_Room_List.Location = new System.Drawing.Point(307, 567);
            this.btn_View_Leaving_Room_List.Name = "btn_View_Leaving_Room_List";
            this.btn_View_Leaving_Room_List.Size = new System.Drawing.Size(509, 70);
            this.btn_View_Leaving_Room_List.TabIndex = 17;
            this.btn_View_Leaving_Room_List.Text = "View Leaving Room List";
            this.btn_View_Leaving_Room_List.UseVisualStyleBackColor = false;
            this.btn_View_Leaving_Room_List.Click += new System.EventHandler(this.btn_View_Leaving_Room_List_Click);
            // 
            // btn_Leaving_Room
            // 
            this.btn_Leaving_Room.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Leaving_Room.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Leaving_Room.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Leaving_Room.Location = new System.Drawing.Point(307, 474);
            this.btn_Leaving_Room.Name = "btn_Leaving_Room";
            this.btn_Leaving_Room.Size = new System.Drawing.Size(509, 72);
            this.btn_Leaving_Room.TabIndex = 16;
            this.btn_Leaving_Room.Text = "Leaving Room ";
            this.btn_Leaving_Room.UseVisualStyleBackColor = false;
            this.btn_Leaving_Room.Click += new System.EventHandler(this.btn_Leaving_Room_List_Click);
            // 
            // btn_View_Room_Allocation
            // 
            this.btn_View_Room_Allocation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Room_Allocation.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Room_Allocation.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Room_Allocation.Location = new System.Drawing.Point(307, 203);
            this.btn_View_Room_Allocation.Name = "btn_View_Room_Allocation";
            this.btn_View_Room_Allocation.Size = new System.Drawing.Size(509, 70);
            this.btn_View_Room_Allocation.TabIndex = 18;
            this.btn_View_Room_Allocation.Text = "View Room Allocation List";
            this.btn_View_Room_Allocation.UseVisualStyleBackColor = false;
            this.btn_View_Room_Allocation.Click += new System.EventHandler(this.btn_View_Room_Allocation_Click);
            // 
            // frm_Rooms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1197, 688);
            this.ControlBox = false;
            this.Controls.Add(this.btn_View_Room_Allocation);
            this.Controls.Add(this.btn_View_Leaving_Room_List);
            this.Controls.Add(this.btn_Leaving_Room);
            this.Controls.Add(this.btn_View_Room_Reallocation_List);
            this.Controls.Add(this.btn_View_Rooms_List);
            this.Controls.Add(this.btn_Room_Reallotment);
            this.Controls.Add(this.btn_Room_Master);
            this.Name = "frm_Rooms";
            this.Text = "Rooms";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Room_Reallotment;
        private System.Windows.Forms.Button btn_Room_Master;
        private System.Windows.Forms.Button btn_View_Rooms_List;
        private System.Windows.Forms.Button btn_View_Room_Reallocation_List;
        private System.Windows.Forms.Button btn_View_Leaving_Room_List;
        private System.Windows.Forms.Button btn_Leaving_Room;
        private System.Windows.Forms.Button btn_View_Room_Allocation;
    }
}