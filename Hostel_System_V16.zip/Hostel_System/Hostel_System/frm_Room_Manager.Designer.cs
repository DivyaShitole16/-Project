﻿namespace Hostel_System
{
    partial class frm_Room_Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Room_Manager = new System.Windows.Forms.Panel();
            this.lbl_Room_Manager = new System.Windows.Forms.Label();
            this.gb_First_Floor = new System.Windows.Forms.GroupBox();
            this.btn_110 = new System.Windows.Forms.Button();
            this.btn_109 = new System.Windows.Forms.Button();
            this.btn_108 = new System.Windows.Forms.Button();
            this.btn_107 = new System.Windows.Forms.Button();
            this.btn_106 = new System.Windows.Forms.Button();
            this.btn_105 = new System.Windows.Forms.Button();
            this.btn_104 = new System.Windows.Forms.Button();
            this.btn_103 = new System.Windows.Forms.Button();
            this.btn_102 = new System.Windows.Forms.Button();
            this.btn_101 = new System.Windows.Forms.Button();
            this.gb_Second_Floor = new System.Windows.Forms.GroupBox();
            this.btn_210 = new System.Windows.Forms.Button();
            this.btn_209 = new System.Windows.Forms.Button();
            this.btn_208 = new System.Windows.Forms.Button();
            this.btn_207 = new System.Windows.Forms.Button();
            this.btn_206 = new System.Windows.Forms.Button();
            this.btn_205 = new System.Windows.Forms.Button();
            this.btn_204 = new System.Windows.Forms.Button();
            this.btn_203 = new System.Windows.Forms.Button();
            this.btn_202 = new System.Windows.Forms.Button();
            this.btn_201 = new System.Windows.Forms.Button();
            this.pnl_Room_Manager.SuspendLayout();
            this.gb_First_Floor.SuspendLayout();
            this.gb_Second_Floor.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Room_Manager
            // 
            this.pnl_Room_Manager.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnl_Room_Manager.Controls.Add(this.lbl_Room_Manager);
            this.pnl_Room_Manager.Location = new System.Drawing.Point(1, 0);
            this.pnl_Room_Manager.Name = "pnl_Room_Manager";
            this.pnl_Room_Manager.Size = new System.Drawing.Size(1323, 86);
            this.pnl_Room_Manager.TabIndex = 0;
            // 
            // lbl_Room_Manager
            // 
            this.lbl_Room_Manager.AutoSize = true;
            this.lbl_Room_Manager.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Manager.ForeColor = System.Drawing.Color.White;
            this.lbl_Room_Manager.Location = new System.Drawing.Point(539, 23);
            this.lbl_Room_Manager.Name = "lbl_Room_Manager";
            this.lbl_Room_Manager.Size = new System.Drawing.Size(286, 45);
            this.lbl_Room_Manager.TabIndex = 0;
            this.lbl_Room_Manager.Text = "Room Manager";
            // 
            // gb_First_Floor
            // 
            this.gb_First_Floor.BackColor = System.Drawing.Color.Lavender;
            this.gb_First_Floor.Controls.Add(this.btn_110);
            this.gb_First_Floor.Controls.Add(this.btn_109);
            this.gb_First_Floor.Controls.Add(this.btn_108);
            this.gb_First_Floor.Controls.Add(this.btn_107);
            this.gb_First_Floor.Controls.Add(this.btn_106);
            this.gb_First_Floor.Controls.Add(this.btn_105);
            this.gb_First_Floor.Controls.Add(this.btn_104);
            this.gb_First_Floor.Controls.Add(this.btn_103);
            this.gb_First_Floor.Controls.Add(this.btn_102);
            this.gb_First_Floor.Controls.Add(this.btn_101);
            this.gb_First_Floor.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_First_Floor.Location = new System.Drawing.Point(78, 118);
            this.gb_First_Floor.Name = "gb_First_Floor";
            this.gb_First_Floor.Size = new System.Drawing.Size(1159, 233);
            this.gb_First_Floor.TabIndex = 1;
            this.gb_First_Floor.TabStop = false;
            this.gb_First_Floor.Text = "First Floor";
            // 
            // btn_110
            // 
            this.btn_110.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_110.Location = new System.Drawing.Point(1044, 61);
            this.btn_110.Name = "btn_110";
            this.btn_110.Size = new System.Drawing.Size(95, 92);
            this.btn_110.TabIndex = 12;
            this.btn_110.Text = "110";
            this.btn_110.UseVisualStyleBackColor = true;
            this.btn_110.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_109
            // 
            this.btn_109.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_109.Location = new System.Drawing.Point(922, 61);
            this.btn_109.Name = "btn_109";
            this.btn_109.Size = new System.Drawing.Size(95, 92);
            this.btn_109.TabIndex = 11;
            this.btn_109.Text = "109";
            this.btn_109.UseVisualStyleBackColor = true;
            this.btn_109.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_108
            // 
            this.btn_108.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_108.Location = new System.Drawing.Point(802, 61);
            this.btn_108.Name = "btn_108";
            this.btn_108.Size = new System.Drawing.Size(95, 92);
            this.btn_108.TabIndex = 10;
            this.btn_108.Text = "108";
            this.btn_108.UseVisualStyleBackColor = true;
            this.btn_108.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_107
            // 
            this.btn_107.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_107.Location = new System.Drawing.Point(688, 61);
            this.btn_107.Name = "btn_107";
            this.btn_107.Size = new System.Drawing.Size(95, 92);
            this.btn_107.TabIndex = 9;
            this.btn_107.Text = "107";
            this.btn_107.UseVisualStyleBackColor = true;
            this.btn_107.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_106
            // 
            this.btn_106.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_106.Location = new System.Drawing.Point(571, 61);
            this.btn_106.Name = "btn_106";
            this.btn_106.Size = new System.Drawing.Size(95, 92);
            this.btn_106.TabIndex = 8;
            this.btn_106.Text = "106";
            this.btn_106.UseVisualStyleBackColor = true;
            this.btn_106.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_105
            // 
            this.btn_105.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_105.Location = new System.Drawing.Point(453, 61);
            this.btn_105.Name = "btn_105";
            this.btn_105.Size = new System.Drawing.Size(95, 92);
            this.btn_105.TabIndex = 7;
            this.btn_105.Text = "105";
            this.btn_105.UseVisualStyleBackColor = true;
            this.btn_105.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_104
            // 
            this.btn_104.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_104.Location = new System.Drawing.Point(336, 61);
            this.btn_104.Name = "btn_104";
            this.btn_104.Size = new System.Drawing.Size(95, 92);
            this.btn_104.TabIndex = 6;
            this.btn_104.Text = "104";
            this.btn_104.UseVisualStyleBackColor = true;
            this.btn_104.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_103
            // 
            this.btn_103.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_103.Location = new System.Drawing.Point(226, 61);
            this.btn_103.Name = "btn_103";
            this.btn_103.Size = new System.Drawing.Size(95, 92);
            this.btn_103.TabIndex = 5;
            this.btn_103.Text = "103";
            this.btn_103.UseVisualStyleBackColor = true;
            this.btn_103.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_102
            // 
            this.btn_102.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_102.Location = new System.Drawing.Point(112, 61);
            this.btn_102.Name = "btn_102";
            this.btn_102.Size = new System.Drawing.Size(95, 92);
            this.btn_102.TabIndex = 4;
            this.btn_102.Text = "102";
            this.btn_102.UseVisualStyleBackColor = true;
            this.btn_102.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_101
            // 
            this.btn_101.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_101.Location = new System.Drawing.Point(6, 61);
            this.btn_101.Name = "btn_101";
            this.btn_101.Size = new System.Drawing.Size(95, 92);
            this.btn_101.TabIndex = 3;
            this.btn_101.Text = "101";
            this.btn_101.UseVisualStyleBackColor = true;
            this.btn_101.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // gb_Second_Floor
            // 
            this.gb_Second_Floor.BackColor = System.Drawing.Color.Lavender;
            this.gb_Second_Floor.Controls.Add(this.btn_210);
            this.gb_Second_Floor.Controls.Add(this.btn_209);
            this.gb_Second_Floor.Controls.Add(this.btn_208);
            this.gb_Second_Floor.Controls.Add(this.btn_207);
            this.gb_Second_Floor.Controls.Add(this.btn_206);
            this.gb_Second_Floor.Controls.Add(this.btn_205);
            this.gb_Second_Floor.Controls.Add(this.btn_204);
            this.gb_Second_Floor.Controls.Add(this.btn_203);
            this.gb_Second_Floor.Controls.Add(this.btn_202);
            this.gb_Second_Floor.Controls.Add(this.btn_201);
            this.gb_Second_Floor.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Second_Floor.Location = new System.Drawing.Point(72, 397);
            this.gb_Second_Floor.Name = "gb_Second_Floor";
            this.gb_Second_Floor.Size = new System.Drawing.Size(1165, 218);
            this.gb_Second_Floor.TabIndex = 2;
            this.gb_Second_Floor.TabStop = false;
            this.gb_Second_Floor.Text = "Second Floor";
            // 
            // btn_210
            // 
            this.btn_210.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_210.Location = new System.Drawing.Point(1050, 55);
            this.btn_210.Name = "btn_210";
            this.btn_210.Size = new System.Drawing.Size(95, 92);
            this.btn_210.TabIndex = 22;
            this.btn_210.Text = "210";
            this.btn_210.UseVisualStyleBackColor = true;
            this.btn_210.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_209
            // 
            this.btn_209.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_209.Location = new System.Drawing.Point(928, 55);
            this.btn_209.Name = "btn_209";
            this.btn_209.Size = new System.Drawing.Size(95, 92);
            this.btn_209.TabIndex = 21;
            this.btn_209.Text = "209";
            this.btn_209.UseVisualStyleBackColor = true;
            this.btn_209.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_208
            // 
            this.btn_208.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_208.Location = new System.Drawing.Point(808, 55);
            this.btn_208.Name = "btn_208";
            this.btn_208.Size = new System.Drawing.Size(95, 92);
            this.btn_208.TabIndex = 20;
            this.btn_208.Text = "208";
            this.btn_208.UseVisualStyleBackColor = true;
            this.btn_208.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_207
            // 
            this.btn_207.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_207.Location = new System.Drawing.Point(694, 55);
            this.btn_207.Name = "btn_207";
            this.btn_207.Size = new System.Drawing.Size(95, 92);
            this.btn_207.TabIndex = 19;
            this.btn_207.Text = "207";
            this.btn_207.UseVisualStyleBackColor = true;
            this.btn_207.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_206
            // 
            this.btn_206.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_206.Location = new System.Drawing.Point(577, 55);
            this.btn_206.Name = "btn_206";
            this.btn_206.Size = new System.Drawing.Size(95, 92);
            this.btn_206.TabIndex = 18;
            this.btn_206.Text = "206";
            this.btn_206.UseVisualStyleBackColor = true;
            this.btn_206.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_205
            // 
            this.btn_205.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_205.Location = new System.Drawing.Point(459, 55);
            this.btn_205.Name = "btn_205";
            this.btn_205.Size = new System.Drawing.Size(95, 92);
            this.btn_205.TabIndex = 17;
            this.btn_205.Text = "205";
            this.btn_205.UseVisualStyleBackColor = true;
            this.btn_205.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_204
            // 
            this.btn_204.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_204.Location = new System.Drawing.Point(342, 49);
            this.btn_204.Name = "btn_204";
            this.btn_204.Size = new System.Drawing.Size(95, 92);
            this.btn_204.TabIndex = 16;
            this.btn_204.Text = "204";
            this.btn_204.UseVisualStyleBackColor = true;
            this.btn_204.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_203
            // 
            this.btn_203.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_203.Location = new System.Drawing.Point(232, 49);
            this.btn_203.Name = "btn_203";
            this.btn_203.Size = new System.Drawing.Size(95, 92);
            this.btn_203.TabIndex = 15;
            this.btn_203.Text = "203";
            this.btn_203.UseVisualStyleBackColor = true;
            this.btn_203.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_202
            // 
            this.btn_202.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_202.Location = new System.Drawing.Point(118, 49);
            this.btn_202.Name = "btn_202";
            this.btn_202.Size = new System.Drawing.Size(95, 92);
            this.btn_202.TabIndex = 14;
            this.btn_202.Text = "202";
            this.btn_202.UseVisualStyleBackColor = true;
            this.btn_202.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // btn_201
            // 
            this.btn_201.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_201.Location = new System.Drawing.Point(6, 49);
            this.btn_201.Name = "btn_201";
            this.btn_201.Size = new System.Drawing.Size(95, 92);
            this.btn_201.TabIndex = 13;
            this.btn_201.Text = "201";
            this.btn_201.UseVisualStyleBackColor = true;
            this.btn_201.Click += new System.EventHandler(this.btn_Show_Room_Details_Click);
            // 
            // frm_Room_Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1327, 713);
            this.Controls.Add(this.gb_Second_Floor);
            this.Controls.Add(this.gb_First_Floor);
            this.Controls.Add(this.pnl_Room_Manager);
            this.Name = "frm_Room_Manager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Manager";
            this.Load += new System.EventHandler(this.frm_Room_Manager_Load);
            this.pnl_Room_Manager.ResumeLayout(false);
            this.pnl_Room_Manager.PerformLayout();
            this.gb_First_Floor.ResumeLayout(false);
            this.gb_Second_Floor.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Room_Manager;
        private System.Windows.Forms.Label lbl_Room_Manager;
        private System.Windows.Forms.GroupBox gb_First_Floor;
        private System.Windows.Forms.Button btn_110;
        private System.Windows.Forms.Button btn_109;
        private System.Windows.Forms.Button btn_108;
        private System.Windows.Forms.Button btn_107;
        private System.Windows.Forms.Button btn_106;
        private System.Windows.Forms.Button btn_105;
        private System.Windows.Forms.Button btn_104;
        private System.Windows.Forms.Button btn_103;
        private System.Windows.Forms.Button btn_102;
        private System.Windows.Forms.Button btn_101;
        private System.Windows.Forms.GroupBox gb_Second_Floor;
        private System.Windows.Forms.Button btn_210;
        private System.Windows.Forms.Button btn_209;
        private System.Windows.Forms.Button btn_208;
        private System.Windows.Forms.Button btn_207;
        private System.Windows.Forms.Button btn_206;
        private System.Windows.Forms.Button btn_205;
        private System.Windows.Forms.Button btn_204;
        private System.Windows.Forms.Button btn_203;
        private System.Windows.Forms.Button btn_202;
        private System.Windows.Forms.Button btn_201;
    }
}