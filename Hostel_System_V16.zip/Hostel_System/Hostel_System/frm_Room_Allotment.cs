﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Room_Allotment : Form
    {
        public frm_Room_Allotment()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
      
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (Char)Keys.Space)))
            {
                e.Handled = true;
            }
        }

        void Clear_Controls()
        {
            cmb_Floor.Text = "";
            cmb_Room_Type.Text = "";
            cmb_Room_No.Text = "";
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
             Con_Open();

            if (tb_Student_Id.Text != ""  && dtp_Date.Text != "" && cmb_Room_No.Text != "" && cmb_Room_Type.Text != "" && cmb_Floor.Text != "") 
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Room_Allotment Values(@Student_Id,@Date,@Room_No,@Room_Type,@Floor, 'true')";
                
                Cmd.Parameters.Add("Student_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                Cmd.Parameters.Add("Date", SqlDbType.Date).Value = dtp_Date.Value.Date;
                Cmd.Parameters.Add("Room_No", SqlDbType.Int).Value = cmb_Room_No.Text;
                Cmd.Parameters.Add("Room_Type", SqlDbType.NVarChar).Value = cmb_Room_Type.Text;
                Cmd.Parameters.Add("Floor", SqlDbType.NVarChar).Value = cmb_Floor.Text;

                Cmd.ExecuteNonQuery();
                Shared_Vars.Room_type = cmb_Room_Type.Text;

                Cmd.Connection = Con;
                Cmd.CommandText = "Update Room_Master Set Vacancy = @Vac where Room_No = @RNo";

                Cmd.Parameters.Add("RNo", SqlDbType.Int).Value = cmb_Room_No.Text;
                Cmd.Parameters.Add("Vac", SqlDbType.Int).Value = Convert.ToInt32(tb_Vacancy.Text) - 1;

                Cmd.ExecuteNonQuery();

                MessageBox.Show("Record Saved");

                frm_Payment Obj = new frm_Payment();
                Obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }

            Con_Close();
            Clear_Controls();
        }
        
        private void frm_Room_Allotment_Load(object sender, EventArgs e)
        {
            tb_Student_Id.Text = Convert.ToString(Shared_Vars.ID);
            tb_Name.Text = Shared_Vars.Name;
            tb_Mobile_No.Text = Convert.ToString(Shared_Vars.Mob_No);
        }

        private void cmb_Room_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            Con_Open();

            cmb_Room_No.Items.Clear();

            SqlCommand Cmd = new SqlCommand("Select Room_No from Room_Master where Vacancy > 0 And Floor = @Flr And Room_Type = @Rtype ", Con);

            Cmd.Parameters.Add("Flr", SqlDbType.VarChar).Value = cmb_Floor.Text;
            Cmd.Parameters.Add("RType", SqlDbType.NVarChar).Value = cmb_Room_Type.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            while (Dr.Read())
            {
                cmb_Room_No.Items.Add(Dr["Room_No"].ToString());
            }

            Con_Close();
        }

        private void cmb_Room_No_SelectedIndexChanged(object sender, EventArgs e)
        {
            Con_Open();

            SqlCommand Cmd = new SqlCommand("Select Vacancy from Room_Master where Room_No = @R_No", Con);

            Cmd.Parameters.Add("R_No", SqlDbType.Int).Value = cmb_Room_No.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                tb_Vacancy.Text = Dr["Vacancy"].ToString();
            }
            Con_Close();
        }
        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
