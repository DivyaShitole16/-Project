﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Payment : Form
    {
        public frm_Payment()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        void Clear_Controls()
        {

            tb_Student_Id.Clear();
            tb_Name.Clear();
            tb_Mobile_No.Clear();
            cmb_Duration.SelectedIndex = -1;
            tb_Deposit.Clear();
            tb_Charges.Clear();
            tb_Total.Clear();
            tb_Paying_Amt.Clear();
            tb_Remaining_Amt.Clear();
            cmb_Payment_Mode.SelectedIndex = -1;

        }

        private void frm_Payment_Load(object sender, EventArgs e)
        {
            tb_Student_Id.Text = Convert.ToString(Shared_Vars.ID);
            tb_Name.Text = Shared_Vars.Name;
            tb_Mobile_No.Text = Convert.ToString(Shared_Vars.Mob_No);
            cmb_Room_Type.Text = Shared_Vars.Room_type;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (tb_Student_Id.Text != "" && tb_Name.Text != "" && dtp_Date.Text != "" && tb_Mobile_No.Text != "" && cmb_Duration.Text != "" && tb_Deposit.Text != "" && tb_Charges.Text != "" && tb_Total.Text != "" && tb_Paying_Amt.Text != "" && tb_Remaining_Amt.Text != "" && cmb_Payment_Mode.Text != "")
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Payment Values(@Student_Id, @Name,@Date,@Mobile_No,@Duration,@Deposit,@Charges,@Total,@Paying_Amt,@Remaining_Amt)";

                Cmd.Parameters.Add("Student_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                Cmd.Parameters.Add("Name", SqlDbType.VarChar).Value = tb_Name.Text;
                Cmd.Parameters.Add("Date", SqlDbType.Date).Value = dtp_Date.Value.Date;
                Cmd.Parameters.Add("Mobile_No", SqlDbType.Decimal).Value = tb_Mobile_No.Text;
                Cmd.Parameters.Add("Duration", SqlDbType.NVarChar).Value = cmb_Duration.Text;
                Cmd.Parameters.Add("Deposit", SqlDbType.Money).Value = tb_Deposit.Text;
                Cmd.Parameters.Add("Charges", SqlDbType.Money).Value = tb_Charges.Text;
                Cmd.Parameters.Add("Total", SqlDbType.Money).Value = tb_Total.Text;
                Cmd.Parameters.Add("Paying_Amt", SqlDbType.Money).Value = tb_Paying_Amt.Text;
                Cmd.Parameters.Add("Remaining_Amt", SqlDbType.Money).Value = tb_Remaining_Amt.Text;

                Cmd.ExecuteNonQuery();

                Cmd.Dispose();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Accounts Values(@S_Id, @Dt, @Amt, @Pay_Mode)";

                Cmd.Parameters.Add("S_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                Cmd.Parameters.Add("Dt", SqlDbType.Date).Value = dtp_Date.Value.Date;
                Cmd.Parameters.Add("Amt", SqlDbType.Money).Value = tb_Paying_Amt.Text;
                Cmd.Parameters.Add("Pay_Mode", SqlDbType.VarChar).Value = cmb_Payment_Mode.Text;

                Cmd.ExecuteNonQuery();

                Cmd.Dispose();

                MessageBox.Show("Record Saved");
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }
            Con_Close();
            Clear_Controls();
        }

        private void cmb_Duration_SelectedIndexChanged(object sender, EventArgs e)
        {
            Con_Open();

            SqlCommand Cmd = new SqlCommand("Select * from Room_Charges where Room_Type = @Rtype ", Con);

            Cmd.Parameters.Add("RType", SqlDbType.NVarChar).Value = cmb_Room_Type.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            while (Dr.Read())
            {
                tb_Deposit.Text = (Dr["Deposit"].ToString());     
                if (cmb_Duration.SelectedIndex == 0)
                {
                    tb_Charges.Text = Dr["Charges"].ToString();
                }
                else if(cmb_Duration.SelectedIndex == 1)
                {
                    tb_Charges.Text = Convert.ToString(Convert.ToDecimal(Dr["Charges"].ToString()) * 2);
                }
            }
            tb_Total.Text = Convert.ToString(Convert.ToDecimal(tb_Charges.Text) + Convert.ToDecimal(tb_Deposit.Text));
            tb_Remaining_Amt.Text = Convert.ToString(Convert.ToDecimal(tb_Charges.Text) + Convert.ToDecimal(tb_Deposit.Text));

            Con_Close();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }    
        private void tb_Paying_Amt_Leave(object sender, EventArgs e)
        {
            if (Convert.ToDouble(tb_Total.Text) > 0 && tb_Paying_Amt.Text != "")
            {
                if (Convert.ToDouble(tb_Paying_Amt.Text) > Convert.ToDouble(tb_Total.Text) * 0.5)
                {
                    tb_Remaining_Amt.Text = Convert.ToString(Convert.ToDecimal(tb_Total.Text) - Convert.ToDecimal(tb_Paying_Amt.Text));
                }
                else
                {
                    MessageBox.Show("Paying Fees Should be Atleast 50% of Total");
                    tb_Paying_Amt.Text = "0";
                    tb_Paying_Amt.Focus();
                }
            }
        }

       

      
    }
}

