﻿namespace Hostel_System
{
    partial class frm_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_View_Employee_Details = new System.Windows.Forms.Button();
            this.btn_Update_Employee_Details = new System.Windows.Forms.Button();
            this.btn_Add_New_Employee_Details_ = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_View_Employee_Details
            // 
            this.btn_View_Employee_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Employee_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Employee_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Employee_Details.Location = new System.Drawing.Point(347, 435);
            this.btn_View_Employee_Details.Name = "btn_View_Employee_Details";
            this.btn_View_Employee_Details.Size = new System.Drawing.Size(503, 84);
            this.btn_View_Employee_Details.TabIndex = 14;
            this.btn_View_Employee_Details.Text = "View Employee Details";
            this.btn_View_Employee_Details.UseVisualStyleBackColor = false;
            this.btn_View_Employee_Details.Click += new System.EventHandler(this.btn_View_Employee_Details_Click);
            // 
            // btn_Update_Employee_Details
            // 
            this.btn_Update_Employee_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Update_Employee_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update_Employee_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Update_Employee_Details.Location = new System.Drawing.Point(347, 302);
            this.btn_Update_Employee_Details.Name = "btn_Update_Employee_Details";
            this.btn_Update_Employee_Details.Size = new System.Drawing.Size(503, 84);
            this.btn_Update_Employee_Details.TabIndex = 13;
            this.btn_Update_Employee_Details.Text = "Update Employee Details";
            this.btn_Update_Employee_Details.UseVisualStyleBackColor = false;
            this.btn_Update_Employee_Details.Click += new System.EventHandler(this.btn_Update_Employee_Details_Click);
            // 
            // btn_Add_New_Employee_Details_
            // 
            this.btn_Add_New_Employee_Details_.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Add_New_Employee_Details_.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_New_Employee_Details_.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Add_New_Employee_Details_.Location = new System.Drawing.Point(347, 169);
            this.btn_Add_New_Employee_Details_.Name = "btn_Add_New_Employee_Details_";
            this.btn_Add_New_Employee_Details_.Size = new System.Drawing.Size(503, 84);
            this.btn_Add_New_Employee_Details_.TabIndex = 12;
            this.btn_Add_New_Employee_Details_.Text = "Add New Employee Details";
            this.btn_Add_New_Employee_Details_.UseVisualStyleBackColor = false;
            this.btn_Add_New_Employee_Details_.Click += new System.EventHandler(this.btn_Add_New_Employee_Details__Click);
            // 
            // frm_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1197, 688);
            this.ControlBox = false;
            this.Controls.Add(this.btn_View_Employee_Details);
            this.Controls.Add(this.btn_Update_Employee_Details);
            this.Controls.Add(this.btn_Add_New_Employee_Details_);
            this.Name = "frm_Employee";
            this.Text = "Employee";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_View_Employee_Details;
        private System.Windows.Forms.Button btn_Update_Employee_Details;
        private System.Windows.Forms.Button btn_Add_New_Employee_Details_;


    }
}