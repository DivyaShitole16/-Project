﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Leaving_Room : Form
    {
        public frm_Leaving_Room()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        void Clear_Controls()
        {
            tb_Student_Id.Clear();
            tb_Name.Clear();
            tb_Room_No.Clear();
            dtp_Leave_Date.ResetText();
            tb_Deposit.Clear();
            tb_Remark.Clear();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            SqlCommand Cmd = new SqlCommand();

            if (tb_Student_Id.Text != "" && tb_Remark.Text != "" && tb_Deposit.Text != "" && tb_Name.Text != "")
            {
                Cmd.CommandText = "Select Status From Student_Details where Student_Id= @Stud_Id";
                Cmd.Connection = Con;

                Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;

                bool Ret = Convert.ToBoolean(Cmd.ExecuteScalar());

                if (Ret == true)
                {
                    Cmd.CommandText = "Update Student_Details Set Status = 0  where Student_Id= @Stud_Id2";
                    Cmd.Connection = Con;

                    Cmd.Parameters.Add("Stud_Id2", SqlDbType.Int).Value = tb_Student_Id.Text;

                    Cmd.ExecuteNonQuery();

                    Cmd.Dispose();

                    Cmd.CommandText = "Select Vacancy From Room_Master where Room_No= @RNo";
                    Cmd.Connection = Con;

                    Cmd.Parameters.Add("RNo", SqlDbType.Int).Value = tb_Room_No.Text;

                    int Vac = Convert.ToInt32(Cmd.ExecuteScalar());

                    Cmd.Dispose();

                    Cmd.CommandText = "Update Room_Master Set Vacancy = @Vc  where Room_No= @RNo1";
                    Cmd.Connection = Con;

                    Cmd.Parameters.Add("RNo1", SqlDbType.Int).Value = tb_Room_No.Text;
                    Cmd.Parameters.Add("Vc", SqlDbType.Int).Value = Vac + 1;

                    Cmd.ExecuteNonQuery();
                    Cmd.Dispose();

                    
                    Cmd.Connection = Con;
                    Cmd.CommandText = "Insert Into Leaving_Room_Details Values(@St_ID,@Nm,@RN,@LDt,@Dp,@Rm)";

                    Cmd.Parameters.Add("St_ID", SqlDbType.Int).Value = tb_Student_Id.Text;
                    Cmd.Parameters.Add("Nm", SqlDbType.VarChar).Value = tb_Name.Text;
                    Cmd.Parameters.Add("RN", SqlDbType.Int).Value = tb_Room_No.Text;
                    Cmd.Parameters.Add("LDt", SqlDbType.Date).Value = dtp_Leave_Date.Text;
                    Cmd.Parameters.Add("Dp", SqlDbType.Money).Value = tb_Deposit.Text;
                    Cmd.Parameters.Add("Rm", SqlDbType.VarChar).Value = tb_Remark.Text;

                    Cmd.ExecuteNonQuery();
              
                    MessageBox.Show("Details Updated Successfully!!!");
                }
                else
                {
                    MessageBox.Show("Student Already Left");
                }
                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }

            Con_Close();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Con_Open();
            SqlDataReader Dr;
            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select * from Student_Details where  Student_Id= @Stud_Id";
            Cmd.Connection = Con;

            Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
            Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                String Name = Dr.GetString(Dr.GetOrdinal("First_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Middle_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Last_Name"));
                tb_Name.Text = Name;

                Cmd.Dispose();
                Dr.Close();

                Cmd.CommandText ="Select * from Room_Allotment where  Student_Id= @Stud_Id1";
                Cmd.Connection = Con;

                Cmd.Parameters.Add("Stud_Id1", SqlDbType.Int).Value = tb_Student_Id.Text;

                Dr = Cmd.ExecuteReader();

                if (Dr.Read())
                {
                    tb_Room_No.Text = (Dr["Room_No"].ToString());
                }

                Cmd.Dispose();
                Dr.Close();

                Cmd.CommandText = "Select Room_No from Room_Allotment where  Student_Id= @Stud_Id2";
                Cmd.Connection = Con;

                Cmd.Parameters.Add("Stud_Id2", SqlDbType.Int).Value = tb_Student_Id.Text;

                Dr = Cmd.ExecuteReader();

                if (Dr.Read())
                {
                    tb_Room_No.Text = (Dr["Room_No"].ToString());
                }
                Cmd.Dispose();
                Dr.Close();

                Cmd.CommandText = "Select Deposit from Payment where Student_Id= @Stud_Id3";
                Cmd.Connection = Con;

                Cmd.Parameters.Add("Stud_Id3", SqlDbType.Int).Value = tb_Student_Id.Text;

                Dr = Cmd.ExecuteReader();

                if (Dr.Read())
                {
                    tb_Deposit.Text = (Dr["Deposit"].ToString());
                }
                Cmd.Dispose();
                Dr.Close();
            }
            else
            {
                MessageBox.Show("No Record Found", "Invalid Student Id");
                tb_Student_Id.Clear();
                Cmd.Dispose();
            }

            Con_Close();
        }

        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) || (e.KeyChar == (Char)Keys.Back) || (e.KeyChar == (Char)Keys.Space)))
            {
                e.Handled = true;
            }
        }    
    }
}
