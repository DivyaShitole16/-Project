﻿namespace Hostel_System
{
    partial class frm_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Add_New_Student_Details_ = new System.Windows.Forms.Button();
            this.btn_Update_Student_Details = new System.Windows.Forms.Button();
            this.btn_View_Student_Details = new System.Windows.Forms.Button();
            this.btn_View_Account_Details = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Add_New_Student_Details_
            // 
            this.btn_Add_New_Student_Details_.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Add_New_Student_Details_.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_New_Student_Details_.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Add_New_Student_Details_.Location = new System.Drawing.Point(321, 67);
            this.btn_Add_New_Student_Details_.Name = "btn_Add_New_Student_Details_";
            this.btn_Add_New_Student_Details_.Size = new System.Drawing.Size(497, 82);
            this.btn_Add_New_Student_Details_.TabIndex = 0;
            this.btn_Add_New_Student_Details_.Text = "Add New Student Details";
            this.btn_Add_New_Student_Details_.UseVisualStyleBackColor = false;
            this.btn_Add_New_Student_Details_.Click += new System.EventHandler(this.btn_Add_New_Student_Details__Click);
            // 
            // btn_Update_Student_Details
            // 
            this.btn_Update_Student_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Update_Student_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update_Student_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Update_Student_Details.Location = new System.Drawing.Point(321, 202);
            this.btn_Update_Student_Details.Name = "btn_Update_Student_Details";
            this.btn_Update_Student_Details.Size = new System.Drawing.Size(497, 75);
            this.btn_Update_Student_Details.TabIndex = 1;
            this.btn_Update_Student_Details.Text = "Update Student Details";
            this.btn_Update_Student_Details.UseVisualStyleBackColor = false;
            this.btn_Update_Student_Details.Click += new System.EventHandler(this.btn_Update_Student_Details_Click);
            // 
            // btn_View_Student_Details
            // 
            this.btn_View_Student_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Student_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Student_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Student_Details.Location = new System.Drawing.Point(321, 331);
            this.btn_View_Student_Details.Name = "btn_View_Student_Details";
            this.btn_View_Student_Details.Size = new System.Drawing.Size(497, 75);
            this.btn_View_Student_Details.TabIndex = 2;
            this.btn_View_Student_Details.Text = "View Student Details";
            this.btn_View_Student_Details.UseVisualStyleBackColor = false;
            this.btn_View_Student_Details.Click += new System.EventHandler(this.btn_View_Student_Details_Click);
            // 
            // btn_View_Account_Details
            // 
            this.btn_View_Account_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_View_Account_Details.Font = new System.Drawing.Font("Century", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Account_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_View_Account_Details.Location = new System.Drawing.Point(321, 448);
            this.btn_View_Account_Details.Name = "btn_View_Account_Details";
            this.btn_View_Account_Details.Size = new System.Drawing.Size(497, 74);
            this.btn_View_Account_Details.TabIndex = 3;
            this.btn_View_Account_Details.Text = "View Account Details";
            this.btn_View_Account_Details.UseVisualStyleBackColor = false;
            this.btn_View_Account_Details.Click += new System.EventHandler(this.btn_View_Account_Details_Click);
            // 
            // frm_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1197, 685);
            this.ControlBox = false;
            this.Controls.Add(this.btn_View_Account_Details);
            this.Controls.Add(this.btn_View_Student_Details);
            this.Controls.Add(this.btn_Update_Student_Details);
            this.Controls.Add(this.btn_Add_New_Student_Details_);
            this.Name = "frm_Student";
            this.Text = "Student";
            this.Load += new System.EventHandler(this.frm_Student_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Add_New_Student_Details_;
        private System.Windows.Forms.Button btn_Update_Student_Details;
        private System.Windows.Forms.Button btn_View_Student_Details;
        private System.Windows.Forms.Button btn_View_Account_Details;

    }
}