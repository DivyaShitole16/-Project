﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Expenses : Form
    {
        public frm_Expenses()
        {
            InitializeComponent();
        }

        private void btn_Add_New_Expenses_Click(object sender, EventArgs e)
        {
            frm_Expenses_Details obj = new frm_Expenses_Details();
            obj.Show();
        }

        private void btn_View_Expenses_Details_Click(object sender, EventArgs e)
        {
            frm_View_Expense_Details Obj = new frm_View_Expense_Details();
            Obj.Show();
            this.Hide();
        }
    }
}
