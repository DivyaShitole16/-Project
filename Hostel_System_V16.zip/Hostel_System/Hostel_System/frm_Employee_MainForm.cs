﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Employee : Form
    {
        public frm_Employee()
        {
            InitializeComponent();
        }

        private void btn_Add_New_Employee_Details__Click(object sender, EventArgs e)
        {
            frm_Add_New_Employee obj =  new frm_Add_New_Employee();
            obj.Show();
            this.Hide();
        }

        private void btn_Update_Employee_Details_Click(object sender, EventArgs e)
        {
            frm_Update_Employee_Details obj = new frm_Update_Employee_Details();
            obj.Show();
            this.Hide();
        }

        private void btn_View_Employee_Details_Click(object sender, EventArgs e)
        {
            frm_View_Employee_Details obj = new frm_View_Employee_Details();
            obj.Show();
            this.Hide();
        }
       
    }
}
