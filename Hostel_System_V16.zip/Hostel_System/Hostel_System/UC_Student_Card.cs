﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class UC_Student_Card : UserControl
    {
        public UC_Student_Card()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
        private void UC_Student_Card_Load(object sender, EventArgs e)
        {
            tb_Student_Id.Text = Convert.ToString(Shared_Class.Stud_ID);

            Con_Open();

            SqlCommand Cmd = new SqlCommand("Select * from Student_Details where Student_Id = @SID", Con);

            Cmd.Parameters.Add("SID", SqlDbType.VarChar).Value = tb_Student_Id.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                tb_Name.Text =  Dr.GetString(Dr.GetOrdinal("First_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Middle_Name")) + " " + Dr.GetString(Dr.GetOrdinal("Last_Name"));
                tb_Mobile_No.Text = (Dr["Mobile_No1"].ToString());
                tb_Mob2.Text = (Dr["Mobile_No2"].ToString());
                tb_Course.Text = Dr.GetString(Dr.GetOrdinal("Course"));
                dtp_Date.Text = (Dr["Date"].ToString());
            }

            Cmd.Dispose();
            Dr.Close();

            Con_Close();
        }

        private void btn_View_Student_Details_Click(object sender, EventArgs e)
        {

        }
    }
}
