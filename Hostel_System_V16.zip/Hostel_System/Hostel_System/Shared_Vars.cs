﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hostel_System
{
    class Shared_Vars
    {
        public static int ID = 0;
        public static string Name = "";
        public static long Mob_No = 0;
        public static string Room_type = "";
    }
}
