﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Room_Master : Form
    {
        public frm_Room_Master()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }

        int Auto_Incr()
        {
                int Cnt = 0;
                Con_Open();

                SqlCommand Cmd = new SqlCommand();
   
                Cmd.Connection = Con;
                Cmd.CommandText = "Select Count(*) From Room_Master where Floor = '" + cmb_Floor.Text + "'";

                Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

                if (Cnt > 0)
                {
                    Cmd.CommandText = "Select Max(Room_No)From Room_Master where Floor = '" + cmb_Floor.Text + "'";
                    Cnt = Convert.ToInt32(Cmd.ExecuteScalar()) + 1;
                }
                else
                {
                    if (cmb_Floor.SelectedIndex == 0)
                    {
                        Cnt = 101;
                    }
                    else
                    {
                        Cnt = 201;
                    }
                }

                Con_Close();
                return Cnt;
        }

        void Clear_Controls()
        {
            tb_Room_No.Clear();
            cmb_Room_type.SelectedIndex=-1;
            tb_Capacity.Clear();
            cmb_Floor.SelectedIndex = -1;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if ( cmb_Room_type.Text != "" && tb_Capacity.Text != "" && cmb_Floor.Text != "" && tb_Room_No.Text != "" )
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Room_Master Values( @R_No, @R_Type, @Capacity, @Floor, @Vac)";

                Cmd.Parameters.Add("R_No", SqlDbType.Int).Value = tb_Room_No.Text;
                Cmd.Parameters.Add("R_type", SqlDbType.VarChar).Value = cmb_Room_type.Text;
                Cmd.Parameters.Add("Capacity", SqlDbType.Int).Value = tb_Capacity.Text;
                Cmd.Parameters.Add("Floor", SqlDbType.NVarChar).Value = cmb_Floor.Text;
                Cmd.Parameters.Add("Vac", SqlDbType.Int).Value = tb_Capacity.Text;
               
                Cmd.ExecuteNonQuery();

                MessageBox.Show("Record Saved");

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }
            Con_Close();

        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void frm_Room_Master_Load(object sender, EventArgs e)
        {
            Clear_Controls();
            cmb_Floor.Focus();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmb_Floor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Floor.Text != "")
            {
                tb_Room_No.Text = Convert.ToString(Auto_Incr());
            }
        }

        private void cmb_Room_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Room_type.SelectedIndex == 0)
            {
                tb_Capacity.Text = "2";
            }
            else if (cmb_Room_type.SelectedIndex == 1)
            {
                tb_Capacity.Text = "3";
            }
            else if (cmb_Room_type.SelectedIndex == 2)
            {
                tb_Capacity.Text = "4";
            }
        }

        
    }
}
