﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Hostel_System
{
    public partial class frm_Room_Reallotment : Form
    {
        public frm_Room_Reallotment()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Hostel_System;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
            }
        }
        void Con_Close()
        {
            if (Con.State != ConnectionState.Closed)
            {
                Con.Close();
            }
        }
        void Clear_Controls()
        {
            tb_Student_Id.Clear();
            tb_Name.Clear();
            tb_Floor.Clear();
            tb_Room_Type.Clear();
            tb_Room_No.Clear();
            dtp_Allocation_Date.ResetText();
            cmb_New_Floor.SelectedIndex = -1;
            cmb_New_Room_Type.SelectedIndex = -1;
            cmb_New_Room_No.SelectedIndex = -1;
            tb_Vacancy.Clear();

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (tb_Student_Id.Text != "" && dtp_Allocation_Date.Text != "" && cmb_New_Floor.Text != "" && cmb_New_Room_Type.Text != "" && cmb_New_Room_No.Text != "" )
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.Connection = Con;
                Cmd.CommandText = "Insert Into Reallocation_Details Values(@Stud_Id,@A_Date,@Floor,@R_Type,@R_No)";

                Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;
                Cmd.Parameters.Add("A_Date", SqlDbType.Date).Value =  dtp_Allocation_Date.Value.Date;
                Cmd.Parameters.Add("Floor", SqlDbType.NVarChar).Value = cmb_New_Floor.Text;
                Cmd.Parameters.Add("R_Type", SqlDbType.NVarChar).Value = cmb_New_Room_Type.Text;
                Cmd.Parameters.Add("R_No", SqlDbType.Int).Value = cmb_New_Room_No.Text;
                

                Cmd.ExecuteNonQuery();
                Shared_Vars.Room_type = cmb_New_Room_Type.Text;

                Cmd.Connection = Con;
                Cmd.CommandText = "Update Room_Master Set Vacancy = @Vac where Room_No = @RNo";

                Cmd.Parameters.Add("RNo", SqlDbType.Int).Value = cmb_New_Room_No.Text;
                Cmd.Parameters.Add("Vac", SqlDbType.Int).Value = Convert.ToInt32(tb_Vacancy.Text) - 1;

                Cmd.ExecuteNonQuery();

                MessageBox.Show("Record Saved");

                
            }
            else
            {
                MessageBox.Show("Fill All Fields");
            }
            Con_Close();
            Clear_Controls();
            
        }
       
        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_Room_Reallotment_Load(object sender, EventArgs e)
        {
            lbl_Student_Id.Focus();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Con_Open();
            SqlCommand Cmd = new SqlCommand("Select * from Room_Allotment where  Student_Id= @Stud_Id", Con);
            
            Cmd.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                tb_Floor.Text = (Dr["Floor"].ToString());
                tb_Room_Type.Text = (Dr["Room_Type"].ToString());
                tb_Room_No.Text = (Dr["Room_No"].ToString());
            } 
            else
            {
                MessageBox.Show("No Record Found", "Invalid Student Id");
                tb_Student_Id.Clear();
                Cmd.Dispose();
                return;
            }

            Dr.Close();

            SqlCommand Cmd1 = new SqlCommand("Select * from Student_Details where  Student_Id= @Stud_Id", Con);

            Cmd1.Parameters.Add("Stud_Id", SqlDbType.Int).Value = tb_Student_Id.Text;

            SqlDataReader Dr1 = Cmd1.ExecuteReader();

            if (Dr1.Read())
            {
                String Name = Dr1.GetString(Dr1.GetOrdinal("First_Name")) + " " + Dr1.GetString(Dr1.GetOrdinal("Middle_Name")) + " " + Dr1.GetString(Dr1.GetOrdinal("Last_Name"));
                tb_Name.Text = Name; 
            }
            else
            {
                MessageBox.Show("No Record Found", "Invalid Student Id");
                tb_Student_Id.Clear();
                Cmd1.Dispose();
            }
            Con_Close();

        }
        private void Only_Numeric(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (Char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void cmb_New_Room_Type_SelectedIndexChanged(object sender, EventArgs e)
        {
            Con_Open();

            
            SqlCommand Cmd = new SqlCommand("Select Room_No from Room_Master where Vacancy > 0 And Floor = @Flr And Room_Type = @Rtype ", Con);

            Cmd.Parameters.Add("Flr", SqlDbType.VarChar).Value = cmb_New_Floor.Text;
            Cmd.Parameters.Add("RType", SqlDbType.NVarChar).Value = cmb_New_Room_Type.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            while (Dr.Read())
            {
                cmb_New_Room_No.Items.Add(Dr["Room_No"].ToString());
            }

            Con_Close();
        }

        private void cmb_New_Room_No_SelectedIndexChanged(object sender, EventArgs e)
        {
            Con_Open();

            SqlCommand Cmd = new SqlCommand("Select Vacancy from Room_Master where Room_No = @R_No", Con);

            Cmd.Parameters.Add("R_No", SqlDbType.Int).Value = cmb_New_Room_No.Text;

            SqlDataReader Dr = Cmd.ExecuteReader();

            if (Dr.Read())
            {
                tb_Vacancy.Text = Dr["Vacancy"].ToString();
            }
            Con_Close();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }
       
    }
}
