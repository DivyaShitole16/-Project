﻿namespace Hostel_System
{
    partial class frm_Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Dashboard));
            this.pnl_Menu = new System.Windows.Forms.Panel();
            this.btn_Reports = new System.Windows.Forms.Button();
            this.btn_Charges = new System.Windows.Forms.Button();
            this.btn_Expenses = new System.Windows.Forms.Button();
            this.btn_Payment = new System.Windows.Forms.Button();
            this.btn_Room = new System.Windows.Forms.Button();
            this.btn_Employee = new System.Windows.Forms.Button();
            this.btn_Student = new System.Windows.Forms.Button();
            this.pnl_Logo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_Title = new System.Windows.Forms.Panel();
            this.lbl_Home = new System.Windows.Forms.Label();
            this.pnl_Desktop = new System.Windows.Forms.Panel();
            this.pnl_Menu.SuspendLayout();
            this.pnl_Logo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_Title.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Menu
            // 
            this.pnl_Menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnl_Menu.Controls.Add(this.btn_Reports);
            this.pnl_Menu.Controls.Add(this.btn_Charges);
            this.pnl_Menu.Controls.Add(this.btn_Expenses);
            this.pnl_Menu.Controls.Add(this.btn_Payment);
            this.pnl_Menu.Controls.Add(this.btn_Room);
            this.pnl_Menu.Controls.Add(this.btn_Employee);
            this.pnl_Menu.Controls.Add(this.btn_Student);
            this.pnl_Menu.Controls.Add(this.pnl_Logo);
            this.pnl_Menu.Location = new System.Drawing.Point(-3, 0);
            this.pnl_Menu.Name = "pnl_Menu";
            this.pnl_Menu.Size = new System.Drawing.Size(336, 820);
            this.pnl_Menu.TabIndex = 0;
            // 
            // btn_Reports
            // 
            this.btn_Reports.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Reports.FlatAppearance.BorderSize = 0;
            this.btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reports.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reports.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Reports.Image = ((System.Drawing.Image)(resources.GetObject("btn_Reports.Image")));
            this.btn_Reports.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Reports.Location = new System.Drawing.Point(0, 726);
            this.btn_Reports.Name = "btn_Reports";
            this.btn_Reports.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Reports.Size = new System.Drawing.Size(330, 79);
            this.btn_Reports.TabIndex = 6;
            this.btn_Reports.Text = "   Reports";
            this.btn_Reports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Reports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Reports.UseVisualStyleBackColor = true;
            // 
            // btn_Charges
            // 
            this.btn_Charges.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Charges.FlatAppearance.BorderSize = 0;
            this.btn_Charges.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Charges.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Charges.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Charges.Image = ((System.Drawing.Image)(resources.GetObject("btn_Charges.Image")));
            this.btn_Charges.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Charges.Location = new System.Drawing.Point(3, 624);
            this.btn_Charges.Name = "btn_Charges";
            this.btn_Charges.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Charges.Size = new System.Drawing.Size(330, 79);
            this.btn_Charges.TabIndex = 5;
            this.btn_Charges.Text = "   Charges";
            this.btn_Charges.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Charges.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Charges.UseVisualStyleBackColor = true;
            this.btn_Charges.Click += new System.EventHandler(this.btn_Charges_Click);
            // 
            // btn_Expenses
            // 
            this.btn_Expenses.FlatAppearance.BorderSize = 0;
            this.btn_Expenses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Expenses.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Expenses.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Expenses.Image = ((System.Drawing.Image)(resources.GetObject("btn_Expenses.Image")));
            this.btn_Expenses.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Expenses.Location = new System.Drawing.Point(3, 526);
            this.btn_Expenses.Name = "btn_Expenses";
            this.btn_Expenses.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Expenses.Size = new System.Drawing.Size(330, 81);
            this.btn_Expenses.TabIndex = 2;
            this.btn_Expenses.Text = "   Expenses";
            this.btn_Expenses.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Expenses.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Expenses.UseVisualStyleBackColor = true;
            this.btn_Expenses.Click += new System.EventHandler(this.btn_Expenses_Click);
            // 
            // btn_Payment
            // 
            this.btn_Payment.FlatAppearance.BorderSize = 0;
            this.btn_Payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Payment.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Payment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Payment.Image = ((System.Drawing.Image)(resources.GetObject("btn_Payment.Image")));
            this.btn_Payment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Payment.Location = new System.Drawing.Point(3, 431);
            this.btn_Payment.Name = "btn_Payment";
            this.btn_Payment.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Payment.Size = new System.Drawing.Size(330, 75);
            this.btn_Payment.TabIndex = 4;
            this.btn_Payment.Text = "   Payment";
            this.btn_Payment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Payment.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Payment.UseVisualStyleBackColor = true;
            this.btn_Payment.Click += new System.EventHandler(this.btn_Payment_Click);
            // 
            // btn_Room
            // 
            this.btn_Room.FlatAppearance.BorderSize = 0;
            this.btn_Room.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Room.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Room.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Room.Image = ((System.Drawing.Image)(resources.GetObject("btn_Room.Image")));
            this.btn_Room.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Room.Location = new System.Drawing.Point(3, 334);
            this.btn_Room.Name = "btn_Room";
            this.btn_Room.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Room.Size = new System.Drawing.Size(330, 74);
            this.btn_Room.TabIndex = 3;
            this.btn_Room.Text = "   Room";
            this.btn_Room.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Room.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Room.UseVisualStyleBackColor = true;
            this.btn_Room.Click += new System.EventHandler(this.btn_Room_Click);
            // 
            // btn_Employee
            // 
            this.btn_Employee.FlatAppearance.BorderSize = 0;
            this.btn_Employee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Employee.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Employee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Employee.Image = ((System.Drawing.Image)(resources.GetObject("btn_Employee.Image")));
            this.btn_Employee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Employee.Location = new System.Drawing.Point(3, 235);
            this.btn_Employee.Name = "btn_Employee";
            this.btn_Employee.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Employee.Size = new System.Drawing.Size(333, 77);
            this.btn_Employee.TabIndex = 2;
            this.btn_Employee.Text = "   Employee";
            this.btn_Employee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Employee.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Employee.UseVisualStyleBackColor = true;
            this.btn_Employee.Click += new System.EventHandler(this.btn_Employee_Click);
            // 
            // btn_Student
            // 
            this.btn_Student.FlatAppearance.BorderSize = 0;
            this.btn_Student.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Student.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Student.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Student.Image = ((System.Drawing.Image)(resources.GetObject("btn_Student.Image")));
            this.btn_Student.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Student.Location = new System.Drawing.Point(6, 143);
            this.btn_Student.Name = "btn_Student";
            this.btn_Student.Padding = new System.Windows.Forms.Padding(12, 0, 0, 0);
            this.btn_Student.Size = new System.Drawing.Size(327, 69);
            this.btn_Student.TabIndex = 1;
            this.btn_Student.Text = "   Student";
            this.btn_Student.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Student.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_Student.UseVisualStyleBackColor = true;
            this.btn_Student.Click += new System.EventHandler(this.btn_Student_Click);
            // 
            // pnl_Logo
            // 
            this.pnl_Logo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.pnl_Logo.Controls.Add(this.pictureBox1);
            this.pnl_Logo.Location = new System.Drawing.Point(0, 3);
            this.pnl_Logo.Name = "pnl_Logo";
            this.pnl_Logo.Size = new System.Drawing.Size(336, 134);
            this.pnl_Logo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(339, 134);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_Title
            // 
            this.pnl_Title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.pnl_Title.Controls.Add(this.lbl_Home);
            this.pnl_Title.Location = new System.Drawing.Point(333, 0);
            this.pnl_Title.Name = "pnl_Title";
            this.pnl_Title.Size = new System.Drawing.Size(1213, 135);
            this.pnl_Title.TabIndex = 1;
            // 
            // lbl_Home
            // 
            this.lbl_Home.AutoSize = true;
            this.lbl_Home.Font = new System.Drawing.Font("Century", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Home.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Home.Location = new System.Drawing.Point(420, 45);
            this.lbl_Home.Name = "lbl_Home";
            this.lbl_Home.Size = new System.Drawing.Size(153, 55);
            this.lbl_Home.TabIndex = 0;
            this.lbl_Home.Text = "Home";
            // 
            // pnl_Desktop
            // 
            this.pnl_Desktop.Location = new System.Drawing.Point(333, 133);
            this.pnl_Desktop.Name = "pnl_Desktop";
            this.pnl_Desktop.Size = new System.Drawing.Size(1213, 687);
            this.pnl_Desktop.TabIndex = 2;
            // 
            // frm_Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1548, 817);
            this.Controls.Add(this.pnl_Desktop);
            this.Controls.Add(this.pnl_Title);
            this.Controls.Add(this.pnl_Menu);
            this.Name = "frm_Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.pnl_Menu.ResumeLayout(false);
            this.pnl_Logo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_Title.ResumeLayout(false);
            this.pnl_Title.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Menu;
        private System.Windows.Forms.Button btn_Student;
        private System.Windows.Forms.Panel pnl_Logo;
        private System.Windows.Forms.Button btn_Expenses;
        private System.Windows.Forms.Button btn_Payment;
        private System.Windows.Forms.Button btn_Room;
        private System.Windows.Forms.Button btn_Employee;
        private System.Windows.Forms.Button btn_Charges;
        private System.Windows.Forms.Panel pnl_Title;
        private System.Windows.Forms.Label lbl_Home;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnl_Desktop;
        private System.Windows.Forms.Button btn_Reports;

    }
}