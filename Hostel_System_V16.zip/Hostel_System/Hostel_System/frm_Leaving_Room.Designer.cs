﻿namespace Hostel_System
{
    partial class frm_Leaving_Room
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_Leave_Date = new System.Windows.Forms.DateTimePicker();
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.lbl_Leaving_Room = new System.Windows.Forms.Label();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb_Room_No = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.lbl_Remark = new System.Windows.Forms.Label();
            this.tb_Remark = new System.Windows.Forms.TextBox();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.lbl_Deposite = new System.Windows.Forms.Label();
            this.lbl_Leave_Date = new System.Windows.Forms.Label();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Student_Id = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Leave_Date
            // 
            this.dtp_Leave_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Leave_Date.Location = new System.Drawing.Point(695, 269);
            this.dtp_Leave_Date.Name = "dtp_Leave_Date";
            this.dtp_Leave_Date.Size = new System.Drawing.Size(330, 38);
            this.dtp_Leave_Date.TabIndex = 4;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Save.Location = new System.Drawing.Point(729, 676);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 65);
            this.btn_Save.TabIndex = 4;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_Name
            // 
            this.tb_Name.Enabled = false;
            this.tb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(695, 106);
            this.tb_Name.MaxLength = 60;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(330, 38);
            this.tb_Name.TabIndex = 2;
            // 
            // lbl_Leaving_Room
            // 
            this.lbl_Leaving_Room.AutoSize = true;
            this.lbl_Leaving_Room.Font = new System.Drawing.Font("Times New Roman", 30.2F, System.Drawing.FontStyle.Bold);
            this.lbl_Leaving_Room.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Leaving_Room.Location = new System.Drawing.Point(553, 4);
            this.lbl_Leaving_Room.Name = "lbl_Leaving_Room";
            this.lbl_Leaving_Room.Size = new System.Drawing.Size(344, 58);
            this.lbl_Leaving_Room.TabIndex = 0;
            this.lbl_Leaving_Room.Text = "Leaving Room";
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(695, 26);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(330, 38);
            this.tb_Student_Id.TabIndex = 1;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.tb_Room_No);
            this.panel2.Controls.Add(this.btn_Search);
            this.panel2.Controls.Add(this.lbl_Remark);
            this.panel2.Controls.Add(this.tb_Remark);
            this.panel2.Controls.Add(this.tb_Deposit);
            this.panel2.Controls.Add(this.lbl_Deposite);
            this.panel2.Controls.Add(this.dtp_Leave_Date);
            this.panel2.Controls.Add(this.tb_Name);
            this.panel2.Controls.Add(this.tb_Student_Id);
            this.panel2.Controls.Add(this.lbl_Leave_Date);
            this.panel2.Controls.Add(this.lbl_Room_No);
            this.panel2.Controls.Add(this.lbl_Name);
            this.panel2.Controls.Add(this.lbl_Student_Id);
            this.panel2.Location = new System.Drawing.Point(12, 134);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1408, 513);
            this.panel2.TabIndex = 25;
            // 
            // tb_Room_No
            // 
            this.tb_Room_No.Enabled = false;
            this.tb_Room_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Room_No.Location = new System.Drawing.Point(695, 183);
            this.tb_Room_No.MaxLength = 50;
            this.tb_Room_No.Name = "tb_Room_No";
            this.tb_Room_No.Size = new System.Drawing.Size(330, 38);
            this.tb_Room_No.TabIndex = 0;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Search.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Search.Location = new System.Drawing.Point(1094, 17);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(191, 55);
            this.btn_Search.TabIndex = 2;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // lbl_Remark
            // 
            this.lbl_Remark.AutoSize = true;
            this.lbl_Remark.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Remark.ForeColor = System.Drawing.Color.Black;
            this.lbl_Remark.Location = new System.Drawing.Point(362, 447);
            this.lbl_Remark.Name = "lbl_Remark";
            this.lbl_Remark.Size = new System.Drawing.Size(109, 31);
            this.lbl_Remark.TabIndex = 8;
            this.lbl_Remark.Text = "Remark";
            // 
            // tb_Remark
            // 
            this.tb_Remark.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Remark.Location = new System.Drawing.Point(695, 445);
            this.tb_Remark.MaxLength = 40;
            this.tb_Remark.Name = "tb_Remark";
            this.tb_Remark.Size = new System.Drawing.Size(330, 38);
            this.tb_Remark.TabIndex = 3;
            this.tb_Remark.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Enabled = false;
            this.tb_Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Deposit.Location = new System.Drawing.Point(695, 357);
            this.tb_Deposit.MaxLength = 7;
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(330, 38);
            this.tb_Deposit.TabIndex = 5;
            // 
            // lbl_Deposite
            // 
            this.lbl_Deposite.AutoSize = true;
            this.lbl_Deposite.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Deposite.ForeColor = System.Drawing.Color.Black;
            this.lbl_Deposite.Location = new System.Drawing.Point(362, 359);
            this.lbl_Deposite.Name = "lbl_Deposite";
            this.lbl_Deposite.Size = new System.Drawing.Size(115, 31);
            this.lbl_Deposite.TabIndex = 7;
            this.lbl_Deposite.Text = "Deposite";
            // 
            // lbl_Leave_Date
            // 
            this.lbl_Leave_Date.AutoSize = true;
            this.lbl_Leave_Date.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Leave_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Leave_Date.Location = new System.Drawing.Point(362, 272);
            this.lbl_Leave_Date.Name = "lbl_Leave_Date";
            this.lbl_Leave_Date.Size = new System.Drawing.Size(146, 31);
            this.lbl_Leave_Date.TabIndex = 0;
            this.lbl_Leave_Date.Text = "Leave Date";
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(362, 185);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(132, 31);
            this.lbl_Room_No.TabIndex = 0;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(362, 108);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(82, 31);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Student_Id
            // 
            this.lbl_Student_Id.AutoSize = true;
            this.lbl_Student_Id.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Id.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Id.Location = new System.Drawing.Point(362, 28);
            this.lbl_Student_Id.Name = "lbl_Student_Id";
            this.lbl_Student_Id.Size = new System.Drawing.Size(141, 31);
            this.lbl_Student_Id.TabIndex = 0;
            this.lbl_Student_Id.Text = "Student ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel1.Controls.Add(this.btn_Back);
            this.panel1.Controls.Add(this.lbl_Leaving_Room);
            this.panel1.Location = new System.Drawing.Point(-2, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1432, 73);
            this.panel1.TabIndex = 23;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(3, 7);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 55);
            this.btn_Back.TabIndex = 14;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Refresh.Location = new System.Drawing.Point(408, 676);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 65);
            this.btn_Refresh.TabIndex = 26;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // frm_Leaving_Room
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Leaving_Room";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Leaving Room";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Leave_Date;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.Label lbl_Leaving_Room;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl_Remark;
        private System.Windows.Forms.TextBox tb_Remark;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.Label lbl_Leave_Date;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Student_Id;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.TextBox tb_Room_No;
        private System.Windows.Forms.Label lbl_Deposite;
    }
}