﻿namespace Hostel_System
{
    partial class frm_Room_Allotment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_Room_Allotment = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.gb_Room_Details = new System.Windows.Forms.GroupBox();
            this.cmb_Room_Type = new System.Windows.Forms.ComboBox();
            this.lbl_Room_Type = new System.Windows.Forms.Label();
            this.cmb_Room_No = new System.Windows.Forms.ComboBox();
            this.tb_Vacancy = new System.Windows.Forms.TextBox();
            this.cmb_Floor = new System.Windows.Forms.ComboBox();
            this.lbl_Vacancy = new System.Windows.Forms.Label();
            this.lbl_Floor = new System.Windows.Forms.Label();
            this.lbl_Room_No = new System.Windows.Forms.Label();
            this.gb_Student_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.gb_Room_Details.SuspendLayout();
            this.gb_Student_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Save.Location = new System.Drawing.Point(889, 649);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(237, 69);
            this.btn_Save.TabIndex = 5;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // lbl_Room_Allotment
            // 
            this.lbl_Room_Allotment.AutoSize = true;
            this.lbl_Room_Allotment.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Room_Allotment.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Allotment.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Room_Allotment.Location = new System.Drawing.Point(558, 7);
            this.lbl_Room_Allotment.Name = "lbl_Room_Allotment";
            this.lbl_Room_Allotment.Size = new System.Drawing.Size(374, 57);
            this.lbl_Room_Allotment.TabIndex = 0;
            this.lbl_Room_Allotment.Text = "Room Allotment";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel1.Controls.Add(this.btn_Back);
            this.panel1.Controls.Add(this.lbl_Room_Allotment);
            this.panel1.Location = new System.Drawing.Point(-2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1439, 78);
            this.panel1.TabIndex = 23;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(3, 3);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 67);
            this.btn_Back.TabIndex = 29;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // gb_Room_Details
            // 
            this.gb_Room_Details.BackColor = System.Drawing.Color.Lavender;
            this.gb_Room_Details.Controls.Add(this.cmb_Room_Type);
            this.gb_Room_Details.Controls.Add(this.lbl_Room_Type);
            this.gb_Room_Details.Controls.Add(this.cmb_Room_No);
            this.gb_Room_Details.Controls.Add(this.tb_Vacancy);
            this.gb_Room_Details.Controls.Add(this.cmb_Floor);
            this.gb_Room_Details.Controls.Add(this.lbl_Vacancy);
            this.gb_Room_Details.Controls.Add(this.lbl_Floor);
            this.gb_Room_Details.Controls.Add(this.lbl_Room_No);
            this.gb_Room_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Room_Details.ForeColor = System.Drawing.Color.Purple;
            this.gb_Room_Details.Location = new System.Drawing.Point(710, 136);
            this.gb_Room_Details.Name = "gb_Room_Details";
            this.gb_Room_Details.Size = new System.Drawing.Size(695, 458);
            this.gb_Room_Details.TabIndex = 25;
            this.gb_Room_Details.TabStop = false;
            this.gb_Room_Details.Text = "Room Details";
            // 
            // cmb_Room_Type
            // 
            this.cmb_Room_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Room_Type.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_Type.FormattingEnabled = true;
            this.cmb_Room_Type.Items.AddRange(new object[] {
            "2 Bed",
            "3 Bed",
            "4 Bed"});
            this.cmb_Room_Type.Location = new System.Drawing.Point(312, 148);
            this.cmb_Room_Type.Name = "cmb_Room_Type";
            this.cmb_Room_Type.Size = new System.Drawing.Size(303, 39);
            this.cmb_Room_Type.TabIndex = 2;
            this.cmb_Room_Type.SelectedIndexChanged += new System.EventHandler(this.cmb_Room_Type_SelectedIndexChanged);
            // 
            // lbl_Room_Type
            // 
            this.lbl_Room_Type.AutoSize = true;
            this.lbl_Room_Type.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_Type.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_Type.Location = new System.Drawing.Point(33, 155);
            this.lbl_Room_Type.Name = "lbl_Room_Type";
            this.lbl_Room_Type.Size = new System.Drawing.Size(149, 32);
            this.lbl_Room_Type.TabIndex = 10;
            this.lbl_Room_Type.Text = "Room Type";
            // 
            // cmb_Room_No
            // 
            this.cmb_Room_No.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Room_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Room_No.FormattingEnabled = true;
            this.cmb_Room_No.Location = new System.Drawing.Point(312, 252);
            this.cmb_Room_No.Name = "cmb_Room_No";
            this.cmb_Room_No.Size = new System.Drawing.Size(303, 39);
            this.cmb_Room_No.TabIndex = 3;
            this.cmb_Room_No.SelectedIndexChanged += new System.EventHandler(this.cmb_Room_No_SelectedIndexChanged);
            // 
            // tb_Vacancy
            // 
            this.tb_Vacancy.Enabled = false;
            this.tb_Vacancy.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Vacancy.Location = new System.Drawing.Point(312, 353);
            this.tb_Vacancy.MaxLength = 20;
            this.tb_Vacancy.Name = "tb_Vacancy";
            this.tb_Vacancy.Size = new System.Drawing.Size(303, 39);
            this.tb_Vacancy.TabIndex = 4;
            // 
            // cmb_Floor
            // 
            this.cmb_Floor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Floor.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Floor.FormattingEnabled = true;
            this.cmb_Floor.Items.AddRange(new object[] {
            "1 st Floor",
            "2 nd Floor"});
            this.cmb_Floor.Location = new System.Drawing.Point(312, 53);
            this.cmb_Floor.Name = "cmb_Floor";
            this.cmb_Floor.Size = new System.Drawing.Size(303, 39);
            this.cmb_Floor.TabIndex = 1;
            // 
            // lbl_Vacancy
            // 
            this.lbl_Vacancy.AutoSize = true;
            this.lbl_Vacancy.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Vacancy.ForeColor = System.Drawing.Color.Black;
            this.lbl_Vacancy.Location = new System.Drawing.Point(42, 357);
            this.lbl_Vacancy.Name = "lbl_Vacancy";
            this.lbl_Vacancy.Size = new System.Drawing.Size(114, 32);
            this.lbl_Vacancy.TabIndex = 0;
            this.lbl_Vacancy.Text = "Vacancy";
            // 
            // lbl_Floor
            // 
            this.lbl_Floor.AutoSize = true;
            this.lbl_Floor.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Floor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Floor.Location = new System.Drawing.Point(42, 58);
            this.lbl_Floor.Name = "lbl_Floor";
            this.lbl_Floor.Size = new System.Drawing.Size(81, 32);
            this.lbl_Floor.TabIndex = 0;
            this.lbl_Floor.Text = "Floor";
            // 
            // lbl_Room_No
            // 
            this.lbl_Room_No.AutoSize = true;
            this.lbl_Room_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Room_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Room_No.Location = new System.Drawing.Point(33, 257);
            this.lbl_Room_No.Name = "lbl_Room_No";
            this.lbl_Room_No.Size = new System.Drawing.Size(133, 32);
            this.lbl_Room_No.TabIndex = 0;
            this.lbl_Room_No.Text = "Room No.";
            // 
            // gb_Student_Details
            // 
            this.gb_Student_Details.BackColor = System.Drawing.Color.Lavender;
            this.gb_Student_Details.Controls.Add(this.dtp_Date);
            this.gb_Student_Details.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.tb_Name);
            this.gb_Student_Details.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Details.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Details.Controls.Add(this.lbl_Date);
            this.gb_Student_Details.Controls.Add(this.lbl_Name);
            this.gb_Student_Details.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Details.ForeColor = System.Drawing.Color.Purple;
            this.gb_Student_Details.Location = new System.Drawing.Point(25, 136);
            this.gb_Student_Details.Name = "gb_Student_Details";
            this.gb_Student_Details.Size = new System.Drawing.Size(644, 458);
            this.gb_Student_Details.TabIndex = 26;
            this.gb_Student_Details.TabStop = false;
            this.gb_Student_Details.Text = "Student Details";
            // 
            // dtp_Date
            // 
            this.dtp_Date.Enabled = false;
            this.dtp_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(298, 353);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(288, 39);
            this.dtp_Date.TabIndex = 0;
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Enabled = false;
            this.tb_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(298, 254);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(288, 39);
            this.tb_Mobile_No.TabIndex = 0;
            this.tb_Mobile_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Name
            // 
            this.tb_Name.Enabled = false;
            this.tb_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Name.Location = new System.Drawing.Point(298, 152);
            this.tb_Name.MaxLength = 50;
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(288, 39);
            this.tb_Name.TabIndex = 0;
            this.tb_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Enabled = false;
            this.tb_Student_Id.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(298, 56);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(288, 39);
            this.tb_Student_Id.TabIndex = 0;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(33, 257);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(147, 32);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.Black;
            this.lbl_Date.Location = new System.Drawing.Point(33, 357);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(70, 32);
            this.lbl_Date.TabIndex = 0;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Name.Location = new System.Drawing.Point(33, 155);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(83, 32);
            this.lbl_Name.TabIndex = 0;
            this.lbl_Name.Text = "Name";
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(33, 57);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(146, 32);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Refresh.Location = new System.Drawing.Point(362, 649);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 69);
            this.btn_Refresh.TabIndex = 28;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            // 
            // frm_Room_Allotment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.ControlBox = false;
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.gb_Room_Details);
            this.Controls.Add(this.gb_Student_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.panel1);
            this.Name = "frm_Room_Allotment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Allotment";
            this.Load += new System.EventHandler(this.frm_Room_Allotment_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Room_Details.ResumeLayout(false);
            this.gb_Room_Details.PerformLayout();
            this.gb_Student_Details.ResumeLayout(false);
            this.gb_Student_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_Room_Allotment;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gb_Room_Details;
        private System.Windows.Forms.Label lbl_Vacancy;
        private System.Windows.Forms.Label lbl_Room_No;
        private System.Windows.Forms.GroupBox gb_Student_Details;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.TextBox tb_Vacancy;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.ComboBox cmb_Floor;
        private System.Windows.Forms.Label lbl_Floor;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.ComboBox cmb_Room_Type;
        private System.Windows.Forms.Label lbl_Room_Type;
        private System.Windows.Forms.ComboBox cmb_Room_No;
    }
}