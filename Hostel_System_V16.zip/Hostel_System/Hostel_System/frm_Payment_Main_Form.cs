﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hostel_System
{
    public partial class frm_Payment_Main_Form : Form
    {
        public frm_Payment_Main_Form()
        {
            InitializeComponent();
        }

        private void btn_Mess_Payment_details_Click(object sender, EventArgs e)
        {
            frm_Mess_Payment_Details obj = new frm_Mess_Payment_Details();
            obj.Show();
        }

        private void btn_Repayment_Details_Click(object sender, EventArgs e)
        {
            frm_Repayment obj = new frm_Repayment();
            obj.Show();

        }
        private void btn_View_Mess_Payment_Details_Click(object sender, EventArgs e)
        {
            frm_View_Mess_Payment_List Obj = new frm_View_Mess_Payment_List();
            Obj.Show();
            this.Hide();
        }

    }
}
