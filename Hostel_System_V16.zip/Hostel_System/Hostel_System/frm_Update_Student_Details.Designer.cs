﻿namespace Hostel_System
{
    partial class frm_Update_Student_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Relationship = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_Update_Student_Details = new System.Windows.Forms.Label();
            this.gb_Others_Information = new System.Windows.Forms.GroupBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Course = new System.Windows.Forms.TextBox();
            this.tb_College_Name = new System.Windows.Forms.TextBox();
            this.lbl_Student_Address = new System.Windows.Forms.Label();
            this.lbl_Course = new System.Windows.Forms.Label();
            this.lbl_College_Name = new System.Windows.Forms.Label();
            this.lbl_Relationship = new System.Windows.Forms.Label();
            this.gb_Guardian_Information = new System.Windows.Forms.GroupBox();
            this.tb_Note = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No2 = new System.Windows.Forms.TextBox();
            this.tb_Mobile_No1 = new System.Windows.Forms.TextBox();
            this.tb_Guardian_Name = new System.Windows.Forms.TextBox();
            this.lbl_Note = new System.Windows.Forms.Label();
            this.lbl_Mobile_No2 = new System.Windows.Forms.Label();
            this.lbl_Mobile_No1 = new System.Windows.Forms.Label();
            this.lbl_Guardian_Name = new System.Windows.Forms.Label();
            this.btn_Update = new System.Windows.Forms.Button();
            this.lbl_Student_ID = new System.Windows.Forms.Label();
            this.lbl_First_Name = new System.Windows.Forms.Label();
            this.lbl_Middle_Name = new System.Windows.Forms.Label();
            this.gb_Student_Information = new System.Windows.Forms.GroupBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.tb_Aadhar_No = new System.Windows.Forms.TextBox();
            this.lbl_Aadhar_No = new System.Windows.Forms.Label();
            this.tb_Mobile_No = new System.Windows.Forms.TextBox();
            this.tb_Last_Name = new System.Windows.Forms.TextBox();
            this.tb_Middle_Name = new System.Windows.Forms.TextBox();
            this.tb_First_Name = new System.Windows.Forms.TextBox();
            this.tb_Student_Id = new System.Windows.Forms.TextBox();
            this.lbl_Mobile_No = new System.Windows.Forms.Label();
            this.lbl_Last_Name = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.gb_Others_Information.SuspendLayout();
            this.gb_Guardian_Information.SuspendLayout();
            this.gb_Student_Information.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Relationship
            // 
            this.tb_Relationship.Enabled = false;
            this.tb_Relationship.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Relationship.Location = new System.Drawing.Point(225, 315);
            this.tb_Relationship.MaxLength = 20;
            this.tb_Relationship.Name = "tb_Relationship";
            this.tb_Relationship.Size = new System.Drawing.Size(236, 38);
            this.tb_Relationship.TabIndex = 10;
            this.tb_Relationship.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.panel1.Controls.Add(this.btn_Back);
            this.panel1.Controls.Add(this.dtp_Date);
            this.panel1.Controls.Add(this.lbl_Update_Student_Details);
            this.panel1.Location = new System.Drawing.Point(1, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1431, 79);
            this.panel1.TabIndex = 12;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(39)))), ((int)(((byte)(58)))));
            this.btn_Back.Font = new System.Drawing.Font("Cambria", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Back.Location = new System.Drawing.Point(3, 10);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(158, 64);
            this.btn_Back.TabIndex = 4;
            this.btn_Back.Text = "Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Location = new System.Drawing.Point(1142, 28);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(261, 34);
            this.dtp_Date.TabIndex = 1;
            // 
            // lbl_Update_Student_Details
            // 
            this.lbl_Update_Student_Details.AutoSize = true;
            this.lbl_Update_Student_Details.Font = new System.Drawing.Font("Times New Roman", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Update_Student_Details.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_Update_Student_Details.Location = new System.Drawing.Point(505, 10);
            this.lbl_Update_Student_Details.Name = "lbl_Update_Student_Details";
            this.lbl_Update_Student_Details.Size = new System.Drawing.Size(521, 57);
            this.lbl_Update_Student_Details.TabIndex = 0;
            this.lbl_Update_Student_Details.Text = "Update Student Details";
            // 
            // gb_Others_Information
            // 
            this.gb_Others_Information.BackColor = System.Drawing.Color.Lavender;
            this.gb_Others_Information.Controls.Add(this.tb_Address);
            this.gb_Others_Information.Controls.Add(this.tb_Course);
            this.gb_Others_Information.Controls.Add(this.tb_College_Name);
            this.gb_Others_Information.Controls.Add(this.lbl_Student_Address);
            this.gb_Others_Information.Controls.Add(this.lbl_Course);
            this.gb_Others_Information.Controls.Add(this.lbl_College_Name);
            this.gb_Others_Information.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Others_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Others_Information.Location = new System.Drawing.Point(980, 117);
            this.gb_Others_Information.Name = "gb_Others_Information";
            this.gb_Others_Information.Size = new System.Drawing.Size(438, 530);
            this.gb_Others_Information.TabIndex = 15;
            this.gb_Others_Information.TabStop = false;
            this.gb_Others_Information.Text = "Others Information";
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(179, 231);
            this.tb_Address.MaxLength = 50;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(233, 38);
            this.tb_Address.TabIndex = 14;
            // 
            // tb_Course
            // 
            this.tb_Course.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.tb_Course.Enabled = false;
            this.tb_Course.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Course.Location = new System.Drawing.Point(179, 144);
            this.tb_Course.MaxLength = 20;
            this.tb_Course.Name = "tb_Course";
            this.tb_Course.Size = new System.Drawing.Size(233, 38);
            this.tb_Course.TabIndex = 13;
            // 
            // tb_College_Name
            // 
            this.tb_College_Name.Enabled = false;
            this.tb_College_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_College_Name.Location = new System.Drawing.Point(179, 67);
            this.tb_College_Name.MaxLength = 50;
            this.tb_College_Name.Name = "tb_College_Name";
            this.tb_College_Name.Size = new System.Drawing.Size(233, 38);
            this.tb_College_Name.TabIndex = 12;
            this.tb_College_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Student_Address
            // 
            this.lbl_Student_Address.AutoSize = true;
            this.lbl_Student_Address.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_Address.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_Address.Location = new System.Drawing.Point(-5, 236);
            this.lbl_Student_Address.Name = "lbl_Student_Address";
            this.lbl_Student_Address.Size = new System.Drawing.Size(112, 30);
            this.lbl_Student_Address.TabIndex = 0;
            this.lbl_Student_Address.Text = " Address";
            // 
            // lbl_Course
            // 
            this.lbl_Course.AutoSize = true;
            this.lbl_Course.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Course.ForeColor = System.Drawing.Color.Black;
            this.lbl_Course.Location = new System.Drawing.Point(6, 155);
            this.lbl_Course.Name = "lbl_Course";
            this.lbl_Course.Size = new System.Drawing.Size(92, 30);
            this.lbl_Course.TabIndex = 0;
            this.lbl_Course.Text = "Course";
            // 
            // lbl_College_Name
            // 
            this.lbl_College_Name.AutoSize = true;
            this.lbl_College_Name.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_College_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_College_Name.Location = new System.Drawing.Point(6, 75);
            this.lbl_College_Name.Name = "lbl_College_Name";
            this.lbl_College_Name.Size = new System.Drawing.Size(167, 30);
            this.lbl_College_Name.TabIndex = 0;
            this.lbl_College_Name.Text = "College Name";
            // 
            // lbl_Relationship
            // 
            this.lbl_Relationship.AutoSize = true;
            this.lbl_Relationship.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Relationship.ForeColor = System.Drawing.Color.Black;
            this.lbl_Relationship.Location = new System.Drawing.Point(15, 326);
            this.lbl_Relationship.Name = "lbl_Relationship";
            this.lbl_Relationship.Size = new System.Drawing.Size(159, 30);
            this.lbl_Relationship.TabIndex = 0;
            this.lbl_Relationship.Text = "Relationship";
            // 
            // gb_Guardian_Information
            // 
            this.gb_Guardian_Information.BackColor = System.Drawing.Color.Lavender;
            this.gb_Guardian_Information.Controls.Add(this.tb_Relationship);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Relationship);
            this.gb_Guardian_Information.Controls.Add(this.tb_Note);
            this.gb_Guardian_Information.Controls.Add(this.tb_Mobile_No2);
            this.gb_Guardian_Information.Controls.Add(this.tb_Mobile_No1);
            this.gb_Guardian_Information.Controls.Add(this.tb_Guardian_Name);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Note);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Mobile_No2);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Mobile_No1);
            this.gb_Guardian_Information.Controls.Add(this.lbl_Guardian_Name);
            this.gb_Guardian_Information.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Guardian_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Guardian_Information.Location = new System.Drawing.Point(496, 117);
            this.gb_Guardian_Information.Name = "gb_Guardian_Information";
            this.gb_Guardian_Information.Size = new System.Drawing.Size(467, 530);
            this.gb_Guardian_Information.TabIndex = 14;
            this.gb_Guardian_Information.TabStop = false;
            this.gb_Guardian_Information.Text = "Guardian Information";
            // 
            // tb_Note
            // 
            this.tb_Note.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Note.Location = new System.Drawing.Point(220, 398);
            this.tb_Note.MaxLength = 50;
            this.tb_Note.Multiline = true;
            this.tb_Note.Name = "tb_Note";
            this.tb_Note.Size = new System.Drawing.Size(241, 83);
            this.tb_Note.TabIndex = 11;
            this.tb_Note.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Mobile_No2
            // 
            this.tb_Mobile_No2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No2.Location = new System.Drawing.Point(225, 234);
            this.tb_Mobile_No2.MaxLength = 10;
            this.tb_Mobile_No2.Name = "tb_Mobile_No2";
            this.tb_Mobile_No2.Size = new System.Drawing.Size(236, 38);
            this.tb_Mobile_No2.TabIndex = 9;
            this.tb_Mobile_No2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Mobile_No1
            // 
            this.tb_Mobile_No1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No1.Location = new System.Drawing.Point(225, 145);
            this.tb_Mobile_No1.MaxLength = 10;
            this.tb_Mobile_No1.Name = "tb_Mobile_No1";
            this.tb_Mobile_No1.Size = new System.Drawing.Size(236, 38);
            this.tb_Mobile_No1.TabIndex = 8;
            this.tb_Mobile_No1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Guardian_Name
            // 
            this.tb_Guardian_Name.Enabled = false;
            this.tb_Guardian_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Guardian_Name.Location = new System.Drawing.Point(225, 67);
            this.tb_Guardian_Name.MaxLength = 50;
            this.tb_Guardian_Name.Name = "tb_Guardian_Name";
            this.tb_Guardian_Name.Size = new System.Drawing.Size(236, 38);
            this.tb_Guardian_Name.TabIndex = 7;
            this.tb_Guardian_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // lbl_Note
            // 
            this.lbl_Note.AutoSize = true;
            this.lbl_Note.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Note.ForeColor = System.Drawing.Color.Black;
            this.lbl_Note.Location = new System.Drawing.Point(21, 405);
            this.lbl_Note.Name = "lbl_Note";
            this.lbl_Note.Size = new System.Drawing.Size(66, 30);
            this.lbl_Note.TabIndex = 0;
            this.lbl_Note.Text = "Note";
            // 
            // lbl_Mobile_No2
            // 
            this.lbl_Mobile_No2.AutoSize = true;
            this.lbl_Mobile_No2.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No2.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No2.Location = new System.Drawing.Point(16, 241);
            this.lbl_Mobile_No2.Name = "lbl_Mobile_No2";
            this.lbl_Mobile_No2.Size = new System.Drawing.Size(144, 30);
            this.lbl_Mobile_No2.TabIndex = 0;
            this.lbl_Mobile_No2.Text = "Mobile No2";
            // 
            // lbl_Mobile_No1
            // 
            this.lbl_Mobile_No1.AutoSize = true;
            this.lbl_Mobile_No1.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No1.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No1.Location = new System.Drawing.Point(16, 155);
            this.lbl_Mobile_No1.Name = "lbl_Mobile_No1";
            this.lbl_Mobile_No1.Size = new System.Drawing.Size(144, 30);
            this.lbl_Mobile_No1.TabIndex = 0;
            this.lbl_Mobile_No1.Text = "Mobile No1";
            // 
            // lbl_Guardian_Name
            // 
            this.lbl_Guardian_Name.AutoSize = true;
            this.lbl_Guardian_Name.Font = new System.Drawing.Font("Cambria", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Guardian_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Guardian_Name.Location = new System.Drawing.Point(15, 75);
            this.lbl_Guardian_Name.Name = "lbl_Guardian_Name";
            this.lbl_Guardian_Name.Size = new System.Drawing.Size(191, 30);
            this.lbl_Guardian_Name.TabIndex = 0;
            this.lbl_Guardian_Name.Text = "Guardian Name";
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Update.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Update.Location = new System.Drawing.Point(803, 664);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(237, 77);
            this.btn_Update.TabIndex = 16;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // lbl_Student_ID
            // 
            this.lbl_Student_ID.AutoSize = true;
            this.lbl_Student_ID.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Student_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_Student_ID.Location = new System.Drawing.Point(10, 65);
            this.lbl_Student_ID.Name = "lbl_Student_ID";
            this.lbl_Student_ID.Size = new System.Drawing.Size(127, 28);
            this.lbl_Student_ID.TabIndex = 0;
            this.lbl_Student_ID.Text = "Student ID";
            // 
            // lbl_First_Name
            // 
            this.lbl_First_Name.AutoSize = true;
            this.lbl_First_Name.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_First_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_First_Name.Location = new System.Drawing.Point(10, 148);
            this.lbl_First_Name.Name = "lbl_First_Name";
            this.lbl_First_Name.Size = new System.Drawing.Size(132, 28);
            this.lbl_First_Name.TabIndex = 0;
            this.lbl_First_Name.Text = "First Name";
            // 
            // lbl_Middle_Name
            // 
            this.lbl_Middle_Name.AutoSize = true;
            this.lbl_Middle_Name.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Middle_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Middle_Name.Location = new System.Drawing.Point(10, 237);
            this.lbl_Middle_Name.Name = "lbl_Middle_Name";
            this.lbl_Middle_Name.Size = new System.Drawing.Size(156, 28);
            this.lbl_Middle_Name.TabIndex = 0;
            this.lbl_Middle_Name.Text = "Middle Name";
            // 
            // gb_Student_Information
            // 
            this.gb_Student_Information.BackColor = System.Drawing.Color.Lavender;
            this.gb_Student_Information.Controls.Add(this.btn_Search);
            this.gb_Student_Information.Controls.Add(this.tb_Aadhar_No);
            this.gb_Student_Information.Controls.Add(this.lbl_Aadhar_No);
            this.gb_Student_Information.Controls.Add(this.tb_Mobile_No);
            this.gb_Student_Information.Controls.Add(this.tb_Last_Name);
            this.gb_Student_Information.Controls.Add(this.tb_Middle_Name);
            this.gb_Student_Information.Controls.Add(this.tb_First_Name);
            this.gb_Student_Information.Controls.Add(this.tb_Student_Id);
            this.gb_Student_Information.Controls.Add(this.lbl_Mobile_No);
            this.gb_Student_Information.Controls.Add(this.lbl_Last_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_Middle_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_First_Name);
            this.gb_Student_Information.Controls.Add(this.lbl_Student_ID);
            this.gb_Student_Information.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Student_Information.ForeColor = System.Drawing.Color.Purple;
            this.gb_Student_Information.Location = new System.Drawing.Point(12, 117);
            this.gb_Student_Information.Name = "gb_Student_Information";
            this.gb_Student_Information.Size = new System.Drawing.Size(471, 530);
            this.gb_Student_Information.TabIndex = 13;
            this.gb_Student_Information.TabStop = false;
            this.gb_Student_Information.Text = "Student Information";
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Search.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Search.Location = new System.Drawing.Point(353, 51);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(112, 49);
            this.btn_Search.TabIndex = 29;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // tb_Aadhar_No
            // 
            this.tb_Aadhar_No.Enabled = false;
            this.tb_Aadhar_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_No.Location = new System.Drawing.Point(188, 471);
            this.tb_Aadhar_No.MaxLength = 12;
            this.tb_Aadhar_No.Name = "tb_Aadhar_No";
            this.tb_Aadhar_No.Size = new System.Drawing.Size(259, 38);
            this.tb_Aadhar_No.TabIndex = 6;
            this.tb_Aadhar_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Aadhar_No
            // 
            this.lbl_Aadhar_No.AutoSize = true;
            this.lbl_Aadhar_No.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhar_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Aadhar_No.Location = new System.Drawing.Point(10, 478);
            this.lbl_Aadhar_No.Name = "lbl_Aadhar_No";
            this.lbl_Aadhar_No.Size = new System.Drawing.Size(134, 28);
            this.lbl_Aadhar_No.TabIndex = 0;
            this.lbl_Aadhar_No.Text = "Aadhar No.";
            // 
            // tb_Mobile_No
            // 
            this.tb_Mobile_No.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mobile_No.Location = new System.Drawing.Point(188, 401);
            this.tb_Mobile_No.MaxLength = 10;
            this.tb_Mobile_No.Name = "tb_Mobile_No";
            this.tb_Mobile_No.Size = new System.Drawing.Size(259, 38);
            this.tb_Mobile_No.TabIndex = 5;
            this.tb_Mobile_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // tb_Last_Name
            // 
            this.tb_Last_Name.Enabled = false;
            this.tb_Last_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Last_Name.Location = new System.Drawing.Point(188, 320);
            this.tb_Last_Name.MaxLength = 20;
            this.tb_Last_Name.Name = "tb_Last_Name";
            this.tb_Last_Name.Size = new System.Drawing.Size(259, 38);
            this.tb_Last_Name.TabIndex = 4;
            this.tb_Last_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Middle_Name
            // 
            this.tb_Middle_Name.Enabled = false;
            this.tb_Middle_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Middle_Name.Location = new System.Drawing.Point(188, 239);
            this.tb_Middle_Name.MaxLength = 20;
            this.tb_Middle_Name.Name = "tb_Middle_Name";
            this.tb_Middle_Name.Size = new System.Drawing.Size(259, 38);
            this.tb_Middle_Name.TabIndex = 3;
            this.tb_Middle_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_First_Name
            // 
            this.tb_First_Name.Enabled = false;
            this.tb_First_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_First_Name.Location = new System.Drawing.Point(188, 148);
            this.tb_First_Name.MaxLength = 20;
            this.tb_First_Name.Name = "tb_First_Name";
            this.tb_First_Name.Size = new System.Drawing.Size(259, 38);
            this.tb_First_Name.TabIndex = 2;
            this.tb_First_Name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Text);
            // 
            // tb_Student_Id
            // 
            this.tb_Student_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Student_Id.Location = new System.Drawing.Point(188, 58);
            this.tb_Student_Id.MaxLength = 10;
            this.tb_Student_Id.Name = "tb_Student_Id";
            this.tb_Student_Id.Size = new System.Drawing.Size(159, 38);
            this.tb_Student_Id.TabIndex = 1;
            this.tb_Student_Id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Only_Numeric);
            // 
            // lbl_Mobile_No
            // 
            this.lbl_Mobile_No.AutoSize = true;
            this.lbl_Mobile_No.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mobile_No.ForeColor = System.Drawing.Color.Black;
            this.lbl_Mobile_No.Location = new System.Drawing.Point(10, 401);
            this.lbl_Mobile_No.Name = "lbl_Mobile_No";
            this.lbl_Mobile_No.Size = new System.Drawing.Size(129, 28);
            this.lbl_Mobile_No.TabIndex = 0;
            this.lbl_Mobile_No.Text = "Mobile No.";
            // 
            // lbl_Last_Name
            // 
            this.lbl_Last_Name.AutoSize = true;
            this.lbl_Last_Name.Font = new System.Drawing.Font("Cambria", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Last_Name.ForeColor = System.Drawing.Color.Black;
            this.lbl_Last_Name.Location = new System.Drawing.Point(10, 318);
            this.lbl_Last_Name.Name = "lbl_Last_Name";
            this.lbl_Last_Name.Size = new System.Drawing.Size(126, 28);
            this.lbl_Last_Name.TabIndex = 0;
            this.lbl_Last_Name.Text = "Last Name";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(76)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Refresh.Location = new System.Drawing.Point(375, 664);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(237, 77);
            this.btn_Refresh.TabIndex = 17;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Update_Student_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1432, 753);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gb_Others_Information);
            this.Controls.Add(this.gb_Guardian_Information);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.gb_Student_Information);
            this.Controls.Add(this.btn_Refresh);
            this.Name = "frm_Update_Student_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update Student Details";
            this.Load += new System.EventHandler(this.frm_Update_Student_Details_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Others_Information.ResumeLayout(false);
            this.gb_Others_Information.PerformLayout();
            this.gb_Guardian_Information.ResumeLayout(false);
            this.gb_Guardian_Information.PerformLayout();
            this.gb_Student_Information.ResumeLayout(false);
            this.gb_Student_Information.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Relationship;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.Label lbl_Update_Student_Details;
        private System.Windows.Forms.GroupBox gb_Others_Information;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Course;
        private System.Windows.Forms.TextBox tb_College_Name;
        private System.Windows.Forms.Label lbl_Student_Address;
        private System.Windows.Forms.Label lbl_Course;
        private System.Windows.Forms.Label lbl_College_Name;
        private System.Windows.Forms.Label lbl_Relationship;
        private System.Windows.Forms.GroupBox gb_Guardian_Information;
        private System.Windows.Forms.TextBox tb_Note;
        private System.Windows.Forms.TextBox tb_Mobile_No2;
        private System.Windows.Forms.TextBox tb_Mobile_No1;
        private System.Windows.Forms.TextBox tb_Guardian_Name;
        private System.Windows.Forms.Label lbl_Note;
        private System.Windows.Forms.Label lbl_Mobile_No2;
        private System.Windows.Forms.Label lbl_Mobile_No1;
        private System.Windows.Forms.Label lbl_Guardian_Name;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.Label lbl_Student_ID;
        private System.Windows.Forms.Label lbl_First_Name;
        private System.Windows.Forms.Label lbl_Middle_Name;
        private System.Windows.Forms.GroupBox gb_Student_Information;
        private System.Windows.Forms.TextBox tb_Aadhar_No;
        private System.Windows.Forms.Label lbl_Aadhar_No;
        private System.Windows.Forms.TextBox tb_Mobile_No;
        private System.Windows.Forms.TextBox tb_Last_Name;
        private System.Windows.Forms.TextBox tb_Middle_Name;
        private System.Windows.Forms.TextBox tb_First_Name;
        private System.Windows.Forms.TextBox tb_Student_Id;
        private System.Windows.Forms.Label lbl_Mobile_No;
        private System.Windows.Forms.Label lbl_Last_Name;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Button btn_Search;
    }
}