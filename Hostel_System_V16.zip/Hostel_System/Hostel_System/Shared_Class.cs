﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hostel_System
{
    class Shared_Class
    {
        public static string Username = "USER";
        public static int UserRole = 0;
        public static int Room_No = 0;
        public static int Stud_ID = 0;
    }
}
